//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CzMvWqLV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/ai",
			"/future-score",
			"/incubation",
			"/management",
			"/multimedia",
			"/online-programs",
			"/outcomes",
			"/ug-programs",
			"/workshop",
			"/portfolio/$slug"
		],
		preloads: [
			"/assets/index-DVUBL9F0.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/react-DHmoMYoq.js",
			"/assets/link-Gv8cj_pG.js",
			"/assets/useStore-CG-np4nj.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/matchContext-BLYTW6T-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DVUBL9F0.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DCV3gM8T.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/calendar-SD3Xr6ew.js",
			"/assets/x-Bmtl9lp9.js",
			"/assets/clock-BKbfwJ3a.js"
		]
	},
	"/ai": {
		filePath: "/dev-server/src/routes/ai.tsx",
		children: [
			"/ai/advanced-data-science",
			"/ai/big-data",
			"/ai/big-data-cert",
			"/ai/cyber-security",
			"/ai/data-security",
			"/ai/gen-ai",
			"/ai/product-management",
			"/ai/"
		],
		preloads: ["/assets/ai-B0fx_eZP.js"]
	},
	"/future-score": {
		filePath: "/dev-server/src/routes/future-score.tsx",
		children: ["/future-score/admin", "/future-score/"],
		preloads: ["/assets/future-score-BrrGkMPG.js"]
	},
	"/incubation": {
		filePath: "/dev-server/src/routes/incubation.tsx",
		children: void 0,
		preloads: [
			"/assets/incubation-DwOEbldm.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/building-2-D2szo2UC.js",
			"/assets/circle-check-TGib2X25.js",
			"/assets/dollar-sign-CuVNJAhL.js",
			"/assets/lightbulb-DGx7Rxji.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js"
		]
	},
	"/management": {
		filePath: "/dev-server/src/routes/management.tsx",
		children: [
			"/management/business-entrepreneurship",
			"/management/finance-accounting",
			"/management/marketing-growth",
			"/management/people-operations",
			"/management/product-management",
			"/management/sales-business-development",
			"/management/"
		],
		preloads: ["/assets/management-B0fx_eZP.js"]
	},
	"/multimedia": {
		filePath: "/dev-server/src/routes/multimedia.tsx",
		children: [
			"/multimedia/ai-graphic-design",
			"/multimedia/ai-video-editing-vfx",
			"/multimedia/animation-vfx",
			"/multimedia/film-production",
			"/multimedia/pm-smm",
			"/multimedia/"
		],
		preloads: ["/assets/multimedia-B0fx_eZP.js"]
	},
	"/online-programs": {
		filePath: "/dev-server/src/routes/online-programs.tsx",
		children: void 0,
		preloads: [
			"/assets/online-programs-DYsfyrwG.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/monitor-QUfmzXuq.js",
			"/assets/zap-3lSWz4TO.js"
		]
	},
	"/outcomes": {
		filePath: "/dev-server/src/routes/outcomes.tsx",
		children: void 0,
		preloads: [
			"/assets/outcomes-BB3QBeEe.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/building-2-D2szo2UC.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js"
		]
	},
	"/ug-programs": {
		filePath: "/dev-server/src/routes/ug-programs.tsx",
		children: void 0,
		preloads: [
			"/assets/ug-programs-C0hx78k1.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/book-open-CCCN4OvP.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/building-2-D2szo2UC.js",
			"/assets/calculator-CVTxiifz.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/graduation-cap-DQ-Mniyi.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js"
		]
	},
	"/workshop": {
		filePath: "/dev-server/src/routes/workshop.tsx",
		children: void 0,
		preloads: [
			"/assets/workshop-CvIKmBB_.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/book-open-CCCN4OvP.js",
			"/assets/brain-C2j6qV9X.js",
			"/assets/calendar-SD3Xr6ew.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/x-Bmtl9lp9.js",
			"/assets/circle-check-TGib2X25.js",
			"/assets/clipboard-list-CSi_6Wkw.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/lightbulb-DGx7Rxji.js",
			"/assets/message-square-DdDyki-u.js",
			"/assets/search-CKfJmV27.js",
			"/assets/target-reOs65de.js",
			"/assets/users-CviH6Ox7.js"
		]
	},
	"/ai/advanced-data-science": {
		filePath: "/dev-server/src/routes/ai.advanced-data-science.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.advanced-data-science-DlqUUr0K.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/chart-line-nk6w2sOy.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/calendar-SD3Xr6ew.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/circle-check-TGib2X25.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/database-CIGND17q.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/server-DekXndRZ.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/target-reOs65de.js",
			"/assets/timer-Bnm_-rZF.js",
			"/assets/trophy-uAopZ_Rk.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js"
		]
	},
	"/ai/big-data": {
		filePath: "/dev-server/src/routes/ai.big-data.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.big-data-B_v-WXT0.js",
			"/assets/database-CIGND17q.js",
			"/assets/CourseDetail-D-BWTTbk.js",
			"/assets/card-big-data-DnLTJYDI.js"
		]
	},
	"/ai/big-data-cert": {
		filePath: "/dev-server/src/routes/ai.big-data-cert.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.big-data-cert-Ddg_iSYs.js",
			"/assets/cpu-C2Ti4Yfb.js",
			"/assets/CourseDetail-D-BWTTbk.js",
			"/assets/card-bd-cert-BLLxYa3n.js"
		]
	},
	"/ai/cyber-security": {
		filePath: "/dev-server/src/routes/ai.cyber-security.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.cyber-security-ChYaHLb6.js",
			"/assets/card-cyber-u0J200ox.js",
			"/assets/CourseDetail-D-BWTTbk.js"
		]
	},
	"/ai/data-security": {
		filePath: "/dev-server/src/routes/ai.data-security.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.data-security-QPyrHa69.js",
			"/assets/card-datasec-PUF67myO.js",
			"/assets/CourseDetail-D-BWTTbk.js"
		]
	},
	"/ai/gen-ai": {
		filePath: "/dev-server/src/routes/ai.gen-ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.gen-ai-BOPr5MRh.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/calendar-SD3Xr6ew.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/circle-check-TGib2X25.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/cpu-C2Ti4Yfb.js",
			"/assets/graduation-cap-DQ-Mniyi.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/message-square-DdDyki-u.js",
			"/assets/monitor-QUfmzXuq.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/server-DekXndRZ.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/timer-Bnm_-rZF.js",
			"/assets/trophy-uAopZ_Rk.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/wand-sparkles-2tq41lzm.js"
		]
	},
	"/ai/product-management": {
		filePath: "/dev-server/src/routes/ai.product-management.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.product-management-riwYh3FP.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/CourseDetail-D-BWTTbk.js",
			"/assets/card-pm-C3b5mUmT.js"
		]
	},
	"/future-score/admin": {
		filePath: "/dev-server/src/routes/future-score.admin.tsx",
		children: void 0,
		preloads: [
			"/assets/future-score.admin-d-Q0oHAj.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/FuturisticBackground-CJttpVxS.js"
		]
	},
	"/management/business-entrepreneurship": {
		filePath: "/dev-server/src/routes/management.business-entrepreneurship.tsx",
		children: void 0,
		preloads: [
			"/assets/management.business-entrepreneurship-DgDfVhep.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/dollar-sign-CuVNJAhL.js",
			"/assets/handshake-WBXbQIlY.js",
			"/assets/lightbulb-DGx7Rxji.js",
			"/assets/megaphone-Tpf7wljb.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/scale-BH-Im57Q.js",
			"/assets/target-reOs65de.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-biz-Z1fqNwKi.js"
		]
	},
	"/management/finance-accounting": {
		filePath: "/dev-server/src/routes/management.finance-accounting.tsx",
		children: void 0,
		preloads: [
			"/assets/management.finance-accounting-Bnt5GC98.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/book-open-CCCN4OvP.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/calculator-CVTxiifz.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/dollar-sign-CuVNJAhL.js",
			"/assets/scale-BH-Im57Q.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-fin-CSctJc0h.js"
		]
	},
	"/management/marketing-growth": {
		filePath: "/dev-server/src/routes/management.marketing-growth.tsx",
		children: void 0,
		preloads: [
			"/assets/management.marketing-growth-k5RATs5v.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/mail-D311rqVx.js",
			"/assets/megaphone-Tpf7wljb.js",
			"/assets/search-CKfJmV27.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/target-reOs65de.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-mkt-DWna6EAV.js"
		]
	},
	"/management/people-operations": {
		filePath: "/dev-server/src/routes/management.people-operations.tsx",
		children: void 0,
		preloads: [
			"/assets/management.people-operations-BOrH79Y3.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/scale-BH-Im57Q.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-ppl-BxO7CfRZ.js"
		]
	},
	"/management/product-management": {
		filePath: "/dev-server/src/routes/management.product-management.tsx",
		children: void 0,
		preloads: [
			"/assets/management.product-management-DO02F-t8.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/clipboard-list-CSi_6Wkw.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/pen-tool-DaR_Nwkh.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/search-CKfJmV27.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-pm-_uUYt0yW.js"
		]
	},
	"/management/sales-business-development": {
		filePath: "/dev-server/src/routes/management.sales-business-development.tsx",
		children: void 0,
		preloads: [
			"/assets/management.sales-business-development-CtxBnuCU.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/handshake-WBXbQIlY.js",
			"/assets/mail-D311rqVx.js",
			"/assets/search-CKfJmV27.js",
			"/assets/target-reOs65de.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/mg-sales-D-nzijmP.js"
		]
	},
	"/multimedia/ai-graphic-design": {
		filePath: "/dev-server/src/routes/multimedia.ai-graphic-design.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.ai-graphic-design-D93xQ8DE.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/book-open-CCCN4OvP.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/film-DwcZmSds.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/pen-tool-DaR_Nwkh.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/wand-sparkles-2tq41lzm.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/card-mm-graphic-WdRqDNpH.js"
		]
	},
	"/multimedia/ai-video-editing-vfx": {
		filePath: "/dev-server/src/routes/multimedia.ai-video-editing-vfx.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.ai-video-editing-vfx-BRmGdmEQ.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/film-DwcZmSds.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/card-mm-video-Baz5FnyN.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/scissors-Dfhpwz4W.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/wand-sparkles-2tq41lzm.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js"
		]
	},
	"/multimedia/animation-vfx": {
		filePath: "/dev-server/src/routes/multimedia.animation-vfx.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.animation-vfx-qvD9TaqG.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/cpu-C2Ti4Yfb.js",
			"/assets/film-DwcZmSds.js",
			"/assets/layers-gDFDcbgW.js",
			"/assets/pen-tool-DaR_Nwkh.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/wand-sparkles-2tq41lzm.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/card-mm-anim-CKwd8WCj.js"
		]
	},
	"/multimedia/film-production": {
		filePath: "/dev-server/src/routes/multimedia.film-production.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.film-production-BN9THC-1.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/card-mm-film-Qfhdb-nU.js",
			"/assets/film-DwcZmSds.js",
			"/assets/pen-tool-DaR_Nwkh.js",
			"/assets/scissors-Dfhpwz4W.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js"
		]
	},
	"/multimedia/pm-smm": {
		filePath: "/dev-server/src/routes/multimedia.pm-smm.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.pm-smm-CrTXcOPb.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/mail-D311rqVx.js",
			"/assets/megaphone-Tpf7wljb.js",
			"/assets/search-CKfJmV27.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/target-reOs65de.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/zap-3lSWz4TO.js",
			"/assets/MultimediaCourseDetail-CiDMlxd0.js",
			"/assets/card-mm-pmsmm-5SMiIHVx.js"
		]
	},
	"/portfolio/$slug": {
		filePath: "/dev-server/src/routes/portfolio.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio._slug-CsxKerUa.js",
			"/assets/portfolio._slug-D8j17tRc.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/award-CHHb8Lm4.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/graduation-cap-DQ-Mniyi.js",
			"/assets/mail-D311rqVx.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/target-reOs65de.js",
			"/assets/portfolio._slug-n_8VEPAT.js"
		]
	},
	"/ai/": {
		filePath: "/dev-server/src/routes/ai.index.tsx",
		children: void 0,
		preloads: [
			"/assets/ai.index-D0pU--7s.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/chart-line-nk6w2sOy.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/brain-C2j6qV9X.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/cpu-C2Ti4Yfb.js",
			"/assets/database-CIGND17q.js",
			"/assets/card-datasec-PUF67myO.js",
			"/assets/card-cyber-u0J200ox.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/card-bd-cert-BLLxYa3n.js",
			"/assets/card-big-data-DnLTJYDI.js",
			"/assets/card-pm-C3b5mUmT.js"
		]
	},
	"/future-score/": {
		filePath: "/dev-server/src/routes/future-score.index.tsx",
		children: void 0,
		preloads: [
			"/assets/future-score.index-RSIKuZfW.js",
			"/assets/createLucideIcon-CaYjXmwE.js",
			"/assets/FuturisticBackground-CJttpVxS.js",
			"/assets/rocket-Bq8rK28_.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/trophy-uAopZ_Rk.js"
		]
	},
	"/management/": {
		filePath: "/dev-server/src/routes/management.index.tsx",
		children: void 0,
		preloads: [
			"/assets/management.index-CnWUNwgY.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/briefcase-Ujus5eMn.js",
			"/assets/chart-column-D_th3kef.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/dollar-sign-CuVNJAhL.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/target-reOs65de.js",
			"/assets/trending-up-CGDmfQK9.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/mg-biz-Z1fqNwKi.js",
			"/assets/mg-fin-CSctJc0h.js",
			"/assets/mg-sales-D-nzijmP.js",
			"/assets/mg-mkt-DWna6EAV.js",
			"/assets/mg-ppl-BxO7CfRZ.js",
			"/assets/mg-pm-_uUYt0yW.js"
		]
	},
	"/multimedia/": {
		filePath: "/dev-server/src/routes/multimedia.index.tsx",
		children: void 0,
		preloads: [
			"/assets/multimedia.index-Bvmc03vZ.js",
			"/assets/skill-ai-logo-DmE8jtHA.js",
			"/assets/arrow-right-t5kLs4TR.js",
			"/assets/card-mm-film-Qfhdb-nU.js",
			"/assets/clock-BKbfwJ3a.js",
			"/assets/film-DwcZmSds.js",
			"/assets/megaphone-Tpf7wljb.js",
			"/assets/card-mm-video-Baz5FnyN.js",
			"/assets/sparkles-uETicRdT.js",
			"/assets/users-CviH6Ox7.js",
			"/assets/wand-sparkles-2tq41lzm.js",
			"/assets/card-mm-graphic-WdRqDNpH.js",
			"/assets/card-mm-anim-CKwd8WCj.js",
			"/assets/card-mm-pmsmm-5SMiIHVx.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
