import { n as __toESM } from "../_runtime.mjs";
import { n as AnimatePresence } from "../_libs/framer-motion+[...].mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as phpBackendEnabled, r as saveFutureScore, t as fetchLeaderboard } from "./php-api-BHg0UHqS.mjs";
import { B as MessageCircle, D as Rocket, E as RotateCcw, L as Minimize2, Lt as ArrowDown, O as QrCode, St as Check, U as Maximize2, d as Trophy, dt as Copy, l as User, o as VolumeX, s as Volume2, st as Download, y as Sparkles } from "../_libs/lucide-react.mjs";
import { a as getLeaderboard, c as questions, n as addLeaderboardEntry, r as calculateResult, s as profiles, t as FuturisticBackground } from "./FuturisticBackground-Dm9rzgp0.mjs";
import { t as motion } from "../_libs/motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/future-score.index-bT5XX72l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "w-full rounded-xl border border-input bg-background/60 px-4 py-3 text-left outline-none placeholder:text-muted-foreground focus:border-secondary";
function LandingScreen({ onStart }) {
	const [step, setStep] = (0, import_react.useState)("intro");
	const [name, setName] = (0, import_react.useState)("");
	const [college, setCollege] = (0, import_react.useState)("");
	const [contact, setContact] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const submit = (e) => {
		e.preventDefault();
		const trimmed = name.trim();
		if (!trimmed) {
			setError("Please enter your name.");
			return;
		}
		if (contact.trim() && !/^[0-9+\-\s]{7,15}$/.test(contact.trim())) {
			setError("Please enter a valid contact number.");
			return;
		}
		setError("");
		onStart({
			name: trimmed,
			college: college.trim(),
			contact: contact.trim()
		});
	};
	if (step === "details") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative flex min-h-[100dvh] flex-col items-center justify-center px-5 py-16 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.form, {
			onSubmit: submit,
			initial: {
				opacity: 0,
				y: 20
			},
			animate: {
				opacity: 1,
				y: 0
			},
			transition: { duration: .5 },
			className: "glass glow-primary w-full max-w-md rounded-3xl p-8 sm:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/15",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-6 w-6 text-primary" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 font-display text-2xl font-black uppercase tracking-widest",
					children: "Before We Begin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Tell us who's playing — your name goes on the leaderboard."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-7 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "player-name",
							children: "Your name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "player-name",
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Your name *",
							maxLength: 40,
							autoFocus: true,
							className: inputClass
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "player-college",
							children: "College name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "player-college",
							value: college,
							onChange: (e) => setCollege(e.target.value),
							placeholder: "College name",
							maxLength: 60,
							className: inputClass
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "player-contact",
							children: "Contact number"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "player-contact",
							value: contact,
							onChange: (e) => setContact(e.target.value),
							placeholder: "Contact number",
							inputMode: "tel",
							maxLength: 15,
							className: inputClass
						})
					]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-destructive",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
					type: "submit",
					whileHover: { scale: 1.03 },
					whileTap: { scale: .97 },
					className: "glow-primary mt-7 inline-flex w-full items-center justify-center gap-3 rounded-full bg-primary px-8 py-4 font-display text-lg font-bold uppercase tracking-widest text-primary-foreground transition-colors hover:bg-primary/90",
					children: ["Start Your Future", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "h-5 w-5" })]
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-[100dvh] flex-col items-center justify-center px-5 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { duration: .6 },
				className: "glass mb-8 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs uppercase tracking-[0.28em] text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 text-secondary" }), "Career Discovery Game"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					scale: .5,
					opacity: 0
				},
				animate: {
					scale: 1,
					opacity: 1
				},
				transition: {
					type: "spring",
					stiffness: 120,
					damping: 12
				},
				className: "text-6xl sm:text-7xl",
				children: "🚀"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
				initial: {
					opacity: 0,
					y: 24
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					delay: .15,
					duration: .6
				},
				className: "mt-6 font-display text-4xl font-black leading-[0.95] tracking-tight sm:text-6xl lg:text-8xl",
				children: [
					"WHAT'S YOUR",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient",
						children: "FUTURE SCORE?"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				transition: {
					delay: .35,
					duration: .6
				},
				className: "mt-6 max-w-xl text-lg text-muted-foreground sm:text-xl",
				children: "Your interests. Your skills. Your possible future."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 16
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					delay: .45,
					duration: .6
				},
				className: "mt-8 flex flex-wrap items-center justify-center gap-3 text-sm text-muted-foreground",
				children: [
					"10 Questions",
					"3 Minutes",
					"1 Future Profile"
				].map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "glass rounded-full px-4 py-2 tracking-wide",
					children: chip
				}, chip))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
				initial: {
					opacity: 0,
					scale: .9
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				transition: {
					delay: .6,
					duration: .5
				},
				whileHover: { scale: 1.04 },
				whileTap: { scale: .97 },
				onClick: () => setStep("details"),
				className: "glow-primary mt-12 inline-flex items-center gap-3 rounded-full bg-primary px-10 py-5 font-display text-lg font-bold uppercase tracking-widest text-primary-foreground transition-colors hover:bg-primary/90 sm:text-xl",
				children: ["Start Your Future", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "h-5 w-5" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				transition: { delay: .8 },
				className: "mt-6 max-w-sm text-sm text-muted-foreground",
				children: "No right answers. Just choose what feels most like you."
			})
		]
	});
}
function ProgressBar({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "progressbar",
		"aria-valuenow": Math.round(value),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": "Game progress",
		className: "h-2 w-full overflow-hidden rounded-full bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			className: "h-full rounded-full",
			style: { background: "var(--gradient-hero)" },
			initial: { width: 0 },
			animate: { width: `${value}%` },
			transition: {
				type: "spring",
				stiffness: 90,
				damping: 18
			}
		})
	});
}
function AnswerOption({ option, index, selected, locked, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
		type: "button",
		initial: {
			opacity: 0,
			x: -18
		},
		animate: {
			opacity: 1,
			x: 0
		},
		transition: {
			delay: .06 * index,
			duration: .35
		},
		whileHover: {
			scale: locked ? 1 : 1.015,
			x: locked ? 0 : 4
		},
		whileTap: { scale: locked ? 1 : .985 },
		onClick: onSelect,
		disabled: locked && !selected,
		"aria-pressed": selected,
		"aria-label": `Option ${option.key}: ${option.label}`,
		className: `glass group flex w-full items-center gap-4 rounded-2xl px-4 py-4 text-left transition-colors sm:px-5 sm:py-5 ${selected ? "glow-primary border-primary/60 bg-primary/10" : "hover:border-secondary/50"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `flex h-10 w-10 shrink-0 items-center justify-center rounded-xl font-display text-sm font-bold transition-colors ${selected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground group-hover:text-secondary"}`,
				children: option.key
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-2xl sm:text-3xl",
				children: option.emoji
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 text-base font-medium leading-snug sm:text-lg",
				children: option.label
			}),
			selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
				initial: {
					scale: 0,
					rotate: -90
				},
				animate: {
					scale: 1,
					rotate: 0
				},
				className: "flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
			})
		]
	});
}
function QuestionCard({ question, selectedKey, locked, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 28
		},
		animate: {
			opacity: 1,
			y: 0
		},
		exit: {
			opacity: 0,
			y: -28
		},
		transition: { duration: .35 },
		className: "w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-bold leading-tight sm:text-4xl",
				children: question.prompt
			}),
			question.sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-lg text-muted-foreground sm:text-xl",
				children: question.sub
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-7 grid gap-3",
				children: question.options.map((option, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnswerOption, {
					option,
					index: i,
					selected: selectedKey === option.key,
					locked,
					onSelect: () => onSelect(option.key)
				}, option.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-xs uppercase tracking-[0.25em] text-muted-foreground",
				children: "Tap a card or press A – E"
			})
		]
	});
}
function GameScreen({ answers, onAnswer, onComplete, onSelectSound }) {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [locked, setLocked] = (0, import_react.useState)(false);
	const question = questions[index] ?? questions[0];
	const progress = (index + (locked ? 1 : 0)) / questions.length * 100;
	const handleSelect = (0, import_react.useCallback)((key) => {
		if (locked) return;
		setLocked(true);
		onSelectSound();
		onAnswer(question.id, key);
		window.setTimeout(() => {
			if (index === questions.length - 1) onComplete();
			else {
				setIndex((i) => i + 1);
				setLocked(false);
			}
		}, 550);
	}, [
		locked,
		onSelectSound,
		onAnswer,
		question.id,
		index,
		onComplete
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const key = e.key.toUpperCase();
			if ([
				"A",
				"B",
				"C",
				"D",
				"E"
			].includes(key)) handleSelect(key);
			if ([
				"1",
				"2",
				"3",
				"4",
				"5"
			].includes(key)) handleSelect([
				"A",
				"B",
				"C",
				"D",
				"E"
			][Number(key) - 1]);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [handleSelect]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto flex min-h-[100dvh] w-full max-w-3xl flex-col justify-center px-5 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between font-display text-xs uppercase tracking-[0.3em] text-muted-foreground sm:text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Question ",
					String(index + 1).padStart(2, "0"),
					" / ",
					questions.length
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-secondary",
					children: [Math.round(progress), "%"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: progress })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
			mode: "wait",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionCard, {
				question,
				selectedKey: answers[question.id],
				locked,
				onSelect: handleSelect
			}, question.id)
		})]
	});
}
var STEPS = [
	"Analyzing your choices...",
	"Finding your strongest profile...",
	"Building your roadmap..."
];
function CalculatingScreen({ onDone }) {
	const [percent, setPercent] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const started = Date.now();
		const total = 3600;
		const timer = window.setInterval(() => {
			const p = Math.min(100, Math.round((Date.now() - started) / total * 100));
			setPercent(p);
			if (p >= 100) {
				window.clearInterval(timer);
				window.setTimeout(onDone, 350);
			}
		}, 40);
		return () => window.clearInterval(timer);
	}, [onDone]);
	const stepIndex = Math.min(STEPS.length - 1, Math.floor(percent / 100 * STEPS.length));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-[100dvh] flex-col items-center justify-center px-5 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-56 w-56 items-center justify-center sm:h-72 sm:w-72",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 rounded-full border-2 border-primary/40 border-t-primary",
						style: { animation: "spin-slow 2.2s linear infinite" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-6 rounded-full border-2 border-secondary/30 border-b-secondary",
						style: { animation: "spin-slow 3.4s linear infinite reverse" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-14 rounded-full bg-primary/10 blur-xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-5xl font-black text-gradient sm:text-6xl",
						children: [percent, "%"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl font-bold uppercase tracking-[0.2em] sm:text-3xl",
				children: "Calculating your future..."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 h-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "text-muted-foreground",
					children: STEPS[stepIndex]
				}, stepIndex)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 h-1.5 w-full max-w-md overflow-hidden rounded-full bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full transition-[width] duration-100",
					style: {
						width: `${percent}%`,
						background: "var(--gradient-hero)"
					}
				})
			})
		]
	});
}
var roadmaps = {
	"ai-innovator": [
		"Python",
		"AI Fundamentals",
		"Generative AI",
		"Prompt Engineering",
		"RAG / AI Applications",
		"AI Agents",
		"🤖 AI Career Opportunities"
	],
	"data-explorer": [
		"Excel & Statistics",
		"SQL",
		"Python for Data",
		"Power BI / Visualization",
		"Machine Learning Basics",
		"Analytics Projects",
		"📊 Data Career Opportunities"
	],
	"tech-builder": [
		"Programming Basics",
		"HTML • CSS • JavaScript",
		"React",
		"Backend & APIs",
		"Databases",
		"Cloud & Deployment",
		"💻 Developer Career Opportunities"
	],
	"cyber-guardian": [
		"Networking Basics",
		"Linux",
		"Security Fundamentals",
		"Ethical Hacking",
		"Threat Detection & SOC",
		"Digital Forensics",
		"🔐 Cybersecurity Career Opportunities"
	],
	"business-strategist": [
		"Business Fundamentals",
		"Excel & SQL",
		"Marketing & Growth",
		"Business Analytics",
		"Dashboards & Reporting",
		"Strategy & Case Studies",
		"📈 Business Career Opportunities"
	]
};
var programs = [
	{
		emoji: "🤖",
		label: "Artificial Intelligence"
	},
	{
		emoji: "📊",
		label: "Data Analytics"
	},
	{
		emoji: "💻",
		label: "Software Development"
	},
	{
		emoji: "🔐",
		label: "Cybersecurity"
	},
	{
		emoji: "📈",
		label: "Business Analytics"
	}
];
function ScoreChart({ ranked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3",
		children: ranked.map((entry, i) => {
			const profile = profiles[entry.id];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 14
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: {
					once: true,
					amount: .4
				},
				transition: { delay: i * .08 },
				className: "glass rounded-2xl px-4 py-4 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xl",
							children: profile.emoji
						}), profile.name]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display font-bold text-secondary",
						children: [entry.percent, "%"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2 overflow-hidden rounded-full bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "h-full rounded-full",
						style: { background: "var(--gradient-hero)" },
						initial: { width: 0 },
						whileInView: { width: `${entry.percent}%` },
						viewport: { once: true },
						transition: {
							duration: 1,
							delay: .15 + i * .08,
							ease: "easeOut"
						}
					})
				})]
			}, entry.id);
		})
	});
}
function ChipSection({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 flex flex-wrap gap-3",
		children: items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.span, {
			initial: {
				opacity: 0,
				scale: .9
			},
			whileInView: {
				opacity: 1,
				scale: 1
			},
			viewport: { once: true },
			transition: { delay: i * .06 },
			className: "glass inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium sm:text-base",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-lg",
				children: item.emoji
			}), item.label]
		}, item.label))
	})] });
}
function CareerSection({ careers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
		children: "Career Directions"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 grid gap-3 sm:grid-cols-2",
		children: careers.map((career, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				y: 16
			},
			whileInView: {
				opacity: 1,
				y: 0
			},
			viewport: { once: true },
			transition: { delay: i * .07 },
			className: "glass flex items-center gap-3 rounded-2xl px-4 py-4 transition-colors hover:border-secondary/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-2xl",
				children: career.emoji
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: career.label
			})]
		}, career.label))
	})] });
}
function Roadmap({ steps }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
		children: "🚀 Your Possible Future Roadmap"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "relative mt-6 flex flex-col items-center gap-0",
		children: steps.map((step, i) => {
			const last = i === steps.length - 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.li, {
				initial: {
					opacity: 0,
					y: 24,
					scale: .96
				},
				whileInView: {
					opacity: 1,
					y: 0,
					scale: 1
				},
				viewport: {
					once: true,
					amount: .6
				},
				transition: { duration: .4 },
				className: "flex w-full max-w-md flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `glass w-full rounded-2xl px-5 py-4 text-center font-display font-bold tracking-wide ${last ? "glow-primary border-primary/60 bg-primary/10" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-2 text-xs text-muted-foreground",
						children: last ? "" : String(i + 1).padStart(2, "0")
					}), step]
				}), !last && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {
					className: "my-2 h-5 w-5 text-secondary",
					"aria-hidden": true
				})]
			}, step);
		})
	})] });
}
var MEDALS = [
	"🔥",
	"⚡",
	"🚀",
	"🤖",
	"📊"
];
function Leaderboard({ score, profile, player, onClaimed }) {
	const [entries, setEntries] = (0, import_react.useState)(() => [...getLeaderboard()].sort((a, b) => b.score - a.score).slice(0, 10));
	const [name, setName] = (0, import_react.useState)(player?.name ?? "");
	const [college, setCollege] = (0, import_react.useState)(player?.college ?? "");
	const [rank, setRank] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!phpBackendEnabled) return;
		let cancelled = false;
		fetchLeaderboard(10).then((res) => {
			if (cancelled || !res.ok || !res.data) return;
			setEntries(res.data.leaderboard.map((r) => ({
				id: String(r.id),
				name: r.name,
				college: r.college ?? "",
				score: r.score,
				profile: r.profile,
				timestamp: new Date(r.created_at).getTime()
			})));
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const claim = async (e) => {
		e.preventDefault();
		const trimmed = name.trim();
		if (!trimmed) {
			setError("Please enter your first name.");
			return;
		}
		setError("");
		setSaving(true);
		if (phpBackendEnabled) {
			const res = await saveFutureScore({
				name: trimmed,
				college: college.trim(),
				contact: player?.contact,
				score,
				profile
			});
			setSaving(false);
			if (res.ok && res.data) {
				setEntries(res.data.leaderboard.map((r) => ({
					id: String(r.id),
					name: r.name,
					college: r.college ?? "",
					score: r.score,
					profile: r.profile,
					timestamp: new Date(r.created_at).getTime()
				})));
				setRank(res.data.rank);
				onClaimed?.(trimmed, college.trim());
				return;
			}
			setError(res.error ?? "Could not save your score. Saved on this device instead.");
		}
		const result = addLeaderboardEntry({
			name: trimmed,
			college: college.trim(),
			contact: player?.contact,
			score,
			profile
		});
		setSaving(false);
		setEntries([...result.entries].sort((a, b) => b.score - a.score).slice(0, 10));
		setRank(result.rank);
		onClaimed?.(trimmed, college.trim());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-3xl p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "flex items-center gap-2 font-display text-lg font-bold uppercase tracking-widest",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-5 w-5 text-primary" }), " Future Score Leaderboard"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 grid gap-2",
				children: entries.map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `flex items-center gap-3 rounded-xl px-4 py-3 ${rank !== null && i + 1 === rank ? "glow-secondary bg-secondary/10" : "bg-muted/40"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-lg",
							children: MEDALS[i] ?? "•"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1 truncate font-medium",
							children: [entry.name, entry.college ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: entry.college
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display font-bold text-secondary",
							children: entry.score
						})
					]
				}, entry.id))
			}),
			rank === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: claim,
				className: "mt-6 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm uppercase tracking-[0.25em] text-muted-foreground",
						children: "Enter the leaderboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "lb-name",
						children: "First name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "lb-name",
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "First name",
						maxLength: 24,
						className: "rounded-xl border border-input bg-background/60 px-4 py-3 outline-none placeholder:text-muted-foreground focus:border-secondary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "lb-college",
						children: "College (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "lb-college",
						value: college,
						onChange: (e) => setCollege(e.target.value),
						placeholder: "College (optional)",
						maxLength: 40,
						className: "rounded-xl border border-input bg-background/60 px-4 py-3 outline-none placeholder:text-muted-foreground focus:border-secondary"
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: saving,
						className: "glow-primary rounded-xl bg-primary px-6 py-3 font-display font-bold uppercase tracking-widest text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60",
						children: saving ? "Saving…" : "Claim My Score 🚀"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.p, {
				initial: {
					opacity: 0,
					scale: .95
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				className: "mt-6 rounded-xl bg-secondary/10 px-4 py-4 text-center font-display font-bold",
				children: [
					"You are ranked #",
					rank,
					" with ",
					score,
					" points 🚀"
				]
			})
		]
	});
}
function ShareResult({ score, profile, match }) {
	const cardRef = (0, import_react.useRef)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const text = `🚀 What's Your Future Score? I scored ${score}/100 — ${profile.emoji} ${profile.name.toUpperCase()} (${match}% match). Your interests. Your skills. Your possible future.`;
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 2e3);
		} catch {
			setCopied(false);
		}
	};
	const download = () => {
		const canvas = document.createElement("canvas");
		canvas.width = 1e3;
		canvas.height = 1250;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const grad = ctx.createLinearGradient(0, 0, 1e3, 1250);
		grad.addColorStop(0, "#0b0d12");
		grad.addColorStop(1, "#150a10");
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, 1e3, 1250);
		ctx.strokeStyle = "rgba(255,255,255,0.15)";
		ctx.lineWidth = 3;
		ctx.strokeRect(40, 40, 920, 1170);
		ctx.textAlign = "center";
		ctx.fillStyle = "#ffffff";
		ctx.font = "bold 44px sans-serif";
		ctx.fillText("WHAT'S YOUR FUTURE SCORE?", 500, 200);
		ctx.fillStyle = "#ff3b47";
		ctx.font = "bold 190px sans-serif";
		ctx.fillText(`${score}`, 500, 460);
		ctx.fillStyle = "#9db4ff";
		ctx.font = "36px sans-serif";
		ctx.fillText("/ 100", 500, 520);
		ctx.fillStyle = "#ffffff";
		ctx.font = "bold 64px sans-serif";
		ctx.fillText(`${profile.emoji} ${profile.name.toUpperCase()}`, 500, 680);
		ctx.fillStyle = "#4fa3ff";
		ctx.font = "bold 46px sans-serif";
		ctx.fillText(`${match}% MATCH`, 500, 760);
		ctx.fillStyle = "rgba(255,255,255,0.7)";
		ctx.font = "italic 32px sans-serif";
		ctx.fillText("Your interests. Your skills.", 500, 880);
		ctx.fillText("Your possible future.", 500, 930);
		ctx.strokeStyle = "rgba(255,255,255,0.25)";
		ctx.strokeRect(340, 1e3, 320, 130);
		ctx.fillStyle = "rgba(255,255,255,0.45)";
		ctx.font = "26px sans-serif";
		ctx.fillText("YOUR INSTITUTION LOGO", 500, 1072);
		const link = document.createElement("a");
		link.download = `future-score-${score}.png`;
		link.href = canvas.toDataURL("image/png");
		link.click();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
				children: "Share My Future 🚀"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: cardRef,
				className: "glass glow-secondary rounded-3xl p-8 text-center",
				"aria-label": "Result card preview",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs uppercase tracking-[0.3em] text-muted-foreground",
						children: "What's Your Future Score?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-6xl font-black text-gradient",
						children: score
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "/ 100"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-display text-2xl font-bold",
						children: [
							profile.emoji,
							" ",
							profile.name.toUpperCase()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-secondary",
						children: [match, "% MATCH"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm italic text-muted-foreground",
						children: "“Your interests. Your skills. Your possible future.”"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-6 flex h-16 w-44 items-center justify-center rounded-xl border border-dashed border-border text-[10px] uppercase tracking-widest text-muted-foreground",
						children: "Institution logo"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://wa.me/?text=${encodeURIComponent(text)}`,
						target: "_blank",
						rel: "noreferrer",
						className: "glass inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 font-medium transition-colors hover:border-secondary/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " WhatsApp"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: copy,
						className: "glass inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 font-medium transition-colors hover:border-secondary/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }),
							" ",
							copied ? "Copied!" : "Copy Result"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: download,
						className: "glass inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 font-medium transition-colors hover:border-secondary/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download Card"]
					})
				]
			})
		]
	});
}
function InstitutionCTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "glass rounded-3xl p-6 text-center sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-black uppercase tracking-wide sm:text-3xl",
				children: "Want to build these skills?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted-foreground",
				children: "Your future starts with the skills you build today."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
				children: "Explore Our Programs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: programs.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 14
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: { once: true },
					transition: { delay: i * .06 },
					className: "glass flex items-center gap-3 rounded-2xl px-4 py-4 text-left transition-colors hover:border-primary/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl",
						children: p.emoji
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: p.label
					})]
				}, p.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col items-center justify-center gap-6 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#talk",
					className: "glow-primary inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 font-display font-bold uppercase tracking-widest text-primary-foreground transition-colors hover:bg-primary/90",
					children: ["Talk To Our Team ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "h-4 w-4" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-24 w-24 items-center justify-center rounded-xl border border-dashed border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
							className: "h-10 w-10 text-muted-foreground",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-xs uppercase tracking-[0.25em] text-muted-foreground",
						children: [
							"Scan to",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"learn more"
						]
					})]
				})]
			})
		]
	});
}
function useCountUp(target) {
	const [value, setValue] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		const total = 45;
		const id = window.setInterval(() => {
			frame += 1;
			setValue(Math.round(target * frame / total));
			if (frame >= total) window.clearInterval(id);
		}, 24);
		return () => window.clearInterval(id);
	}, [target]);
	return value;
}
function ResultScreen({ result, player, onRestart }) {
	const top = profiles[result.top];
	const topPercent = result.percentages[result.top];
	const animatedScore = useCountUp(result.futureScore);
	const others = result.ranked.filter((r) => r.id !== result.top);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto w-full max-w-3xl px-5 py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .94
			},
			animate: {
				opacity: 1,
				scale: 1
			},
			transition: { duration: .5 },
			className: "glass glow-primary rounded-3xl p-8 text-center sm:p-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-[0.35em] text-muted-foreground",
					children: "🚀 Your Future Score"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-7xl font-black text-gradient sm:text-8xl",
					children: animatedScore
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "/ 100"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-9 border-t border-border pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs uppercase tracking-[0.35em] text-muted-foreground",
							children: "Your Strongest Profile"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-display text-3xl font-black uppercase sm:text-5xl",
							children: [
								top.emoji,
								" ",
								top.name
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 font-display text-xl font-bold text-secondary",
							children: [topPercent, "% Match"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-5 max-w-xl text-muted-foreground",
							children: top.description
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-xs text-muted-foreground",
					children: "A fun career-discovery score based on your choices — not a scientifically validated aptitude test."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid gap-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-sm uppercase tracking-[0.3em] text-muted-foreground",
					children: "Other Matches"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreChart, { ranked: others })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipSection, {
					title: "Your Strengths",
					items: top.strengths
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipSection, {
					title: "You May Enjoy",
					items: top.enjoy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roadmap, { steps: roadmaps[result.top] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerSection, { careers: top.careers }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaderboard, {
					score: result.futureScore,
					profile: result.top,
					player
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareResult, {
					score: result.futureScore,
					profile: top,
					match: topPercent
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstitutionCTA, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg uppercase tracking-[0.25em] text-muted-foreground",
						children: "Next student?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: onRestart,
						className: "glow-secondary mt-4 inline-flex items-center gap-2 rounded-full border border-secondary/50 bg-secondary/10 px-8 py-4 font-display font-bold uppercase tracking-widest transition-colors hover:bg-secondary/20",
						children: ["Play Again ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" })]
					})]
				})
			]
		})]
	});
}
var TONES = {
	click: {
		freq: [420],
		dur: .06,
		type: "square"
	},
	select: {
		freq: [520, 760],
		dur: .1,
		type: "triangle"
	},
	progress: {
		freq: [300],
		dur: .05,
		type: "sine"
	},
	reveal: {
		freq: [
			400,
			600,
			900
		],
		dur: .16,
		type: "sine"
	},
	achievement: {
		freq: [
			520,
			660,
			880,
			1100
		],
		dur: .14,
		type: "triangle"
	}
};
function useSound() {
	const [enabled, setEnabled] = (0, import_react.useState)(false);
	const ctxRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const stored = window.localStorage.getItem("fs_sound");
			if (stored) setEnabled(stored === "on");
		} catch {}
	}, []);
	return {
		enabled,
		toggle: (0, import_react.useCallback)(() => {
			setEnabled((prev) => {
				const next = !prev;
				try {
					window.localStorage.setItem("fs_sound", next ? "on" : "off");
				} catch {}
				return next;
			});
		}, []),
		play: (0, import_react.useCallback)((name) => {
			if (!enabled || typeof window === "undefined") return;
			try {
				const Ctx = window.AudioContext ?? window.webkitAudioContext;
				if (!Ctx) return;
				ctxRef.current ??= new Ctx();
				const ctx = ctxRef.current;
				if (ctx.state === "suspended") ctx.resume();
				const tone = TONES[name];
				tone.freq.forEach((f, i) => {
					const osc = ctx.createOscillator();
					const gain = ctx.createGain();
					osc.type = tone.type;
					osc.frequency.value = f;
					const start = ctx.currentTime + i * tone.dur * .7;
					gain.gain.setValueAtTime(1e-4, start);
					gain.gain.exponentialRampToValueAtTime(.12, start + .01);
					gain.gain.exponentialRampToValueAtTime(1e-4, start + tone.dur);
					osc.connect(gain).connect(ctx.destination);
					osc.start(start);
					osc.stop(start + tone.dur + .02);
				});
			} catch {}
		}, [enabled])
	};
}
var IDLE_MS = 6e4;
function FutureScoreGame() {
	const [phase, setPhase] = (0, import_react.useState)("landing");
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [player, setPlayer] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [stallMode, setStallMode] = (0, import_react.useState)(false);
	const [idleWarning, setIdleWarning] = (0, import_react.useState)(false);
	const { enabled, toggle, play } = useSound();
	const idleTimer = (0, import_react.useRef)(null);
	const reset = (0, import_react.useCallback)(() => {
		setAnswers({});
		setPlayer(null);
		setResult(null);
		setIdleWarning(false);
		setPhase("landing");
		window.scrollTo({ top: 0 });
	}, []);
	(0, import_react.useEffect)(() => {
		const schedule = () => {
			if (idleTimer.current) window.clearTimeout(idleTimer.current);
			setIdleWarning(false);
			if (phase === "landing") return;
			idleTimer.current = window.setTimeout(() => {
				setIdleWarning(true);
				window.setTimeout(reset, 2500);
			}, IDLE_MS);
		};
		const events = [
			"pointerdown",
			"keydown",
			"touchstart",
			"scroll",
			"mousemove"
		];
		events.forEach((e) => window.addEventListener(e, schedule, { passive: true }));
		schedule();
		return () => {
			events.forEach((e) => window.removeEventListener(e, schedule));
			if (idleTimer.current) window.clearTimeout(idleTimer.current);
		};
	}, [phase, reset]);
	const toggleStall = async () => {
		play("click");
		try {
			if (!document.fullscreenElement) {
				await document.documentElement.requestFullscreen();
				setStallMode(true);
			} else {
				await document.exitFullscreen();
				setStallMode(false);
			}
		} catch {
			setStallMode((s) => !s);
		}
	};
	const handleAnswer = (questionId, key) => setAnswers((prev) => ({
		...prev,
		[questionId]: key
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: stallMode ? "select-none text-[1.05rem]" : "",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FuturisticBackground, { intensity: phase === "landing" ? "high" : "low" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed right-4 top-4 z-50 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						toggle();
						play("click");
					},
					"aria-label": enabled ? "Turn sound off" : "Turn sound on",
					className: "glass flex h-11 w-11 items-center justify-center rounded-full transition-colors hover:border-secondary/60",
					children: enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: toggleStall,
					"aria-label": stallMode ? "Exit stall mode" : "Enter stall mode",
					className: "glass flex items-center gap-2 rounded-full px-4 text-xs font-display uppercase tracking-widest transition-colors hover:border-primary/60",
					children: [stallMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "\n"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatePresence, {
				mode: "wait",
				children: [
					phase === "landing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						exit: {
							opacity: 0,
							scale: 1.03
						},
						transition: { duration: .3 },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingScreen, { onStart: (p) => {
							play("click");
							setPlayer(p);
							setAnswers({});
							setResult(null);
							setPhase("game");
						} })
					}, "landing"),
					phase === "game" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: { opacity: 0 },
						animate: { opacity: 1 },
						exit: { opacity: 0 },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameScreen, {
							answers,
							onAnswer: handleAnswer,
							onSelectSound: () => play("select"),
							onComplete: () => {
								play("progress");
								setPhase("calculating");
							}
						})
					}, "game"),
					phase === "calculating" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: { opacity: 0 },
						animate: { opacity: 1 },
						exit: { opacity: 0 },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalculatingScreen, { onDone: () => {
							setResult(calculateResult(answers));
							play("reveal");
							setPhase("result");
						} })
					}, "calc"),
					phase === "result" && result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultScreen, {
							result,
							player,
							onRestart: () => {
								play("achievement");
								reset();
							}
						})
					}, "result")
				]
			}),
			idleWarning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-background/85 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-black uppercase tracking-widest text-gradient",
					children: "Ready for your future?"
				})
			})
		]
	});
}
//#endregion
export { FutureScoreGame as component };
