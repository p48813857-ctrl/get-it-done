//#region node_modules/.nitro/vite/services/ssr/assets/card-mm-anim-DjQetQza.js
var card_mm_anim_default = "/assets/card-mm-anim-Bd-FrTBr.jpg";
//#endregion
export { card_mm_anim_default as t };
