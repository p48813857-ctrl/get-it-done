import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as submitApplication } from "./php-api-BHg0UHqS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ug-programs-CAHAfbmi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./ug-programs-en6V180C.mjs");
var Route = createFileRoute("/ug-programs")({
	head: () => ({ meta: [{ title: "UG / PG Programs — Skill Ai School of Business" }, {
		name: "description",
		content: "Undergraduate (BCA, BBA, BCom, BA) and Postgraduate (MBA, MCA, MCom, MA) programs at Skill Ai — built for the AI era."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function ApplyModal({ program, onClose, variant = "default" }) {
	const [done, setDone] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [sendError, setSendError] = (0, import_react.useState)("");
	const isMM = variant === "multimedia";
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		city: "",
		interest: "",
		level: "",
		portfolio: "",
		tools: "",
		project: "",
		why: ""
	});
	const update = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	const onSubmit = async (e) => {
		e.preventDefault();
		setSending(true);
		setSendError("");
		const res = await submitApplication({
			form_type: isMM ? "multimedia-program" : "ug-pg-program",
			program,
			name: form.name,
			email: form.email,
			phone: form.phone,
			city: form.city,
			goal: isMM ? form.project : form.why,
			extra: isMM ? {
				interest: form.interest,
				level: form.level,
				portfolio: form.portfolio,
				tools: form.tools
			} : { why: form.why }
		});
		setSending(false);
		if (res.ok || res.offline) setDone(true);
		else setSendError(res.error ?? "Could not submit. Please try again.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border/60 bg-surface p-7 max-h-[90vh] overflow-y-auto",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-2xl font-black",
					children: ["Apply — ", program]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "text-2xl text-muted-foreground hover:text-foreground",
					children: "×"
				})]
			}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-lime text-lime-foreground text-2xl",
						children: "✓"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-semibold",
						children: "Application received!"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Our team will reach out within 24 hrs."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-5 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.name,
						onChange: update("name"),
						placeholder: "Full name",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.email,
						onChange: update("email"),
						type: "email",
						placeholder: "Email",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.phone,
						onChange: update("phone"),
						placeholder: "Phone",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form.city,
						onChange: update("city"),
						placeholder: "City",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					isMM ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							required: true,
							value: form.interest,
							onChange: update("interest"),
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Creative area of interest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Graphic Design & Branding" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Video Editing & VFX" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "2D / 3D Animation" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Film Direction & Cinematography" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Performance & Social Media Marketing" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							required: true,
							value: form.level,
							onChange: update("level"),
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Your current level"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Absolute beginner" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hobbyist / self-taught" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "1–2 years experience" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Working professional" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: form.portfolio,
							onChange: update("portfolio"),
							placeholder: "Portfolio / Instagram / showreel link (optional)",
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: form.tools,
							onChange: update("tools"),
							placeholder: "Tools you already use (e.g. Photoshop, Premiere)",
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							required: true,
							value: form.project,
							onChange: update("project"),
							placeholder: "Tell us about a project or story you'd love to create.",
							rows: 3,
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: form.why,
						onChange: update("why"),
						placeholder: "Why this program?",
						rows: 3,
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					sendError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: sendError
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: sending,
						className: "rounded-full bg-lime py-3 font-bold text-lime-foreground hover:scale-[1.02] transition-transform disabled:opacity-60",
						children: sending ? "Sending…" : "Submit application"
					})
				]
			})]
		})
	});
}
//#endregion
export { Route as n, ApplyModal as t };
