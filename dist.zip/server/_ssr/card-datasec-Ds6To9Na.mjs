//#region node_modules/.nitro/vite/services/ssr/assets/card-datasec-Ds6To9Na.js
var card_datasec_default = "/assets/card-datasec-BluUat0n.jpg";
//#endregion
export { card_datasec_default as t };
