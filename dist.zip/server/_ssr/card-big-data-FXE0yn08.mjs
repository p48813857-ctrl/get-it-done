//#region node_modules/.nitro/vite/services/ssr/assets/card-big-data-FXE0yn08.js
var card_big_data_default = "/assets/card-big-data-Bpj8CIvo.jpg";
//#endregion
export { card_big_data_default as t };
