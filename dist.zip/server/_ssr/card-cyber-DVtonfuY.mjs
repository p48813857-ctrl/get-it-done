//#region node_modules/.nitro/vite/services/ssr/assets/card-cyber-DVtonfuY.js
var card_cyber_default = "/assets/card-cyber-PTqDKZit.jpg";
//#endregion
export { card_cyber_default as t };
