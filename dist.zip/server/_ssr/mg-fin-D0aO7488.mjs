//#region node_modules/.nitro/vite/services/ssr/assets/mg-fin-D0aO7488.js
var mg_fin_default = "/assets/mg-fin-Dk_yZD5L.jpg";
//#endregion
export { mg_fin_default as t };
