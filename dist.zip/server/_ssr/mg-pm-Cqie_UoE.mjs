//#region node_modules/.nitro/vite/services/ssr/assets/mg-pm-Cqie_UoE.js
var mg_pm_default = "/assets/mg-pm-C2dIXUV8.jpg";
//#endregion
export { mg_pm_default as t };
