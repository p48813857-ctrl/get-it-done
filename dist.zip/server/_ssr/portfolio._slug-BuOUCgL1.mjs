import { A as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio._slug-BuOUCgL1.js
var manya_png_asset_default = {
	version: 1,
	asset_id: "b348487a-947b-47f9-8b20-d0613ebe2af4",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/b348487a-947b-47f9-8b20-d0613ebe2af4/manya-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/b348487a-947b-47f9-8b20-d0613ebe2af4/manya-cut.png",
	original_filename: "manya-cut.png",
	size: 150529,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var megha_png_asset_default = {
	version: 1,
	asset_id: "a3a6778e-cee4-4ec9-9876-891635337326",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/a3a6778e-cee4-4ec9-9876-891635337326/megha-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/a3a6778e-cee4-4ec9-9876-891635337326/megha-cut.png",
	original_filename: "megha-cut.png",
	size: 188659,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var priyanka_png_asset_default = {
	version: 1,
	asset_id: "4bbc0142-3337-4adb-85cf-60e547be01ea",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/4bbc0142-3337-4adb-85cf-60e547be01ea/priyanka-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/4bbc0142-3337-4adb-85cf-60e547be01ea/priyanka-cut.png",
	original_filename: "priyanka-cut.png",
	size: 290126,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var sharanya_png_asset_default = {
	version: 1,
	asset_id: "6621c9d9-dda1-4cbb-ac17-c15dff2cb7f4",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/6621c9d9-dda1-4cbb-ac17-c15dff2cb7f4/sharanya-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/6621c9d9-dda1-4cbb-ac17-c15dff2cb7f4/sharanya-cut.png",
	original_filename: "sharanya-cut.png",
	size: 231029,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var suprabha_png_asset_default = {
	version: 1,
	asset_id: "f4b005bb-8d5b-41c3-a372-c72ec46dde8b",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/f4b005bb-8d5b-41c3-a372-c72ec46dde8b/suprabha-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/f4b005bb-8d5b-41c3-a372-c72ec46dde8b/suprabha-cut.png",
	original_filename: "suprabha-cut.png",
	size: 278924,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var disha_png_asset_default = {
	version: 1,
	asset_id: "110c41b1-79c0-4150-aa11-7256521368a4",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/110c41b1-79c0-4150-aa11-7256521368a4/disha-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/110c41b1-79c0-4150-aa11-7256521368a4/disha-cut.png",
	original_filename: "disha-cut.png",
	size: 123517,
	content_type: "image/png",
	created_at: "2026-07-31T06:11:48Z"
};
var anwitha_png_asset_default = {
	version: 1,
	asset_id: "8506d744-caa0-414c-98b5-6937b8f9c37e",
	project_id: "6727995d-f8ae-4355-97f9-a04b70b1a4c3",
	url: "/__l5e/assets-v1/8506d744-caa0-414c-98b5-6937b8f9c37e/anwitha-cut.png",
	r2_key: "a/v1/6727995d-f8ae-4355-97f9-a04b70b1a4c3/8506d744-caa0-414c-98b5-6937b8f9c37e/anwitha-cut.png",
	original_filename: "anwitha-cut.png",
	size: 248280,
	content_type: "image/png",
	created_at: "2026-07-31T06:10:03Z"
};
var $$splitComponentImporter = () => import("./portfolio._slug-BpHUwV-m.mjs");
var $$splitErrorComponentImporter = () => import("./portfolio._slug-BFa2MraC.mjs");
var $$splitNotFoundComponentImporter = () => import("./portfolio._slug-COvarQIo.mjs");
var priyankaPhoto = priyanka_png_asset_default.url;
var sharanyaPhoto = sharanya_png_asset_default.url;
var suprabhaPhoto = suprabha_png_asset_default.url;
var portfolios = {
	manya: {
		name: "Manya M",
		role: "Project Lead",
		photo: manya_png_asset_default.url,
		tagline: "Leading with purpose. Building with research.",
		expertise: [
			"Product Research",
			"LMS Research",
			"Requirements Gathering",
			"Project Documentation",
			"Artificial Intelligence",
			"Data Analytics"
		],
		skills: [
			"Market & Competitor Research",
			"Requirement Gathering",
			"Data Analysis & Reporting",
			"Presentation & Documentation",
			"Leadership & Team Coordination",
			"Communication & Public Speaking",
			"Python, Java, C",
			"HTML, CSS, SQL"
		],
		skillLevels: [
			{
				name: "Market & Competitor Research",
				value: 92
			},
			{
				name: "Requirement Gathering",
				value: 90
			},
			{
				name: "Project Documentation",
				value: 90
			},
			{
				name: "Leadership & Team Coordination",
				value: 88
			},
			{
				name: "Data Analysis & Reporting",
				value: 86
			},
			{
				name: "Communication & Public Speaking",
				value: 85
			},
			{
				name: "Python / Java / C",
				value: 80
			}
		],
		tools: [
			"Python",
			"Java",
			"C",
			"SQL",
			"HTML",
			"CSS",
			"MS Excel",
			"Power BI",
			"Google Workspace",
			"Notion",
			"Jira",
			"ChatGPT"
		],
		talents: [
			"Leadership & organization",
			"Analytical problem-solving",
			"Presentation abilities",
			"Research-driven decisions",
			"Fast technology learner",
			"Event & team management"
		],
		qualifications: [{
			title: "BCA — Final Year Graduate",
			sub: "Sridevi College of Information Science, Mangalore University"
		}, {
			title: "AI, ML & Big Data Analytics Certification",
			sub: "Pursued alongside BCA"
		}],
		about: "I am a passionate Project Leader with strong leadership, communication, and problem solving skills. I enjoy collaborating with teams, managing projects, and turning ideas into practical solutions while continuously learning and growing as a professional.",
		vision: "My vision is to lead with purpose, inspire teamwork, and contribute innovative ideas that drive successful projects and create long-term value for the company while growing alongside the organization.",
		currentRole: "Project Lead — leading cross-functional teams through research, requirements gathering, and project documentation to deliver practical, data-informed solutions.",
		standOut: [
			"Research-driven mindset backed by hands-on AI, ML & Big Data Analytics training",
			"Bridges technical skills (Python, Java, C, SQL, HTML/CSS) with business and product research",
			"Turns complex requirements into clear, actionable documentation",
			"Natural leader who enjoys organizing teams and events toward a shared goal"
		]
	},
	megha: {
		name: "Megha Shree",
		role: "Digital Marketing Executive",
		photo: megha_png_asset_default.url,
		tagline: "SEO-first growth. Data-driven campaigns. AI-accelerated marketing.",
		expertise: [
			"Search Engine Optimization (SEO)",
			"Google Ads & Paid Search",
			"Meta Ads & Paid Social",
			"Social Media Marketing",
			"Content Strategy & Creative Design",
			"Video Editing & Motion Content",
			"AI-Powered Marketing"
		],
		skills: [
			"Search Engine Optimization (SEO)",
			"Canva / Design Execution",
			"Social Media Marketing",
			"Google Ads",
			"Content Marketing",
			"Meta Ads",
			"AI Tools (ChatGPT, Claude, Gemini)",
			"Google Analytics & Search Console"
		],
		skillLevels: [
			{
				name: "Search Engine Optimization (SEO)",
				value: 92
			},
			{
				name: "Canva / Design Execution",
				value: 92
			},
			{
				name: "Social Media Marketing",
				value: 90
			},
			{
				name: "Google Ads",
				value: 88
			},
			{
				name: "Content Marketing",
				value: 87
			},
			{
				name: "Meta Ads",
				value: 85
			},
			{
				name: "AI Tools (ChatGPT, Claude, Gemini)",
				value: 85
			}
		],
		tools: [
			"Google Ads",
			"Google Analytics",
			"Google Search Console",
			"Meta Business Suite",
			"Canva",
			"Adobe Photoshop",
			"Adobe Illustrator",
			"Adobe Premiere Pro",
			"CapCut",
			"ChatGPT",
			"Claude",
			"Gemini"
		],
		talents: [
			"Keyword research & on-page optimisation",
			"Technical SEO & Core Web Vitals",
			"Campaign testing & performance analysis",
			"Digital branding & creative execution",
			"Video editing (CapCut, Premiere Pro)",
			"Mentoring interns on live projects"
		],
		qualifications: [{
			title: "Bachelor of Commerce (B.Com)",
			sub: "Government First Grade College for Women, Balmatta, Mangalore"
		}, {
			title: "Professional Diploma in Digital Marketing (PDM)",
			sub: "Sree Sankaracharya Institute of Advanced Skill, Mangalore — SEO, paid media, content strategy"
		}],
		about: "Meghashree is a Digital Marketing Executive with a strong SEO-first approach to growth — she treats organic search as the foundation that every other channel builds on, structuring keyword research, on-page optimisation, technical SEO, and content strategy around long-term, sustainable visibility rather than short-term ranking spikes. Around that SEO core, she runs Google Ads and Meta Ads campaigns engineered to convert search and social intent into qualified leads, and produces the social and creative output that keeps a brand consistent across every touchpoint. She has folded AI tools — ChatGPT, Claude, and Gemini — into her SEO and content workflow to accelerate research, ideation, copywriting, and campaign analysis, without losing the strategic judgement that comes from hands-on marketing experience. Beyond her own campaigns, she mentors interns through live SEO and marketing projects rather than theoretical exercises.",
		vision: "To create innovative digital marketing strategies that strengthen brand presence, drive business growth, and inspire aspiring digital marketers through practical learning, creativity, and continuous innovation.",
		currentRole: "Digital Marketing Executive — owning SEO end-to-end (keyword strategy, on-page, technical and content SEO), planning and optimising Google Ads for lead generation, managing Meta Ads across Facebook and Instagram, developing social media content strategies, designing campaign creatives in Canva, building brand awareness across paid and organic channels, mentoring internship students on live projects, and continuously analysing campaign performance data.",
		standOut: [
			"SEO as a core specialisation — keyword, on-page, technical, content, local, and analytics",
			"Full-funnel marketer across paid search, paid social, organic, and creative",
			"Tooling depth: Google Ads, Analytics, Search Console, Meta Business Suite, Canva, Photoshop, Illustrator, Premiere Pro, CapCut",
			"Applied AI fluency with ChatGPT, Claude, and Gemini across research, copy, and analysis",
			"Mentors interns through real, live marketing projects"
		]
	},
	priyanka: {
		name: "Priyanka K Poojary",
		role: "AI EXPERT & TRAINER",
		photo: priyankaPhoto,
		tagline: "Empowering minds. Building skills. Driving futures.",
		expertise: [
			"Full-Stack Web Development (MERN)",
			"Data Science & Analytics",
			"Database Management",
			"Machine Learning",
			"Data Visualization",
			"Teaching & Mentoring"
		],
		skills: [
			"Python",
			"React.js & Node.js",
			"MongoDB & MySQL",
			"Power BI & Tableau",
			"Excel & Exploratory Data Analysis",
			"HTML & CSS",
			"Software Engineering & QA",
			"Business Process Understanding"
		],
		skillLevels: [
			{
				name: "Python",
				value: 92
			},
			{
				name: "React.js & Node.js",
				value: 90
			},
			{
				name: "MongoDB & MySQL",
				value: 88
			},
			{
				name: "Power BI & Tableau",
				value: 86
			},
			{
				name: "Exploratory Data Analysis",
				value: 85
			},
			{
				name: "HTML & CSS",
				value: 90
			},
			{
				name: "Teaching & Mentoring",
				value: 92
			}
		],
		tools: [
			"Python",
			"React.js",
			"Node.js",
			"Express",
			"MongoDB",
			"MySQL",
			"Power BI",
			"Tableau",
			"Excel",
			"Git & GitHub",
			"VS Code",
			"AWS"
		],
		talents: [
			"Clear communication & presentation",
			"Leadership & team collaboration",
			"Problem solving",
			"Time management",
			"Quick learner",
			"Teaching complex topics simply"
		],
		qualifications: [
			{
				title: "Master of Computer Applications (MCA)",
				sub: "Shree Devi Institute of Technology"
			},
			{
				title: "Bachelor of Computer Applications (BCA)",
				sub: "St. Aloysius (Deemed to be University)"
			},
			{
				title: "AWS Cloud Practitioner Essentials",
				sub: "Certification"
			},
			{
				title: "Data Analytics & Visualization Job Simulation",
				sub: "Certification"
			}
		],
		about: "MCA graduate with hands-on experience in Full-Stack Web Development (MERN Stack), Data Analysis, and Database Management. Strong foundation in software engineering, analytics, quality assurance, and business process understanding — currently focused on teaching, mentoring, and turning real-world problems into working products.",
		vision: "To empower individuals with industry-relevant skills and help them achieve their career goals, while continuously growing as a developer, analyst, and mentor.",
		currentRole: "AI EXPERT & TRAINER — building MERN applications, analyzing data with Python/SQL/Power BI, and mentoring students on real-world projects.",
		standOut: [
			"20+ projects guided & delivered end-to-end",
			"100+ students trained and empowered in modern tech",
			"Comfortable across the full stack: frontend, backend, database, analytics",
			"Committed to practical knowledge, innovation, and learner-first teaching"
		]
	},
	sharanya: {
		name: "Sharanya V K",
		role: "Human Resources & Management Officer",
		photo: sharanyaPhoto,
		tagline: "Building people. Developing organizations. Driving performance.",
		expertise: [
			"HR Management",
			"Recruitment & Selection",
			"Payroll Management",
			"Employee Documentation",
			"Attendance & Records",
			"Administrative Coordination"
		],
		skills: [
			"HR Management",
			"Recruitment & Hiring",
			"Payroll Processing",
			"Employee Documentation",
			"MS Excel & MS Word",
			"Power BI",
			"Adobe Photoshop & Illustrator",
			"HR Reporting"
		],
		skillLevels: [
			{
				name: "HR Management",
				value: 92
			},
			{
				name: "Recruitment & Hiring",
				value: 90
			},
			{
				name: "Payroll Processing",
				value: 88
			},
			{
				name: "Employee Documentation",
				value: 90
			},
			{
				name: "MS Excel & MS Word",
				value: 88
			},
			{
				name: "Power BI Reporting",
				value: 80
			},
			{
				name: "Photoshop & Illustrator",
				value: 78
			}
		],
		tools: [
			"MS Excel",
			"MS Word",
			"Power BI",
			"Google Workspace",
			"HRMS Portals",
			"Payroll Software",
			"Adobe Photoshop",
			"Adobe Illustrator",
			"Canva",
			"LinkedIn Recruiter"
		],
		talents: [
			"Strong communication",
			"Team leadership",
			"Decision-making",
			"Creativity",
			"Problem-solving under pressure",
			"Quick learner with initiative"
		],
		qualifications: [
			{
				title: "Master of Arts in Economics",
				sub: "Kannur University"
			},
			{
				title: "Bachelor of Arts in Economics",
				sub: "Kannur University"
			},
			{
				title: "Diploma in Digital Marketing & Graphic Design",
				sub: "GTEC Education"
			}
		],
		about: "I am a Human Resources and Management Officer passionate about creating efficient HR systems that enhance employee performance and organizational growth. With practical experience in recruitment, payroll processing, HR documentation, attendance, and administrative coordination, I focus on delivering structured HR operations that support business objectives.",
		vision: "To build a successful and rewarding career in Human Resources and Management by continuously developing my professional skills and contributing to effective HR practices, employee development, and organizational growth.",
		currentRole: "HR & Management Officer — handling recruitment, payroll, employee documentation, attendance, and day-to-day HR operations while supporting leadership with reporting and coordination.",
		standOut: [
			"3+ years of learning and HR experience",
			"15+ HR documents & templates created",
			"100+ employee records managed accurately",
			"Combines HR ops with design tools (Photoshop, Illustrator) for branded internal comms"
		]
	},
	suprabha: {
		name: "Suprabha Y",
		role: "CRM Executive",
		photo: suprabhaPhoto,
		tagline: "Building relationships. Creating trust. Driving admissions.",
		expertise: [
			"Customer Relationship Management",
			"Student Counseling",
			"Lead Management",
			"Admissions Support",
			"Customer Handling",
			"Follow-up & Coordination"
		],
		skills: [
			"Communication",
			"CRM Management",
			"Student Counseling",
			"Customer Handling",
			"Teamwork",
			"Problem Solving",
			"Negotiation",
			"Record Keeping"
		],
		skillLevels: [
			{
				name: "Communication",
				value: 94
			},
			{
				name: "CRM Management",
				value: 90
			},
			{
				name: "Student Counseling",
				value: 92
			},
			{
				name: "Customer Handling",
				value: 90
			},
			{
				name: "Negotiation",
				value: 85
			},
			{
				name: "Record Keeping",
				value: 88
			},
			{
				name: "Teamwork",
				value: 90
			}
		],
		tools: [
			"CRM Software",
			"MS Excel",
			"Google Sheets",
			"WhatsApp Business",
			"Email Campaigns",
			"Calling Systems",
			"Google Forms",
			"Canva"
		],
		talents: [
			"Empathy & active listening",
			"Time management",
			"Relationship building",
			"Trust development",
			"Quick learner",
			"Positive, service-first attitude"
		],
		qualifications: [{
			title: "Bachelor's Degree in English",
			sub: "Undergraduate"
		}, {
			title: "CRM & Counseling — On-the-job Training",
			sub: "Sree Sankaracharya Institution"
		}],
		about: "I am Suprabha Y, a passionate CRM Executive with a Bachelor's degree in English. Currently working at Sree Sankaracharya Institution, I handle student enquiries, maintain CRM records, provide career counseling, manage follow-ups, and support the complete admission process.",
		vision: "To become a trusted CRM and counseling professional who builds long-term customer relationships and drives organizational success through empathy, communication, and consistent service excellence.",
		currentRole: "CRM Executive at Sree Sankaracharya Institution — handling student enquiries, maintaining CRM records, providing career counseling, and supporting the end-to-end admission process.",
		standOut: [
			"100+ student enquiries handled professionally",
			"50+ leads managed effectively through the CRM",
			"95% customer satisfaction across counseling interactions",
			"Coordinates smoothly across internal departments for admissions"
		]
	},
	disha: {
		name: "Disha",
		role: "Multimedia Trainer",
		photo: disha_png_asset_default.url,
		tagline: "Inspiring creativity. Building careers.",
		expertise: [
			"Graphic Design",
			"Video Editing",
			"Motion Graphics",
			"Digital Marketing",
			"Social Media Management",
			"Content Creation"
		],
		skills: [
			"Graphic Design",
			"Video Editing",
			"Motion Graphics",
			"Digital Marketing",
			"Social Media Management",
			"Content Creation",
			"Presentation & Communication"
		],
		skillLevels: [
			{
				name: "Graphic Design",
				value: 92
			},
			{
				name: "Video Editing",
				value: 90
			},
			{
				name: "Motion Graphics",
				value: 86
			},
			{
				name: "Digital Marketing",
				value: 85
			},
			{
				name: "Social Media Management",
				value: 88
			},
			{
				name: "Content Creation",
				value: 90
			},
			{
				name: "Presentation & Communication",
				value: 92
			}
		],
		tools: [
			"Adobe Photoshop",
			"Adobe Illustrator",
			"Adobe Premiere Pro",
			"After Effects",
			"Canva",
			"CapCut",
			"Figma",
			"Meta Business Suite",
			"ChatGPT"
		],
		talents: [
			"Creative thinker",
			"Passionate trainer",
			"Student-centric approach",
			"Results driven",
			"Conceptual & practical teaching",
			"Hands-on project mentoring"
		],
		qualifications: [{
			title: "BSc in Computer Science and Mathematics",
			sub: "Undergraduate"
		}, {
			title: "Certified Digital Marketing Course",
			sub: "Certification"
		}],
		about: "Creative Multimedia Trainer passionate about designing, teaching, and inspiring future creatives. Dedicated to delivering industry-relevant training and empowering students with practical skills and creative confidence.",
		vision: "To empower minds to turn creativity into careers by combining creative thinking, hands-on training, and modern digital skills.",
		currentRole: "Multimedia Trainer — training students in industry-relevant multimedia skills, designing creative visuals, producing videos and motion graphics, and guiding learners on digital marketing tools and strategies.",
		standOut: [
			"Blends design, video, and marketing into one practical curriculum",
			"Student-first, project-based teaching approach",
			"Bridges creative craft with digital marketing outcomes",
			"Focused on real career growth, not just tools training"
		]
	},
	anwitha: {
		name: "Anwitha",
		role: "Multimedia Trainer",
		photo: anwitha_png_asset_default.url,
		tagline: "Teaching design that tells a story.",
		expertise: [
			"Graphic Design",
			"Video Editing",
			"Motion Graphics",
			"Visual Storytelling",
			"Content Creation",
			"Social Media Creatives"
		],
		skills: [
			"Adobe Photoshop & Illustrator",
			"Premiere Pro & After Effects",
			"Branding & Layout Design",
			"Short-form Video Production",
			"Creative Direction",
			"Classroom Training & Mentoring",
			"Presentation & Communication"
		],
		skillLevels: [
			{
				name: "Adobe Photoshop & Illustrator",
				value: 92
			},
			{
				name: "Premiere Pro & After Effects",
				value: 88
			},
			{
				name: "Branding & Layout Design",
				value: 90
			},
			{
				name: "Short-form Video Production",
				value: 88
			},
			{
				name: "Creative Direction",
				value: 85
			},
			{
				name: "Classroom Training & Mentoring",
				value: 90
			}
		],
		tools: [
			"Adobe Photoshop",
			"Adobe Illustrator",
			"Adobe Premiere Pro",
			"After Effects",
			"Figma",
			"Canva",
			"CapCut",
			"Blender",
			"ChatGPT"
		],
		talents: [
			"Strong visual sense",
			"Patient, hands-on trainer",
			"Detail-oriented editor",
			"Fast tool learner",
			"Collaborative team player",
			"Deadline-driven delivery"
		],
		qualifications: [{
			title: "Degree in Multimedia / Design",
			sub: "Undergraduate"
		}, {
			title: "Certified Multimedia & Design Training",
			sub: "Certification"
		}],
		about: "Multimedia Trainer with a passion for design, editing, and visual storytelling. I help students build a strong creative foundation and translate ideas into polished, industry-ready work.",
		vision: "To nurture confident creators who can take an idea from concept to a finished, professional-grade visual product.",
		currentRole: "Multimedia Trainer — teaching graphic design, video editing, and motion graphics through practical, project-based sessions.",
		standOut: [
			"Project-first teaching with real client-style briefs",
			"Comfortable across both design and video pipelines",
			"Strong eye for composition, colour, and typography",
			"Mentors students through portfolio building"
		]
	}
};
var Route = createFileRoute("/portfolio/$slug")({
	loader: ({ params }) => {
		const p = portfolios[params.slug];
		if (!p) throw notFound();
		return { portfolio: p };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Portfolio not found — SKILL AI" }, {
			name: "robots",
			content: "noindex"
		}] };
		const { portfolio } = loaderData;
		const title = `${portfolio.name} — ${portfolio.role} | SKILL AI`;
		const desc = `Professional portfolio of ${portfolio.name}, ${portfolio.role} at SKILL AI.`;
		return { meta: [
			{ title },
			{
				name: "description",
				content: desc
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: desc
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
