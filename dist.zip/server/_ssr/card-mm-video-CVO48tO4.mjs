//#region node_modules/.nitro/vite/services/ssr/assets/card-mm-video-CVO48tO4.js
var card_mm_video_default = "/assets/card-mm-video-khtT1hRU.jpg";
//#endregion
export { card_mm_video_default as t };
