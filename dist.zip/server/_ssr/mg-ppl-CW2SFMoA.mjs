//#region node_modules/.nitro/vite/services/ssr/assets/mg-ppl-CW2SFMoA.js
var mg_ppl_default = "/assets/mg-ppl-tXwti5PD.jpg";
//#endregion
export { mg_ppl_default as t };
