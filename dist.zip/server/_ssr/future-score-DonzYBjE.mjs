import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { d as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/future-score-DonzYBjE.js
var import_jsx_runtime = require_jsx_runtime();
function FutureScoreLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fs-scope min-h-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
//#endregion
export { FutureScoreLayout as component };
