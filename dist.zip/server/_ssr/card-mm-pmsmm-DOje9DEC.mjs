//#region node_modules/.nitro/vite/services/ssr/assets/card-mm-pmsmm-DOje9DEC.js
var card_mm_pmsmm_default = "/assets/card-mm-pmsmm-CLp3IqrV.jpg";
//#endregion
export { card_mm_pmsmm_default as t };
