//#region node_modules/.nitro/vite/services/ssr/assets/mg-mkt-BbnM-uVa.js
var mg_mkt_default = "/assets/mg-mkt-CinH8Xja.jpg";
//#endregion
export { mg_mkt_default as t };
