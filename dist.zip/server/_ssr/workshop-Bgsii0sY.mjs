import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as submitApplication } from "./php-api-BHg0UHqS.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { A as Presentation, At as Brain, C as Search, Et as Calendar, Ft as ArrowRight, J as Layers, Nt as BookOpen, Pt as Award, V as Menu, W as MapPin, _t as ClipboardCheck, at as FileSearch, bt as CircleCheck, c as Users, g as Target, gt as ClipboardList, ht as Clock, it as FileText, n as X, nt as GitBranch, q as Lightbulb, r as Wrench, wt as ChartColumn, xt as ChevronDown, z as MessageSquare } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workshop-Bgsii0sY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var navItems = [
	{
		label: "AI",
		chevron: true,
		href: "/ai"
	},
	{
		label: "Multimedia",
		chevron: true,
		href: "/multimedia"
	},
	{
		label: "Management",
		chevron: true,
		href: "/management"
	},
	{
		label: "UG & PG Program",
		chevron: true,
		href: "/ug-programs"
	},
	{
		label: "Online Programs",
		chevron: true,
		href: "/online-programs"
	},
	{
		label: "Workshop",
		chevron: false,
		href: "/workshop"
	}
];
var lifecycle = [
	"Business Problem",
	"Problem Statement",
	"Stakeholder Identification",
	"Requirement Gathering",
	"BRD",
	"FRD",
	"AS-IS Process",
	"Root Cause Analysis",
	"Gap Analysis",
	"TO-BE Process",
	"Use Cases",
	"User Stories",
	"Acceptance Criteria",
	"RTM",
	"UAT",
	"SOP",
	"Final Business Solution"
];
var days = [
	{
		day: "Day 1",
		title: "BA Fundamentals & Problem Solving",
		blocks: [
			{
				heading: "Introduction to Business Analysis",
				items: [
					"What is Business Analysis?",
					"Role of a Business Analyst",
					"BA responsibilities",
					"BA vs Data Analyst",
					"BA role in IT projects",
					"SDLC overview",
					"Agile vs Waterfall",
					"Introduction to Scrum",
					"BA project lifecycle"
				]
			},
			{
				heading: "Problem Identification",
				items: [
					"Business problem identification",
					"Problem statement",
					"Business objectives",
					"Business impact",
					"Scope",
					"Stakeholder identification",
					"Business needs vs requirements"
				]
			},
			{
				heading: "Problem-Solving Techniques",
				items: [
					"5 Whys",
					"Root Cause Analysis",
					"Fishbone Diagram",
					"Gap Analysis",
					"Process analysis",
					"Impact analysis"
				]
			}
		],
		activity: "Problem Statement + Business Objective + Initial Scope"
	},
	{
		day: "Day 2",
		title: "Requirements & BRD",
		blocks: [{
			heading: "Requirement Gathering",
			items: [
				"Elicitation techniques",
				"Stakeholder interviews & workshops",
				"Surveys and observation",
				"Business needs vs requirements",
				"Prioritizing requirements"
			]
		}, {
			heading: "Business Requirements Document (BRD)",
			items: [
				"BRD structure and purpose",
				"Writing clear business requirements",
				"Scope, objectives & success metrics",
				"Assumptions, constraints & risks",
				"Stakeholder review & sign-off"
			]
		}],
		activity: "Requirement List + complete BRD draft"
	},
	{
		day: "Day 3",
		title: "FRD, Process & SOP",
		blocks: [{
			heading: "Functional Requirements Document (FRD)",
			items: [
				"From business to functional requirements",
				"FRD structure & best practices",
				"Functional vs non-functional requirements",
				"Traceability from BRD to FRD"
			]
		}, {
			heading: "Process Mapping & SOP",
			items: [
				"AS-IS process mapping",
				"Root cause & gap analysis",
				"TO-BE process design",
				"Writing Standard Operating Procedures",
				"Process improvement recommendations"
			]
		}],
		activity: "FRD + AS-IS / TO-BE process maps + SOP"
	},
	{
		day: "Day 4",
		title: "Agile, Use Cases & UAT",
		blocks: [{
			heading: "Agile Requirements",
			items: [
				"Use cases & use case diagrams",
				"Writing user stories",
				"Acceptance criteria that work",
				"Backlog & sprint basics"
			]
		}, {
			heading: "Traceability & UAT",
			items: [
				"Requirement Traceability Matrix (RTM)",
				"UAT planning & scenarios",
				"Writing UAT test cases",
				"Defect triage & sign-off"
			]
		}],
		activity: "User Stories + Acceptance Criteria + RTM + UAT scenarios"
	},
	{
		day: "Day 5",
		title: "Tools & Final Project",
		blocks: [{
			heading: "BA Tools Hands-On",
			items: [
				"Excel for analysis",
				"SQL for data queries",
				"Power BI dashboards",
				"Jira & Confluence basics",
				"Visio / Lucidchart / Draw.io"
			]
		}, {
			heading: "Capstone Presentation",
			items: [
				"Assemble the complete BA project",
				"Present your business solution",
				"Get expert feedback",
				"Next steps in your BA career"
			]
		}],
		activity: "Final project presentation + feedback"
	}
];
var deliverables = [
	"Problem Statement",
	"Business Objectives",
	"BRD",
	"FRD",
	"SOP",
	"Use Cases",
	"User Stories",
	"Acceptance Criteria",
	"Requirement Traceability Matrix",
	"UAT Test Scenarios",
	"UAT Test Cases",
	"AS-IS Process",
	"TO-BE Process",
	"Gap Analysis",
	"Root Cause Analysis"
];
var tools = [
	"Excel",
	"SQL",
	"Power BI",
	"Jira",
	"Confluence",
	"Visio / Lucidchart / Draw.io"
];
var audiences = [
	"Students",
	"Fresh Graduates",
	"Aspiring Business Analysts",
	"Working Professionals",
	"Software Developers",
	"QA / Test Engineers",
	"Data Analysts",
	"Project Coordinators",
	"IT Professionals",
	"Career Transitioners"
];
var gains = [
	{
		icon: Search,
		title: "Understand",
		body: "Grasp the business problem and context"
	},
	{
		icon: Brain,
		title: "Analyze",
		body: "Break down requirements and processes"
	},
	{
		icon: FileText,
		title: "Document",
		body: "Create professional BA deliverables"
	},
	{
		icon: MessageSquare,
		title: "Communicate",
		body: "Bridge stakeholders and teams"
	},
	{
		icon: ClipboardCheck,
		title: "Validate",
		body: "Verify through UAT and acceptance criteria"
	},
	{
		icon: Lightbulb,
		title: "Solve",
		body: "Deliver a complete business solution"
	}
];
var overview = [
	{
		day: "Day 1",
		focus: "BA Fundamentals & Problem Solving",
		deliverables: "Problem Statement, Objectives, Scope"
	},
	{
		day: "Day 2",
		focus: "Requirements & BRD",
		deliverables: "Requirement List, BRD"
	},
	{
		day: "Day 3",
		focus: "FRD, Process & SOP",
		deliverables: "FRD, AS-IS, TO-BE, SOP"
	},
	{
		day: "Day 4",
		focus: "Agile, Use Cases & UAT",
		deliverables: "User Stories, Acceptance Criteria, RTM, UAT"
	},
	{
		day: "Day 5",
		focus: "Tools & Final Project",
		deliverables: "Excel, SQL, Power BI, Final Presentation"
	}
];
var lifecycleIcons = [
	Target,
	FileSearch,
	Users,
	ClipboardList,
	BookOpen,
	FileText,
	GitBranch,
	Layers
];
/** Auto-reveal on scroll for any element with class "reveal" */
function useScrollReveal(deps = []) {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal:not(.in-view)");
		const io = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) {
					e.target.classList.add("in-view");
					io.unobserve(e.target);
				}
			});
		}, {
			threshold: .12,
			rootMargin: "0px 0px -40px 0px"
		});
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, deps);
}
function Logo({ size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: skill_ai_logo_default,
		alt: "SkillAI - Learn Skill Get Job",
		className: `${size === "sm" ? "h-8" : "h-10"} w-auto rounded-md bg-white p-1`
	});
}
function WorkshopPage() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [activeDay, setActiveDay] = (0, import_react.useState)(0);
	useScrollReveal([activeDay]);
	const scrollTo = (id) => {
		document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 py-3 sm:py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "hidden items-center gap-4 xl:gap-6 lg:flex",
							children: navItems.map((n) => {
								const isActive = n.href === "/workshop";
								const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative",
									children: [n.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -bottom-1 left-0 h-0.5 bg-lime transition-all duration-300 ${isActive ? "w-full" : "w-0 group-hover:w-full"}` })]
								}), n.chevron && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 opacity-70 transition-transform group-hover:translate-y-0.5" })] });
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: n.href,
									className: `group flex items-center gap-1 text-[13px] whitespace-nowrap transition-colors hover:text-lime ${isActive ? "text-lime font-semibold" : "text-foreground/85"}`,
									children: inner
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "group flex items-center gap-1 text-[13px] whitespace-nowrap text-foreground/85 transition-colors hover:text-lime",
									children: inner
								}) }, n.label);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => scrollTo("apply"),
								className: "hidden sm:inline-flex rounded-full border border-lime px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold tracking-wide text-lime transition-all hover:bg-lime hover:text-lime-foreground hover:scale-105",
								children: "APPLY NOW"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Open menu",
								className: "grid h-10 w-10 place-items-center rounded-md border border-border text-foreground lg:hidden",
								onClick: () => setMenuOpen((v) => !v),
								children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `lg:hidden overflow-hidden border-t border-border transition-[max-height,opacity] duration-300 ${menuOpen ? "max-h-[30rem] opacity-100" : "max-h-0 opacity-0"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "flex flex-col gap-1 px-4 py-3",
						children: [navItems.map((n) => {
							const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [n.label, n.chevron && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-60" })] });
							const cls = "flex w-full items-center justify-between rounded-lg px-3 py-3 text-sm text-foreground/90 transition-colors hover:bg-surface";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.href,
								className: cls,
								onClick: () => setMenuOpen(false),
								children: content
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: cls,
								children: content
							}) }, n.label);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									setMenuOpen(false);
									scrollTo("apply");
								},
								className: "w-full rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground",
								children: "APPLY NOW"
							})
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6 pt-10 pb-16 lg:pt-20 lg:pb-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-20 -left-20 h-72 w-72 rounded-full bg-lime/10 blur-3xl animate-float" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-40 right-0 h-80 w-80 rounded-full bg-mint/10 blur-3xl animate-float-soft" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid items-center gap-10 lg:gap-12 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2 rounded-full border border-lime/40 bg-lime/5 px-4 py-1.5 text-xs sm:text-sm font-semibold tracking-wide text-lime",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), " 1-Week Intensive"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-5 text-[2.25rem] sm:text-5xl lg:text-6xl font-bold leading-[1.05] tracking-tight",
									children: ["Business Analyst ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-lime",
										children: "Workshop"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-lg sm:text-xl font-medium text-foreground/90",
									children: "From Business Problem to Complete Business Solution"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-xl text-sm sm:text-base leading-relaxed text-muted-foreground",
									children: "Practical training across the complete BA lifecycle — BRD, FRD, SOP, Use Cases, UAT & more. One week, one real-world project, complete Business Analyst experience."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 flex flex-wrap gap-x-5 gap-y-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-lime" }),
											label: "5 Days"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-lime" }),
											label: "Hands-on"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-lime" }),
											label: "Mangalore / Online"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-4 w-4 text-lime" }),
											label: "15+ Deliverables"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-7 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => scrollTo("apply"),
										className: "group inline-flex items-center gap-2 rounded-full bg-lime px-5 sm:px-6 py-3 text-xs sm:text-sm font-bold tracking-wider text-lime-foreground transition-all hover:scale-[1.04] hover:shadow-[0_8px_24px_oklch(0.72_0.2_50/0.35)] animate-pulse-glow",
										children: ["START YOUR BA JOURNEY ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => scrollTo("curriculum"),
										className: "group inline-flex items-center gap-2 rounded-full border border-lime px-5 sm:px-6 py-3 text-xs sm:text-sm font-bold tracking-wider text-lime transition-all hover:bg-lime hover:text-lime-foreground hover:scale-[1.04]",
										children: ["VIEW CURRICULUM ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 transition-transform group-hover:translate-y-0.5" })]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal reveal-delay-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hover-lift rounded-3xl border border-border bg-surface p-5 sm:p-7 shadow-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-sm font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "h-4 w-4 text-lime" }), " BA Project Dashboard"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-lime/10 px-3 py-1 text-[11px] font-semibold text-lime",
											children: "Live Project"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5 grid grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl border border-border bg-background p-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: "Deliverables"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-2xl font-bold text-gradient-lime",
													children: "24%"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-2 h-1.5 overflow-hidden rounded-full bg-muted",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[24%] rounded-full bg-lime" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1.5 text-[11px] text-mint",
													children: "↑ Completion rate"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl border border-border bg-background p-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: "Stakeholders"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-2xl font-bold text-gradient-lime",
													children: "45"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-2 flex -space-x-1.5",
													children: [
														0,
														1,
														2,
														3
													].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-5 w-5 rounded-full border border-background bg-surface-2" }, i))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1.5 text-[11px] text-mint",
													children: "↑ Identified"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 rounded-2xl border border-border bg-background p-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs text-muted-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Requirements by Day" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "UAT Progress 9%" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-3 flex h-16 items-end gap-1.5",
												children: [
													35,
													55,
													40,
													70,
													60,
													85,
													95
												].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex-1 rounded-t-md bg-lime/25 transition-colors hover:bg-lime/50",
													style: { height: `${h}%` }
												}, i))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5 flex justify-between text-[10px] text-muted-foreground",
												children: [
													"D1",
													"D2",
													"D3",
													"D4",
													"D5",
													"D6",
													"D7"
												].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex-1 text-center",
													children: d
												}, d))
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 flex flex-wrap gap-2",
										children: [
											"BRD",
											"FRD",
											"RTM",
											"UAT"
										].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full border border-lime/40 bg-lime/5 px-3 py-1 text-[11px] font-semibold text-lime",
											children: t
										}, t))
									})
								]
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-surface/40 py-16 sm:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
							children: "Project Roadmap"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
							children: "The Complete BA Lifecycle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mt-4 max-w-2xl text-sm sm:text-base text-muted-foreground",
							children: "Follow the journey from business problem to final solution — every step a Business Analyst owns in a real project."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-3 sm:gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
							children: lifecycle.map((step, i) => {
								const Icon = lifecycleIcons[i % lifecycleIcons.length];
								const isLast = i === lifecycle.length - 1;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `reveal reveal-delay-${i % 4 + 1} hover-lift flex items-start gap-3 rounded-2xl border p-4 ${isLast ? "border-lime/60 bg-lime/10 sm:col-span-2 md:col-span-1" : "border-border bg-background hover:border-lime/50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `grid h-9 w-9 shrink-0 place-items-center rounded-xl ${isLast ? "bg-lime text-lime-foreground" : "bg-lime/10 text-lime"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] font-semibold uppercase tracking-widest text-muted-foreground",
										children: ["Step ", i + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `mt-0.5 text-sm font-semibold ${isLast ? "text-lime" : ""}`,
										children: step
									})] })]
								}, step);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal mt-10 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-lg sm:text-xl font-bold text-gradient-lime",
								children: "Build. Analyze. Document. Solve."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "One Week. One Real-World Project. Complete Business Analyst Experience."
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "curriculum",
				className: "mx-auto max-w-7xl px-4 sm:px-6 py-20 sm:py-24 scroll-mt-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
						children: "5-Day Curriculum"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
						children: "Day-by-Day Workshop Breakdown"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "reveal mt-4 max-w-2xl text-sm sm:text-base text-muted-foreground",
						children: "Each day builds on the last — from fundamentals to a complete, presentation-ready BA project."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal mt-8 flex flex-wrap gap-2",
						children: days.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setActiveDay(i),
							className: `rounded-full px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold transition-all ${activeDay === i ? "bg-lime text-lime-foreground shadow-[0_6px_18px_oklch(0.72_0.2_50/0.35)]" : "border border-border bg-surface text-foreground/80 hover:border-lime/50 hover:text-lime"}`,
							children: d.day
						}, d.day))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 rounded-3xl border border-border bg-surface p-6 sm:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-lime/10 px-3.5 py-1.5 text-xs font-bold tracking-widest text-lime",
								children: days[activeDay].day.toUpperCase()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl sm:text-2xl font-bold",
								children: days[activeDay].title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 grid gap-5 sm:gap-6 md:grid-cols-2 lg:grid-cols-3",
							children: [days[activeDay].blocks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hover-lift rounded-2xl border border-border bg-background p-5 hover:border-lime/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-semibold text-lime",
									children: b.heading
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 space-y-2",
									children: b.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2 text-sm text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-mint" }), item]
									}, item))
								})]
							}, b.heading)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hover-lift rounded-2xl border border-lime/40 bg-lime/5 p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sm font-semibold text-lime",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presentation, { className: "h-4 w-4" }), " Practical Activity"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-foreground/90",
									children: days[activeDay].activity
								})]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-surface/40 py-16 sm:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
							children: "Workshop Deliverables"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
							children: "What You'll Create"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mt-4 max-w-2xl text-sm sm:text-base text-muted-foreground",
							children: "By the end of the workshop, you'll have practical experience producing these professional BA documents and tools."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5",
							children: deliverables.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `reveal reveal-delay-${i % 5 + 1} hover-lift flex items-center gap-2.5 rounded-2xl border border-border bg-background p-4 hover:border-lime/50`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4 shrink-0 text-lime" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs sm:text-sm font-medium",
									children: d
								})]
							}, d))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal mt-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-semibold text-lime",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "h-4 w-4" }), " Tools Exposure"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-wrap gap-2.5",
								children: tools.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-lime/40 bg-lime/5 px-4 py-2 text-xs sm:text-sm font-semibold text-lime transition-all hover:bg-lime/15 hover:scale-105",
									children: t
								}, t))
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 py-20 sm:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-14 lg:gap-16 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
							children: "Who Should Attend?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
							children: "Is This For You?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mt-4 text-sm sm:text-base text-muted-foreground",
							children: "This workshop is designed for anyone looking to build or transition into a Business Analysis career."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-7 flex flex-wrap gap-2.5",
							children: audiences.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `reveal reveal-delay-${i % 5 + 1} rounded-full border border-border bg-surface px-4 py-2 text-xs sm:text-sm text-foreground/90 transition-all hover:border-lime/50 hover:text-lime`,
								children: a
							}, a))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
							children: "What You Will Gain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
							children: ["Understand → Analyze → ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gradient-lime",
								children: "Solve"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mt-4 text-sm sm:text-base text-muted-foreground",
							children: "By the end of the workshop, you'll understand how a BA works from problem identification to solution delivery — and complete a real project."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-7 grid gap-3 sm:grid-cols-2",
							children: gains.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `reveal reveal-delay-${i % 3 + 1} hover-lift rounded-2xl border border-border bg-surface p-4 hover:border-lime/50`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-8 w-8 place-items-center rounded-lg bg-lime/10 text-lime",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(g.icon, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-bold",
										children: g.title
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs sm:text-sm text-muted-foreground",
									children: g.body
								})]
							}, g.title))
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-surface/40 py-16 sm:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
							children: "At a Glance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
							children: "5-Day Workshop Overview"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal mt-8 overflow-hidden rounded-3xl border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-[560px] text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "bg-surface text-xs uppercase tracking-widest text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-4 font-semibold",
												children: "Day"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-4 font-semibold",
												children: "Main Focus"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-4 font-semibold",
												children: "Key Deliverables"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: overview.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: `border-t border-border transition-colors hover:bg-lime/5 ${i % 2 ? "bg-surface/40" : "bg-background"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-5 py-4 font-bold text-lime whitespace-nowrap",
												children: r.day
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-5 py-4 font-medium",
												children: r.focus
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-5 py-4 text-muted-foreground",
												children: r.deliverables
											})
										]
									}, r.day)) })]
								})
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplySection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border bg-surface/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-8 sm:gap-10 px-4 sm:px-6 py-12 sm:py-14 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted-foreground",
							children: "Mangalore, India"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "Programs",
							items: [
								"PG Program",
								"UG Program",
								"Online Programs",
								"Incubation"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "School",
							items: [
								"Outcomes",
								"Faculty",
								"Alumni",
								"Life at SKILL AI"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "Contact",
							items: [
								"Chat with us",
								"Connect@skillaiindia.com",
								"Press",
								"Careers"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border py-6 text-center text-xs text-muted-foreground whitespace-pre-line",
					children: ["© 2026 Skill AI India School of AI. All Rights Reserved.", "\n\xA0"]
				})]
			})
		]
	});
}
var whyJoin = [
	"Complete a real-world BA project from start to finish",
	"Create 15+ professional BA deliverables",
	"Hands-on exposure to Excel, SQL, Power BI, Jira & more",
	"Learn the full BA lifecycle: problem to solution",
	"Present your project and get feedback"
];
function ApplySection() {
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [sendError, setSendError] = (0, import_react.useState)("");
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		role: "",
		experience: "",
		goal: ""
	});
	const update = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "apply",
		className: "mx-auto max-w-7xl px-4 sm:px-6 py-20 sm:py-24 scroll-mt-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:gap-14 lg:grid-cols-2 lg:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "reveal",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
						children: "Apply Now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
						children: ["Reserve Your ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gradient-lime",
							children: "Seat"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm sm:text-base text-muted-foreground",
						children: "Fill out the application form to register for the 1-Week Business Analyst Workshop."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 rounded-3xl border border-border bg-surface p-6 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-lime",
								children: "Why Join This Workshop?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-3",
								children: whyJoin.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2.5 text-sm text-foreground/90",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-4 w-4 shrink-0 text-lime" }), w]
								}, w))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 border-t border-border pt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-lg font-bold text-gradient-lime",
									children: "Build. Analyze. Document. Solve."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs sm:text-sm text-muted-foreground",
									children: "One Week. One Real-World Project. Complete BA Experience."
								})]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal reveal-delay-2",
				children: submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid min-h-[26rem] place-items-center rounded-3xl border border-lime/50 bg-lime/5 p-8 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-auto grid h-16 w-16 place-items-center rounded-full bg-lime text-lime-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 text-2xl font-bold",
							children: "Application Received!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mx-auto mt-3 max-w-sm text-sm text-muted-foreground",
							children: [
								"Thanks ",
								form.name.split(" ")[0] || "there",
								" — we've received your application for the Business Analyst Workshop. Our team will reach out to you shortly."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSubmitted(false),
							className: "mt-6 rounded-full border border-lime px-5 py-2.5 text-xs font-bold tracking-wider text-lime transition-all hover:bg-lime hover:text-lime-foreground",
							children: "SUBMIT ANOTHER APPLICATION"
						})
					] })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: async (e) => {
						e.preventDefault();
						setSending(true);
						setSendError("");
						const res = await submitApplication({
							form_type: "workshop",
							program: "1-Week Business Analyst Workshop",
							name: form.name,
							email: form.email,
							phone: form.phone,
							role: form.role,
							experience: form.experience,
							goal: form.goal
						});
						setSending(false);
						if (res.ok || res.offline) setSubmitted(true);
						else setSendError(res.error ?? "Could not submit. Please try again.");
					},
					className: "rounded-3xl border border-border bg-surface p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Full Name *",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.name,
										onChange: update("name"),
										placeholder: "Your full name",
										className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Email *",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "email",
										value: form.email,
										onChange: update("email"),
										placeholder: "you@example.com",
										className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Phone Number *",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "tel",
										value: form.phone,
										onChange: update("phone"),
										placeholder: "+91 ...",
										className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Current Role",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.role,
										onChange: update("role"),
										placeholder: "e.g. Student, Developer, QA",
										className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Years of Experience",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.experience,
										onChange: update("experience"),
										className: "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-lime",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select..."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "fresher",
												children: "Fresher / Student"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "0-2",
												children: "0–2 years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "2-5",
												children: "2–5 years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "5+",
												children: "5+ years"
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "What do you want to gain from this workshop?",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											value: form.goal,
											onChange: update("goal"),
											rows: 4,
											placeholder: "Tell us about your goals...",
											className: "w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-lime"
										})
									})
								})
							]
						}),
						sendError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: sendError
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: sending,
							className: "group mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-lime px-6 py-3.5 text-sm font-bold tracking-wider text-lime-foreground transition-all hover:scale-[1.02] hover:shadow-[0_8px_24px_oklch(0.72_0.2_50/0.35)] disabled:opacity-60",
							children: [
								sending ? "SENDING…" : "SUBMIT APPLICATION",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })
							]
						})
					]
				})
			})]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-semibold tracking-wide text-foreground/80",
			children: label
		}), children]
	});
}
function Meta({ icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 text-foreground/90",
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function FootCol({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm font-semibold",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 space-y-2 text-sm text-muted-foreground",
		children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#",
			onClick: (e) => e.preventDefault(),
			className: "relative inline-block transition-colors hover:text-lime",
			children: i
		}) }, i))
	})] });
}
//#endregion
export { WorkshopPage as component };
