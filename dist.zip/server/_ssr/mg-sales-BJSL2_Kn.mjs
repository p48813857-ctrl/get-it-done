//#region node_modules/.nitro/vite/services/ssr/assets/mg-sales-BJSL2_Kn.js
var mg_sales_default = "/assets/mg-sales-yokooVLE.jpg";
//#endregion
export { mg_sales_default as t };
