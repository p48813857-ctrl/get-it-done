//#region node_modules/.nitro/vite/services/ssr/assets/card-bd-cert-CLLppQO1.js
var card_bd_cert_default = "/assets/card-bd-cert-DcHG_47b.jpg";
//#endregion
export { card_bd_cert_default as t };
