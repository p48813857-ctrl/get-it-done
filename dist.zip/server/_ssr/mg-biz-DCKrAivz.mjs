//#region node_modules/.nitro/vite/services/ssr/assets/mg-biz-DCKrAivz.js
var mg_biz_default = "/assets/mg-biz-DFrq5LD0.jpg";
//#endregion
export { mg_biz_default as t };
