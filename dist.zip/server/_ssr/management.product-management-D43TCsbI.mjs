import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { C as Search, D as Rocket, J as Layers, M as PenTool, c as Users, f as TrendingUp, gt as ClipboardList, kt as Briefcase, t as Zap, wt as ChartColumn } from "../_libs/lucide-react.mjs";
import { t as MultimediaCourseDetail } from "./MultimediaCourseDetail-CUunzaDV.mjs";
import { t as mg_pm_default } from "./mg-pm-Cqie_UoE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management.product-management-D43TCsbI.js
var import_jsx_runtime = require_jsx_runtime();
var MODULES = [
	{
		n: 1,
		icon: ClipboardList,
		title: "Product Management Foundations",
		weeks: "Month 1",
		hours: "40 hrs",
		points: [
			"PM role & operating model",
			"Product lifecycle",
			"Working with eng & design",
			"Product sense"
		],
		color: "from-lime/30 to-emerald-500/10"
	},
	{
		n: 2,
		icon: Search,
		title: "Discovery & User Research",
		weeks: "Month 1",
		hours: "40 hrs",
		points: [
			"User interviews",
			"JTBD framework",
			"Opportunity solution trees",
			"Problem framing"
		],
		color: "from-cyan-500/30 to-blue-500/10"
	},
	{
		n: 3,
		icon: Layers,
		title: "Strategy, Roadmaps & Prioritisation",
		weeks: "Month 2",
		hours: "40 hrs",
		points: [
			"Product strategy docs",
			"RICE & prioritisation",
			"Now-Next-Later roadmaps",
			"Stakeholder alignment"
		],
		color: "from-fuchsia-500/30 to-pink-500/10"
	},
	{
		n: 4,
		icon: PenTool,
		title: "PRDs, Specs & Design Collaboration",
		weeks: "Month 3",
		hours: "40 hrs",
		points: [
			"Writing crisp PRDs",
			"User stories & acceptance criteria",
			"Wireframing in Figma",
			"Design critique"
		],
		color: "from-orange-500/30 to-amber-500/10"
	},
	{
		n: 5,
		icon: Rocket,
		title: "Agile Delivery & Shipping",
		weeks: "Month 3",
		hours: "40 hrs",
		points: [
			"Scrum & Kanban",
			"Sprint planning",
			"Release management",
			"Risk & scope control"
		],
		color: "from-sky-500/30 to-indigo-500/10"
	},
	{
		n: 6,
		icon: ChartColumn,
		title: "Metrics, Analytics & Experimentation",
		weeks: "Month 4",
		hours: "40 hrs",
		points: [
			"North star & input metrics",
			"Funnels & cohorts",
			"A/B testing",
			"Mixpanel / Amplitude"
		],
		color: "from-violet-500/30 to-purple-500/10"
	},
	{
		n: 7,
		icon: TrendingUp,
		title: "Growth & Monetisation",
		weeks: "Month 5",
		hours: "40 hrs",
		points: [
			"Activation & retention loops",
			"Pricing & packaging",
			"PLG motions",
			"Churn reduction"
		],
		color: "from-amber-500/30 to-yellow-500/10"
	},
	{
		n: 8,
		icon: Zap,
		title: "AI Product Management",
		weeks: "Month 5",
		hours: "40 hrs",
		points: [
			"Designing with LLMs",
			"Evals & guardrails",
			"AI feature scoping",
			"AI tooling for PMs"
		],
		color: "from-teal-500/30 to-cyan-500/10"
	},
	{
		n: 9,
		icon: Users,
		title: "Go-To-Market & Product Marketing",
		weeks: "Month 6",
		hours: "40 hrs",
		points: [
			"Launch plans",
			"Positioning & messaging",
			"Beta programs",
			"Sales enablement"
		],
		color: "from-rose-500/30 to-red-500/10"
	},
	{
		n: 10,
		icon: Briefcase,
		title: "Capstone & PM Career Launch",
		weeks: "Month 6",
		hours: "20 hrs",
		points: [
			"End-to-end product case",
			"Portfolio & case studies",
			"PM interview drills",
			"Referral network"
		],
		color: "from-orange-500/30 to-red-500/10"
	}
];
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultimediaCourseDetail, {
	eyebrow: "Management · Product",
	title: "Product Management",
	tagline: "Discovery, roadmaps, metrics and shipping — build products people actually use.",
	duration: "6 Months",
	schedule: "2 hrs/day · 6 days",
	sessions: "144 Sessions",
	totalHours: "288 Hours",
	level: "Beginner → Associate PM",
	mode: "Hybrid + Live Product Squads",
	heroImage: mg_pm_default,
	overview: "A build-first PM program run like a real product org. You'll join a squad, interview users, write PRDs, ship features with engineers and designers, and defend your decisions with data — finishing with an interview-ready product portfolio.",
	modules: MODULES,
	tools: [
		"Figma",
		"Jira",
		"Linear",
		"Notion",
		"Miro",
		"Amplitude",
		"Mixpanel",
		"GA4",
		"SQL",
		"ChatGPT",
		"Lovable"
	],
	capstones: [
		"User Research Report",
		"Product Strategy Doc",
		"Roadmap & Prioritisation Model",
		"Shipped Feature with a Squad",
		"Experiment & Metrics Readout",
		"GTM Launch Plan"
	],
	outcomes: [
		"Run continuous product discovery",
		"Write PRDs engineers love",
		"Prioritise with clear frameworks",
		"Ship in agile squads",
		"Make decisions from product analytics",
		"Land APM / PM roles at startups & SaaS"
	]
});
//#endregion
export { SplitComponent as component };
