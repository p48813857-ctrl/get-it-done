//#region node_modules/.nitro/vite/services/ssr/assets/php-api-BHg0UHqS.js
/**
* Client for the standalone PHP + MySQL backend (see /php-backend).
*
* Set VITE_PHP_API_URL in .env to the folder that contains the PHP files,
* e.g. https://www.your-domain.com/api
*
* When the variable is empty every call resolves to { ok: false, offline: true }
* so the UI keeps working locally before the backend is deployed.
*/
var PHP_API_URL = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_PHP_API_URL": ""
}["VITE_PHP_API_URL"]?.replace(/\/+$/, "") ?? "";
var phpBackendEnabled = PHP_API_URL !== "";
async function post(endpoint, body) {
	if (!phpBackendEnabled) return {
		ok: false,
		offline: true
	};
	try {
		const res = await fetch(`${PHP_API_URL}/${endpoint}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body)
		});
		const json = await res.json().catch(() => ({}));
		if (!res.ok || json["ok"] !== true) return {
			ok: false,
			error: String(json["error"] ?? `Request failed (${res.status})`)
		};
		return {
			ok: true,
			data: json
		};
	} catch {
		return {
			ok: false,
			error: "Network error. Please check your connection."
		};
	}
}
async function get(endpoint) {
	if (!phpBackendEnabled) return {
		ok: false,
		offline: true
	};
	try {
		const res = await fetch(`${PHP_API_URL}/${endpoint}`);
		const json = await res.json().catch(() => ({}));
		if (!res.ok || json["ok"] !== true) return {
			ok: false,
			error: String(json["error"] ?? `Request failed (${res.status})`)
		};
		return {
			ok: true,
			data: json
		};
	} catch {
		return {
			ok: false,
			error: "Network error."
		};
	}
}
function submitApplication(payload) {
	return post("applications.php", {
		...payload,
		source_page: payload.source_page ?? (typeof window !== "undefined" ? window.location.pathname : "")
	});
}
function saveFutureScore(payload) {
	return post("future-score.php", payload);
}
function fetchLeaderboard(limit = 10) {
	return get(`future-score.php?limit=${limit}`);
}
//#endregion
export { submitApplication as i, phpBackendEnabled as n, saveFutureScore as r, fetchLeaderboard as t };
