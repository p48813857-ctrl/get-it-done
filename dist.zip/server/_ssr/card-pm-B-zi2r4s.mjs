//#region node_modules/.nitro/vite/services/ssr/assets/card-pm-B-zi2r4s.js
var card_pm_default = "/assets/card-pm-C0cmCUOD.jpg";
//#endregion
export { card_pm_default as t };
