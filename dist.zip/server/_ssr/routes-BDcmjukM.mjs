import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ApplyModal } from "./ug-programs-CAHAfbmi.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { Et as Calendar, Ft as ArrowRight, Pt as Award, V as Menu, W as MapPin, ht as Clock, n as X, xt as ChevronDown } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BDcmjukM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var pillar_1_default = "/assets/pillar-1-B4pPyRBj.jpg";
var pillar_2_default = "/assets/pillar-2-DX6hmi3q.jpg";
var pillar_3_default = "/assets/pillar-3-kMnNw3ZX.jpg";
var pillar_4_default = "/assets/pillar-4-CuQaj3eW.jpg";
var demoday_default = "/assets/demoday-B7TpFu8S.jpg";
var navItems = [
	{
		label: "AI",
		chevron: true,
		href: "/ai"
	},
	{
		label: "Multimedia",
		chevron: true,
		href: "/multimedia"
	},
	{
		label: "Management",
		chevron: true,
		href: "/management"
	},
	{
		label: "UG & PG Program",
		chevron: true,
		href: "/ug-programs"
	},
	{
		label: "Online Programs",
		chevron: true,
		href: "/online-programs"
	},
	{
		label: "Workshop",
		chevron: false,
		href: "/workshop"
	},
	{
		label: "Future Score",
		chevron: false,
		href: "/future-score"
	}
];
var stats = [
	{
		value: "10L",
		label: "Average CTC (in Lakhs)"
	},
	{
		value: "25+",
		label: "Programs"
	},
	{
		value: "50+",
		label: "Internships"
	},
	{
		value: "100+",
		label: "Companies tie-up"
	},
	{
		value: "10000+",
		label: "Case studies"
	}
];
var pillars = [
	{
		n: "2",
		title: "AI courses",
		img: pillar_2_default,
		href: "/ai",
		body: "Explore industry-ready AI, DS, Big Data, Advanced MLOps, Gen Ai, Agentic Ai, Cyber security courses with live projects and placement support."
	},
	{
		n: "3",
		title: "Multimedia",
		img: pillar_3_default,
		href: "/multimedia",
		body: "Explore industry-ready Multimedia, Graphic Design, Animation, VFX, Video Editing, UI/UX, and Digital Media courses with live projects, practical training, and placement support."
	},
	{
		n: "4",
		title: "Management",
		img: pillar_4_default,
		href: "/management",
		body: "Business & Entrepreneurship, Sales, Marketing and Finance — operator-led classes that turn theory into traction."
	},
	{
		n: "5",
		title: "UG/PG Program",
		img: pillar_1_default,
		href: "/ug-programs",
		body: "Undergraduate (BCA, BBA, BCom, BA) and Postgraduate (MBA, MCA, MCom, MA) degrees redesigned for the AI era."
	}
];
var toolkit = [
	"Python",
	"TensorFlow",
	"PyTorch",
	"LangChain",
	"Hugging Face",
	"Adobe Photoshop",
	"Adobe Illustrator",
	"Premiere Pro",
	"After Effects",
	"Blender",
	"Figma",
	"Canva",
	"Excel",
	"PowerPoint",
	"Tableau",
	"Power BI",
	"Slack",
	"Notion",
	"Salesforce",
	"HubSpot"
];
/** Auto-reveal on scroll for any element with class "reveal" */
function useScrollReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal");
		const io = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) {
					e.target.classList.add("in-view");
					io.unobserve(e.target);
				}
			});
		}, {
			threshold: .12,
			rootMargin: "0px 0px -40px 0px"
		});
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
function Logo({ size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: skill_ai_logo_default,
		alt: "SkillAI - Learn Skill Get Job",
		className: `${size === "sm" ? "h-8" : "h-10"} w-auto rounded-md bg-white p-1`
	});
}
function Index() {
	useScrollReveal();
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [apply, setApply] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 py-3 sm:py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/",
							className: "shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "hidden items-center gap-4 xl:gap-6 lg:flex",
							children: navItems.map((n) => {
								const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative",
									children: [n.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1 left-0 h-0.5 w-0 bg-lime transition-all duration-300 group-hover:w-full" })]
								}), n.chevron && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 opacity-70 transition-transform group-hover:translate-y-0.5" })] });
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: n.href,
									className: "group flex items-center gap-1 text-[13px] whitespace-nowrap text-foreground/85 transition-colors hover:text-lime",
									children: inner
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "group flex items-center gap-1 text-[13px] whitespace-nowrap text-foreground/85 transition-colors hover:text-lime",
									children: inner
								}) }, n.label);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setApply(true),
								className: "hidden sm:inline-flex rounded-full border border-lime px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold tracking-wide text-lime transition-all hover:bg-lime hover:text-lime-foreground hover:scale-105",
								children: "CHAT WITH US"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Open menu",
								className: "grid h-10 w-10 place-items-center rounded-md border border-border text-foreground lg:hidden",
								onClick: () => setMenuOpen((v) => !v),
								children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `lg:hidden overflow-hidden border-t border-border transition-[max-height,opacity] duration-300 ${menuOpen ? "max-h-[30rem] opacity-100" : "max-h-0 opacity-0"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "flex flex-col gap-1 px-4 py-3",
						children: [navItems.map((n) => {
							const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [n.label, n.chevron && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-60" })] });
							const cls = "flex w-full items-center justify-between rounded-lg px-3 py-3 text-sm text-foreground/90 transition-colors hover:bg-surface";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.href,
								className: cls,
								onClick: () => setMenuOpen(false),
								children: content
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: cls,
								children: content
							}) }, n.label);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									setMenuOpen(false);
									setApply(true);
								},
								className: "w-full rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground",
								children: "CHAT WITH US"
							})
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6 pt-10 pb-16 lg:pt-20 lg:pb-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-20 -left-20 h-72 w-72 rounded-full bg-lime/10 blur-3xl animate-float" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-40 right-0 h-80 w-80 rounded-full bg-mint/10 blur-3xl animate-float-soft" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid items-center gap-10 lg:gap-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-3 text-xs sm:text-sm font-medium uppercase tracking-widest text-mint whitespace-pre-line",
									children: "\n"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "text-[2.25rem] sm:text-5xl lg:text-6xl font-bold leading-[1.05] tracking-tight",
									children: [
										"Start Career With ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-gradient-lime",
											children: "Skill AI"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 sm:mt-8 flex flex-wrap gap-x-5 gap-y-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-lime" }),
											label: "online/offline"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-lime" }),
											label: "Full-Time"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-lime" }),
											label: "Mangalore"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-4 w-4 text-lime" }),
											label: "Limited seats"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 flex flex-wrap gap-2",
									children: [
										"AI-focused",
										"Placements",
										"Industry experts Classes"
									].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "reveal rounded-full border border-lime/40 bg-lime/5 px-3.5 py-1.5 text-xs sm:text-sm text-lime transition-all hover:bg-lime/15 hover:scale-105",
										style: { transitionDelay: `${i * 80}ms` },
										children: t
									}, t))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setApply(true),
									className: "mt-7 inline-flex items-center gap-3 rounded-full bg-lime px-5 sm:px-6 py-3 text-sm font-bold tracking-wider text-lime-foreground transition-all hover:scale-[1.04] hover:shadow-[0_8px_24px_oklch(0.72_0.2_50/0.35)] animate-pulse-glow",
									children: ["KNOW MORE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 hidden lg:flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-1 text-muted-foreground animate-scroll-blink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-widest",
								children: "SCROLL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-surface/40 py-16 sm:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal max-w-3xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl sm:text-4xl font-bold tracking-tight",
								children: "Career Outcomes That Matter; AI Training with Real Job Opportunities"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base sm:text-lg italic text-muted-foreground",
								children: "\"At Skill AI, success is measured by more than certificates or placements. Our industry-focused AI training programs prepare students for high-paying careers through real-world projects, internship opportunities, mentorship, and hands-on experience.\""
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 sm:mt-12 grid gap-4 sm:gap-5 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5",
							children: stats.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `reveal reveal-delay-${i % 5 + 1} hover-lift rounded-2xl border border-border bg-background p-5 sm:p-6 hover:border-lime/50`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl sm:text-4xl font-bold text-gradient-lime",
									children: s.value
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 text-xs sm:text-sm text-muted-foreground",
									children: s.label
								})]
							}, s.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal mt-10 flex flex-wrap gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBtn, {
								primary: true,
								onClick: () => setApply(true),
								children: "Learn More"
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 py-20 sm:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
						children: "Program Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "reveal mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
						children: [
							"AI, Multimedia ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							" Management, ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gradient-lime",
								children: "UG/PG Program"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal mt-7 flex flex-wrap gap-x-7 gap-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-lime" }),
								label: "online/offline"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-lime" }),
								label: "Full-Time, Part time"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-lime" }),
								label: "2026"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-lime" }),
								label: "Mangalore"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 sm:gap-6 md:grid-cols-2 lg:grid-cols-3",
						children: pillars.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: p.href,
							className: `reveal reveal-delay-${i % 4 + 1} hover-lift group relative block overflow-hidden rounded-3xl border border-border bg-surface p-6 sm:p-8 hover:border-lime/50`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-5 sm:mb-6 h-36 sm:h-40 overflow-hidden rounded-2xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: p.img,
										alt: p.title,
										loading: "lazy",
										width: 1024,
										height: 512,
										className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg sm:text-xl font-bold group-hover:text-lime transition-colors",
									children: p.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: p.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-lime",
									children: ["Explore ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 transition-transform group-hover:translate-x-1" })]
								})
							]
						}, p.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal mt-12 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBtn, {
							primary: true,
							onClick: () => setApply(true),
							children: "Apply Now"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bg-surface/40 py-16 sm:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-10 sm:gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs sm:text-sm font-medium uppercase tracking-widest text-mint",
								children: "SKILL AI Demo Day"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-3 text-3xl sm:text-4xl font-bold tracking-tight",
								children: [
									"Industrial Experts come to campus.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Students pitch real businesses."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm sm:text-base text-muted-foreground",
								children: "Demo Days are hosted by the SKILL AI Startup Lab, where students pitch to IEs from across the country. Every founder walks away with direct 1:1 feedback; the strongest pitches open doors to follow-up meetings and real investment."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-7 sm:mt-8 grid grid-cols-2 gap-4 sm:gap-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hover-lift rounded-2xl border border-border bg-background p-4 sm:p-5 hover:border-lime/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl sm:text-3xl font-bold text-gradient-lime",
										children: "100+"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs sm:text-sm text-muted-foreground",
										children: "IEs on Campus"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hover-lift rounded-2xl border border-border bg-background p-4 sm:p-5 hover:border-lime/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl sm:text-3xl font-bold text-gradient-lime",
										children: "20+"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs sm:text-sm text-muted-foreground",
										children: "Student Startups"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-7 sm:mt-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBtn, {
									primary: true,
									onClick: () => setApply(true),
									children: "Learn More"
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal reveal-delay-2 aspect-[4/3] overflow-hidden rounded-3xl shadow-2xl animate-float-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: demoday_default,
							alt: "SKILL AI Demo Day",
							loading: "lazy",
							width: 1024,
							height: 768,
							className: "h-full w-full object-cover"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-14 sm:mt-16 max-w-7xl px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center text-xs sm:text-sm font-semibold uppercase tracking-widest text-muted-foreground",
						children: "Tool Kit — Many Used in AI, Multimedia & Management"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "marquee-pause mt-6 overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "marquee-track gap-10 sm:gap-14 py-2",
							children: [...toolkit, ...toolkit].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "shrink-0 text-sm sm:text-base font-semibold tracking-wider text-foreground/70 transition-colors hover:text-lime",
								children: t
							}, i))
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-4 sm:px-6 py-20 sm:py-24 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "reveal text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight whitespace-pre-line text-gradient-lime",
						children: "Skill AI Real-World Skills. Real-World Careers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "reveal reveal-delay-1 mt-5 text-base sm:text-lg text-muted-foreground",
						children: "Join skills that turn ambition into opportunity, Applications for the 2026 cohort are now open."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal reveal-delay-2 mt-8 flex flex-wrap justify-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBtn, {
							primary: true,
							onClick: () => setApply(true),
							children: "Apply Now"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border bg-surface/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-8 sm:gap-10 px-4 sm:px-6 py-12 sm:py-14 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted-foreground",
							children: "Mangalore, India"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "Programs",
							items: [
								"PG Program",
								"UG Program",
								"Online Programs",
								"Incubation"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "School",
							items: [
								"Outcomes",
								"Faculty",
								"Alumni",
								"Life at SKILL AI"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootCol, {
							title: "Contact",
							items: [
								"Chat with us",
								"Connect@skillaiindia.com",
								"Press",
								"Careers"
							],
							onItemClick: (i) => i === "Chat with us" && setApply(true)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border py-6 text-center text-xs text-muted-foreground whitespace-pre-line",
					children: ["© 2026 Skill AI India School of AI. All Rights Reserved.", "\n\xA0"]
				})]
			}),
			apply && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyModal, {
				program: "SKILL AI Programs",
				onClose: () => setApply(false)
			})
		]
	});
}
function Meta({ icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 text-foreground/90",
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function CtaBtn({ children, primary, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: primary ? "group inline-flex items-center gap-2 rounded-full bg-lime px-5 sm:px-6 py-3 text-xs sm:text-sm font-bold tracking-wider text-lime-foreground transition-all hover:scale-[1.04] hover:shadow-[0_8px_24px_oklch(0.72_0.2_50/0.35)]" : "group inline-flex items-center gap-2 rounded-full border border-lime px-5 sm:px-6 py-3 text-xs sm:text-sm font-bold tracking-wider text-lime transition-all hover:bg-lime hover:text-lime-foreground hover:scale-[1.04]",
		children: [
			children,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })
		]
	});
}
function FootCol({ title, items, onItemClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm font-semibold",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 space-y-2 text-sm text-muted-foreground",
		children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#",
			onClick: (e) => {
				if (onItemClick) {
					e.preventDefault();
					onItemClick(i);
				}
			},
			className: "relative inline-block transition-colors hover:text-lime",
			children: i
		}) }, i))
	})] });
}
//#endregion
export { Index as component };
