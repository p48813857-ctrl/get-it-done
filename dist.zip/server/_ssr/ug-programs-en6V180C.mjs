import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as submitApplication } from "./php-api-BHg0UHqS.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { D as Rocket, Dt as Calculator, Ft as ArrowRight, Nt as BookOpen, Ot as Building2, c as Users, et as GraduationCap, f as TrendingUp, ht as Clock, kt as Briefcase, ot as Earth, y as Sparkles } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ug-programs-en6V180C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var courses = [
	{
		slug: "bca",
		title: "BCA",
		full: "Bachelor of Computer Applications",
		Icon: GraduationCap,
		tag: "Tech · AI · Code",
		duration: "3 years",
		seats: "120 seats",
		gradient: "from-orange-500/30 to-amber-500/10",
		short: "Become an AI-first builder. Code, ship, and deploy real products from day one.",
		highlights: [
			"Full-stack web & mobile development",
			"AI/ML, prompt engineering & LLM apps",
			"Cloud, DevOps & system design",
			"Capstone with partner startups"
		],
		careers: [
			"Software Engineer",
			"AI Engineer",
			"Product Engineer",
			"Founding Engineer"
		]
	},
	{
		slug: "bba",
		title: "BBA",
		full: "Bachelor of Business Administration",
		Icon: Briefcase,
		tag: "Business · Strategy",
		duration: "3 years",
		seats: "180 seats",
		gradient: "from-amber-500/30 to-orange-600/10",
		short: "Run real businesses while you study. Marketing, ops, finance, and founder skills.",
		highlights: [
			"Marketing, sales & growth labs",
			"Operations & supply chain sims",
			"Finance for founders",
			"Live consulting projects"
		],
		careers: [
			"Business Analyst",
			"Growth Manager",
			"Founder's Office",
			"Brand Manager"
		]
	},
	{
		slug: "bcom",
		title: "B.Com",
		full: "Bachelor of Commerce",
		Icon: Calculator,
		tag: "Finance · Accounts",
		duration: "3 years",
		seats: "150 seats",
		gradient: "from-orange-600/30 to-yellow-500/10",
		short: "Master modern finance — from books to fintech, taxation to investment banking.",
		highlights: [
			"Advanced accounting & GST",
			"Equity research & valuation",
			"Fintech, payments & risk",
			"CFA / ACCA aligned electives"
		],
		careers: [
			"Financial Analyst",
			"Auditor",
			"Investment Associate",
			"Tax Consultant"
		]
	},
	{
		slug: "ba",
		title: "BA",
		full: "Bachelor of Arts (Liberal Studies)",
		Icon: BookOpen,
		tag: "Liberal · Media · Policy",
		duration: "3 years",
		seats: "100 seats",
		gradient: "from-amber-400/30 to-orange-500/10",
		short: "Think across disciplines. Psychology, economics, media, and design thinking.",
		highlights: [
			"Behavioural economics & psych",
			"Media, storytelling & content",
			"Public policy & sustainability",
			"Internships with NGOs & media houses"
		],
		careers: [
			"Content Strategist",
			"Policy Analyst",
			"PR & Comms",
			"UX Researcher"
		]
	}
];
var pgCourses = [
	{
		slug: "mba",
		title: "MBA",
		full: "Master of Business Administration",
		Icon: Rocket,
		tag: "Leadership · Strategy · AI",
		duration: "2 years",
		seats: "120 seats",
		gradient: "from-orange-500/30 to-amber-500/10",
		short: "An MBA rebuilt for the AI era — strategy, product, finance and founder skills taught by operators.",
		highlights: [
			"AI-native strategy & product",
			"Venture building & fundraising",
			"Global immersion week",
			"Capstone with a real startup"
		],
		careers: [
			"Founder",
			"Chief of Staff",
			"Product Manager",
			"VC Associate"
		]
	},
	{
		slug: "mca",
		title: "MCA",
		full: "Master of Computer Applications",
		Icon: TrendingUp,
		tag: "Engineering · AI · Systems",
		duration: "2 years",
		seats: "90 seats",
		gradient: "from-amber-500/30 to-orange-600/10",
		short: "Become a senior AI / full-stack engineer. Ship production systems with LLMs, agents and cloud-native stacks.",
		highlights: [
			"Advanced ML, LLMs & agents",
			"Distributed systems & cloud",
			"Applied research projects",
			"Industry capstone with funded startups"
		],
		careers: [
			"Senior Engineer",
			"AI Engineer",
			"Tech Lead",
			"Founding Engineer"
		]
	},
	{
		slug: "mcom",
		title: "M.Com",
		full: "Master of Commerce",
		Icon: Building2,
		tag: "Finance · Fintech · Markets",
		duration: "2 years",
		seats: "100 seats",
		gradient: "from-orange-600/30 to-yellow-500/10",
		short: "Specialise in modern finance — fintech, investment banking, equity research, taxation and corporate strategy.",
		highlights: [
			"Investment banking & valuation",
			"Fintech, payments & risk",
			"Advanced taxation & audit",
			"CFA / ACCA aligned"
		],
		careers: [
			"Investment Banker",
			"Equity Analyst",
			"Fintech PM",
			"Corporate Strategy"
		]
	},
	{
		slug: "ma",
		title: "MA",
		full: "Master of Arts (Media & Public Policy)",
		Icon: Earth,
		tag: "Media · Policy · Research",
		duration: "2 years",
		seats: "80 seats",
		gradient: "from-amber-400/30 to-orange-500/10",
		short: "Shape narratives and policy. Specialise in journalism, public policy, UX research or brand storytelling.",
		highlights: [
			"Public policy & governance",
			"Long-form journalism & storytelling",
			"Qualitative & UX research methods",
			"Field internships with media & think-tanks"
		],
		careers: [
			"Policy Analyst",
			"Journalist",
			"UX Researcher",
			"Comms Lead"
		]
	}
];
function useReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal");
		const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in-view"), io.unobserve(e.target))), { threshold: .12 });
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
function UGPrograms() {
	useReveal();
	const [open, setOpen] = (0, import_react.useState)(null);
	const [applyFor, setApplyFor] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/40 bg-background/80 backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: skill_ai_logo_default,
							alt: "SkillAI - Learn Skill Get Job",
							className: "h-9 w-auto rounded-md bg-white p-1"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm text-muted-foreground hover:text-foreground",
						children: "← Home"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden border-b border-border/40 px-6 py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_30%_20%,oklch(0.72_0.2_50/0.25),transparent_60%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl reveal",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-lime/30 bg-lime/5 px-4 py-1.5 text-xs font-semibold text-lime",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), " Undergraduate & Postgraduate Programs"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-5xl font-black tracking-tight md:text-7xl",
							children: [
								"UG & PG that build ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-lime",
									children: "real careers"
								}),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-2xl text-lg text-muted-foreground",
							children: "Four undergraduate and four postgraduate degrees, redesigned for the AI era. Live projects, founder mentors, and real placements from day one."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#ug",
								className: "rounded-full border border-lime/40 px-4 py-2 text-lime hover:bg-lime/10",
								children: "↓ UG Programs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#pg",
								className: "rounded-full border border-lime/40 px-4 py-2 text-lime hover:bg-lime/10",
								children: "↓ PG Programs"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "ug",
				className: "px-6 py-20 scroll-mt-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-10 reveal",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold uppercase tracking-widest text-lime",
							children: "Undergraduate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 text-3xl md:text-5xl font-black",
							children: "UG Programs"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-7 md:grid-cols-2",
						children: courses.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `reveal reveal-delay-${i % 4 + 1} hover-lift group relative flex h-full flex-col overflow-hidden rounded-3xl border border-border/50 bg-surface p-8`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute inset-0 -z-10 bg-gradient-to-br ${c.gradient} opacity-60` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-14 w-14 place-items-center rounded-2xl bg-lime/20 text-lime ring-1 ring-lime/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.Icon, { className: "h-7 w-7" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-border/40 bg-background/40 px-3 py-1 text-[10px] font-semibold tracking-wider text-muted-foreground",
										children: c.tag
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-6 text-4xl font-black",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: c.full
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base",
									children: c.short
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), c.duration]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }), c.seats]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-5 grid gap-2 text-sm",
									children: c.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-lime" }), h]
									}, h))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									children: c.careers.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-background/60 px-3 py-1 text-xs text-muted-foreground ring-1 ring-border/40",
										children: r
									}, r))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-auto flex gap-3 pt-7",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setOpen(c.slug),
										className: "inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/60 px-5 py-2.5 text-sm font-semibold hover:bg-background",
										children: ["Explore ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setApplyFor(c.title),
										className: "inline-flex items-center gap-2 rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground hover:scale-105 transition-transform animate-pulse-glow",
										children: "Apply Now"
									})]
								})
							]
						}, c.slug))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "pg",
				className: "border-t border-border/40 bg-surface/30 px-6 py-20 scroll-mt-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-10 reveal",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-widest text-lime",
								children: "Postgraduate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-3xl md:text-5xl font-black",
								children: "PG Programs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-2xl text-muted-foreground",
								children: "Master's degrees designed with operators, founders and AI labs — for the next generation of builders and leaders."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-7 md:grid-cols-2",
						children: pgCourses.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `reveal reveal-delay-${i % 4 + 1} hover-lift group relative flex h-full flex-col overflow-hidden rounded-3xl border border-border/50 bg-surface p-8`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute inset-0 -z-10 bg-gradient-to-br ${c.gradient} opacity-60` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-14 w-14 place-items-center rounded-2xl bg-lime/20 text-lime ring-1 ring-lime/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.Icon, { className: "h-7 w-7" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-border/40 bg-background/40 px-3 py-1 text-[10px] font-semibold tracking-wider text-muted-foreground",
										children: c.tag
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-6 text-4xl font-black",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: c.full
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base",
									children: c.short
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), c.duration]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }), c.seats]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-5 grid gap-2 text-sm",
									children: c.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-lime" }), h]
									}, h))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									children: c.careers.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-background/60 px-3 py-1 text-xs text-muted-foreground ring-1 ring-border/40",
										children: r
									}, r))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-auto flex gap-3 pt-7",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApplyFor(c.title),
										className: "inline-flex items-center gap-2 rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground hover:scale-105 transition-transform animate-pulse-glow",
										children: ["Apply Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									})
								})
							]
						}, c.slug))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-border/40 bg-surface/50 px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "Why Skill Ai for UG?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-6 md:grid-cols-3",
						children: [
							{
								t: "Founder Mentors",
								d: "1:1 access to 100+ unicorn founders and operators."
							},
							{
								t: "Live Projects",
								d: "Work on real revenue-generating ventures from year 1."
							},
							{
								t: "Placement Promise",
								d: "Graduate into founder-facing or high-growth tech roles."
							}
						].map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i + 1} rounded-2xl border border-border/40 bg-background p-6 hover-lift`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-bold",
								children: b.t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: b.d
							})]
						}, b.t))
					})]
				})
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseModal, {
				course: courses.find((c) => c.slug === open),
				onClose: () => setOpen(null),
				onApply: (t) => {
					setOpen(null);
					setApplyFor(t);
				}
			}),
			applyFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyModal, {
				program: applyFor,
				onClose: () => setApplyFor(null)
			})
		]
	});
}
function CourseModal({ course, onClose, onApply }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[90vh] w-full max-w-2xl overflow-auto rounded-3xl border border-border/60 bg-surface p-8",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-3xl font-black",
						children: course.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: course.full
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "text-2xl text-muted-foreground hover:text-foreground",
						children: "×"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4",
					children: course.short
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-6 font-bold text-lime",
					children: "Curriculum highlights"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1.5 text-sm",
					children: course.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", h] }, h))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-6 font-bold text-lime",
					children: "Career paths"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: course.careers.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-background px-3 py-1 text-xs ring-1 ring-border/40",
						children: r
					}, r))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => onApply(course.title),
					className: "mt-7 w-full rounded-full bg-lime py-3 font-bold text-lime-foreground",
					children: ["Apply for ", course.title]
				})
			]
		})
	});
}
function ApplyModal({ program, onClose, variant = "default" }) {
	const [done, setDone] = (0, import_react.useState)(false);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [sendError, setSendError] = (0, import_react.useState)("");
	const isMM = variant === "multimedia";
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		city: "",
		interest: "",
		level: "",
		portfolio: "",
		tools: "",
		project: "",
		why: ""
	});
	const update = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	const onSubmit = async (e) => {
		e.preventDefault();
		setSending(true);
		setSendError("");
		const res = await submitApplication({
			form_type: isMM ? "multimedia-program" : "ug-pg-program",
			program,
			name: form.name,
			email: form.email,
			phone: form.phone,
			city: form.city,
			goal: isMM ? form.project : form.why,
			extra: isMM ? {
				interest: form.interest,
				level: form.level,
				portfolio: form.portfolio,
				tools: form.tools
			} : { why: form.why }
		});
		setSending(false);
		if (res.ok || res.offline) setDone(true);
		else setSendError(res.error ?? "Could not submit. Please try again.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border/60 bg-surface p-7 max-h-[90vh] overflow-y-auto",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-2xl font-black",
					children: ["Apply — ", program]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "text-2xl text-muted-foreground hover:text-foreground",
					children: "×"
				})]
			}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-lime text-lime-foreground text-2xl",
						children: "✓"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-semibold",
						children: "Application received!"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Our team will reach out within 24 hrs."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-5 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.name,
						onChange: update("name"),
						placeholder: "Full name",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.email,
						onChange: update("email"),
						type: "email",
						placeholder: "Email",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.phone,
						onChange: update("phone"),
						placeholder: "Phone",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form.city,
						onChange: update("city"),
						placeholder: "City",
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					isMM ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							required: true,
							value: form.interest,
							onChange: update("interest"),
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Creative area of interest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Graphic Design & Branding" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Video Editing & VFX" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "2D / 3D Animation" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Film Direction & Cinematography" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Performance & Social Media Marketing" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							required: true,
							value: form.level,
							onChange: update("level"),
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Your current level"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Absolute beginner" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hobbyist / self-taught" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "1–2 years experience" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Working professional" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: form.portfolio,
							onChange: update("portfolio"),
							placeholder: "Portfolio / Instagram / showreel link (optional)",
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: form.tools,
							onChange: update("tools"),
							placeholder: "Tools you already use (e.g. Photoshop, Premiere)",
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							required: true,
							value: form.project,
							onChange: update("project"),
							placeholder: "Tell us about a project or story you'd love to create.",
							rows: 3,
							className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: form.why,
						onChange: update("why"),
						placeholder: "Why this program?",
						rows: 3,
						className: "rounded-xl border border-border/60 bg-background px-4 py-2.5 text-sm outline-none focus:border-lime"
					}),
					sendError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: sendError
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: sending,
						className: "rounded-full bg-lime py-3 font-bold text-lime-foreground hover:scale-[1.02] transition-transform disabled:opacity-60",
						children: sending ? "Sending…" : "Submit application"
					})
				]
			})]
		})
	});
}
//#endregion
export { ApplyModal, UGPrograms as component };
