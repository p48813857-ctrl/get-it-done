import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Dt as Calculator, Nt as BookOpen, T as Scale, Y as Landmark, ct as DollarSign, f as TrendingUp, kt as Briefcase, t as Zap, wt as ChartColumn, x as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as MultimediaCourseDetail } from "./MultimediaCourseDetail-CUunzaDV.mjs";
import { t as mg_fin_default } from "./mg-fin-D0aO7488.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management.finance-accounting-CHVDKnec.js
var import_jsx_runtime = require_jsx_runtime();
var MODULES = [
	{
		n: 1,
		icon: BookOpen,
		title: "Accounting Fundamentals",
		weeks: "Month 1",
		hours: "40 hrs",
		points: [
			"Double-entry basics",
			"Journals & ledgers",
			"Trial balance",
			"Chart of accounts"
		],
		color: "from-lime/30 to-emerald-500/10"
	},
	{
		n: 2,
		icon: Calculator,
		title: "Financial Statements",
		weeks: "Month 1",
		hours: "40 hrs",
		points: [
			"P&L, balance sheet, cash flow",
			"Statement linkages",
			"Ratio analysis",
			"Closing the books"
		],
		color: "from-cyan-500/30 to-blue-500/10"
	},
	{
		n: 3,
		icon: Zap,
		title: "Tally, Zoho & Excel Mastery",
		weeks: "Month 2",
		hours: "40 hrs",
		points: [
			"Tally Prime workflows",
			"Zoho Books",
			"Advanced Excel & pivot tables",
			"Automated reporting"
		],
		color: "from-fuchsia-500/30 to-pink-500/10"
	},
	{
		n: 4,
		icon: Scale,
		title: "GST & Indirect Taxation",
		weeks: "Month 3",
		hours: "40 hrs",
		points: [
			"GST registration & returns",
			"Input tax credit",
			"E-invoicing & e-way bills",
			"Compliance calendar"
		],
		color: "from-orange-500/30 to-amber-500/10"
	},
	{
		n: 5,
		icon: Landmark,
		title: "Income Tax & TDS",
		weeks: "Month 3",
		hours: "40 hrs",
		points: [
			"Income heads & slabs",
			"TDS provisions",
			"Advance tax",
			"ITR filing"
		],
		color: "from-sky-500/30 to-indigo-500/10"
	},
	{
		n: 6,
		icon: ShieldCheck,
		title: "Audit, Controls & Compliance",
		weeks: "Month 4",
		hours: "40 hrs",
		points: [
			"Internal controls",
			"Audit procedures",
			"ROC & company compliance",
			"Fraud red flags"
		],
		color: "from-rose-500/30 to-red-500/10"
	},
	{
		n: 7,
		icon: ChartColumn,
		title: "FP&A and Budgeting",
		weeks: "Month 5",
		hours: "40 hrs",
		points: [
			"Budgets & forecasts",
			"Variance analysis",
			"Cash flow planning",
			"Management reporting"
		],
		color: "from-violet-500/30 to-purple-500/10"
	},
	{
		n: 8,
		icon: TrendingUp,
		title: "Valuation & Corporate Finance",
		weeks: "Month 5",
		hours: "40 hrs",
		points: [
			"DCF & comparables",
			"Cost of capital",
			"Fundraising structures",
			"M&A basics"
		],
		color: "from-amber-500/30 to-yellow-500/10"
	},
	{
		n: 9,
		icon: DollarSign,
		title: "Fintech & AI in Finance",
		weeks: "Month 6",
		hours: "40 hrs",
		points: [
			"Payments & UPI rails",
			"Automated bookkeeping",
			"AI for reconciliation",
			"Finance dashboards"
		],
		color: "from-teal-500/30 to-cyan-500/10"
	},
	{
		n: 10,
		icon: Briefcase,
		title: "Live Books Project & Career Launch",
		weeks: "Month 6",
		hours: "20 hrs",
		points: [
			"Real client bookkeeping",
			"Full compliance cycle",
			"Interview & case prep",
			"Finance portfolio"
		],
		color: "from-orange-500/30 to-red-500/10"
	}
];
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultimediaCourseDetail, {
	eyebrow: "Management · Finance",
	title: "Finance & Accounting",
	tagline: "Modern finance — books, taxation, fintech, valuation and FP&A, taught on real company data.",
	duration: "6 Months",
	schedule: "2 hrs/day · 6 days",
	sessions: "144 Sessions",
	totalHours: "288 Hours",
	level: "Beginner → Job-ready",
	mode: "Hybrid + Live Client Books",
	heroImage: mg_fin_default,
	overview: "A practitioner's finance program. You'll maintain real books, file real compliance cycles, build forecasting models and value businesses — using Tally, Zoho, Excel and AI-assisted finance tooling.",
	modules: MODULES,
	tools: [
		"Tally Prime",
		"Zoho Books",
		"QuickBooks",
		"Advanced Excel",
		"Google Sheets",
		"GST Portal",
		"Power BI",
		"ChatGPT",
		"Razorpay",
		"Notion"
	],
	capstones: [
		"Full Bookkeeping Cycle",
		"GST Return Filing Set",
		"3-Statement Financial Model",
		"Budget vs Actual Report",
		"DCF Valuation",
		"Client Finance Dashboard"
	],
	outcomes: [
		"Maintain company books end-to-end",
		"File GST, TDS and income tax returns",
		"Build forecasts and FP&A reports",
		"Value a business with DCF & comps",
		"Automate finance workflows",
		"Land accountant, analyst or FP&A roles"
	]
});
//#endregion
export { SplitComponent as component };
