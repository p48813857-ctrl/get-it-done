//#region node_modules/.nitro/vite/services/ssr/assets/skill-ai-logo-B_NXSqQa.js
var skill_ai_logo_default = "/assets/skill-ai-logo-oMhBKOpr.png";
//#endregion
export { skill_ai_logo_default as t };
