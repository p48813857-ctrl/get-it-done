import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ApplyModal } from "./ug-programs-CAHAfbmi.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { t as card_ads_default } from "./card-ads-DR6958aP.mjs";
import { At as Brain, Ct as ChartLine, Ft as ArrowRight, K as Lock, b as Shield, ht as Clock, lt as Database, ut as Cpu, wt as ChartColumn, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as card_big_data_default } from "./card-big-data-FXE0yn08.mjs";
import { t as card_bd_cert_default } from "./card-bd-cert-CLLppQO1.mjs";
import { t as card_cyber_default } from "./card-cyber-DVtonfuY.mjs";
import { t as card_datasec_default } from "./card-datasec-Ds6To9Na.mjs";
import { t as card_pm_default } from "./card-pm-B-zi2r4s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.index-D938y0M0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tracks = [
	{
		to: "/ai/gen-ai",
		img: "/assets/card-gen-ai-DEfPV7U1.jpg",
		Icon: Brain,
		title: "Master's in Gen AI & Agentic AI",
		desc: "Build production-grade generative AI systems and autonomous agents.",
		dur: "10 Months (Fast)",
		skills: [
			"LLMs",
			"LangGraph",
			"RAG",
			"Agents"
		]
	},
	{
		to: "/ai/big-data",
		img: card_big_data_default,
		Icon: Database,
		title: "Master's in AI Big Data & Advance MLOps",
		desc: "Engineer massive data pipelines, MLOps and AI systems that power enterprises.",
		dur: "12 months (275 sessions)",
		skills: [
			"Spark",
			"Kafka",
			"MLflow",
			"Cloud"
		]
	},
	{
		to: "/ai/advanced-data-science",
		img: card_ads_default,
		Icon: ChartLine,
		title: "Advanced Data Science",
		desc: "From statistics to deep learning — solve real business problems.",
		dur: "3 Months",
		skills: [
			"Python",
			"ML",
			"DL",
			"SageMaker"
		]
	},
	{
		to: "/ai/big-data-cert",
		img: card_bd_cert_default,
		Icon: Cpu,
		title: "Certificate in Big Data",
		desc: "A focused sprint into distributed data systems for working professionals.",
		dur: "6 months",
		skills: [
			"Spark",
			"Hadoop",
			"AWS",
			"Airflow"
		]
	},
	{
		to: "/ai/cyber-security",
		img: card_cyber_default,
		Icon: Shield,
		title: "Expertise in Cyber Security",
		desc: "Defend, attack and architect secure systems in the AI era.",
		dur: "12 months",
		skills: [
			"Pentest",
			"SOC",
			"Cloud Sec",
			"OSCP"
		]
	},
	{
		to: "/ai/data-security",
		img: card_datasec_default,
		Icon: Lock,
		title: "Certificate in Data Security",
		desc: "Encryption, compliance, privacy and governance for modern data.",
		dur: "6 months",
		skills: [
			"Encryption",
			"KMS",
			"GDPR",
			"DLP"
		]
	},
	{
		to: "/ai/product-management",
		img: card_pm_default,
		Icon: ChartColumn,
		title: "Advanced Product Management",
		desc: "Strategy, engineering, data & AI — 24-week PM operating system with a live-brief capstone.",
		dur: "6 months (24 weeks)",
		skills: [
			"Strategy",
			"Technical PRDs",
			"Metrics",
			"AI PRDs"
		]
	}
];
function useReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal");
		const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in-view"), io.unobserve(e.target))), { threshold: .12 });
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
function AIPrograms() {
	useReveal();
	const [applyFor, setApplyFor] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/40 bg-background/80 backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: skill_ai_logo_default,
							alt: "SkillAI - Learn Skill Get Job",
							className: "h-9 w-auto rounded-md bg-white p-1"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm text-muted-foreground hover:text-foreground",
						children: "← Home"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden border-b border-border/40 px-6 py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_50%_20%,oklch(0.72_0.2_50/0.25),transparent_60%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl reveal",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-lime/30 bg-lime/5 px-4 py-1.5 text-xs font-semibold text-lime",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), " Artificial Intelligence"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-5xl font-black tracking-tight md:text-7xl",
							children: [
								"Build with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-lime",
									children: "AI, not around it"
								}),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-2xl text-lg text-muted-foreground",
							children: "Programs that go beyond theory — ship LLM apps, data pipelines and AI products with mentors from leading AI teams."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-7xl gap-7 md:grid-cols-2 lg:grid-cols-3",
					children: tracks.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `reveal reveal-delay-${i % 4 + 1} hover-lift group relative overflow-hidden flex h-full flex-col rounded-3xl border border-border/50 bg-surface transition-all hover:border-lime/60`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: t.to,
							className: "block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-44 overflow-hidden",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: t.img,
										alt: t.title,
										loading: "lazy",
										className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-surface via-surface/40 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute right-3 top-3 grid h-11 w-11 place-items-center rounded-xl bg-lime/90 text-lime-foreground shadow-lg transition-transform duration-500 group-hover:rotate-6 group-hover:scale-110",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.Icon, { className: "h-5 w-5" })
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: t.to,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black hover:text-lime transition-colors",
										children: t.title
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: t.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), t.dur]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: t.skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-background/60 px-3 py-1 text-xs text-muted-foreground ring-1 ring-border/40",
										children: s
									}, s))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-auto flex gap-2 pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApplyFor(t.title),
										className: "inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground hover:scale-105 transition-transform",
										children: ["Apply Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: t.to,
										className: "inline-flex items-center justify-center rounded-full border border-border px-5 py-2.5 text-sm font-bold hover:bg-background transition-colors",
										children: "Explore"
									})]
								})
							]
						})]
					}, t.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-border/40 bg-surface/50 px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "Why Skill Ai AI?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-6 md:grid-cols-3",
						children: [
							{
								t: "Ship Real AI",
								d: "Deploy 3+ AI products into production during the program."
							},
							{
								t: "Mentor Network",
								d: "1:1 with AI engineers from OpenAI, Google, Meta & top startups."
							},
							{
								t: "GPU Credits",
								d: "Access to GPU credits and enterprise LLM APIs."
							}
						].map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i + 1} rounded-2xl border border-border/40 bg-background p-6 hover-lift`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-bold",
								children: b.t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: b.d
							})]
						}, b.t))
					})]
				})
			}),
			applyFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyModal, {
				program: applyFor,
				onClose: () => setApplyFor(null)
			})
		]
	});
}
//#endregion
export { AIPrograms as component };
