//#region node_modules/.nitro/vite/services/ssr/assets/card-mm-film-rYiZllMf.js
var card_mm_film_default = "/assets/card-mm-film-99sCthh-.jpg";
//#endregion
export { card_mm_film_default as t };
