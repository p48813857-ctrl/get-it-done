import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route$33 } from "./ug-programs-CAHAfbmi.mjs";
import { t as Route$34 } from "./portfolio._slug-BuOUCgL1.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DZ4VgJj1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-C_OCSo1s.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$32 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Skill AI India — Learn Skill, Get Job" },
			{
				name: "description",
				content: "Skill AI India — industry-focused AI, Multimedia, Management and UG/PG programs with real-world projects and placement support."
			},
			{
				name: "author",
				content: "Skill AI India"
			},
			{
				property: "og:title",
				content: "Skill AI India — Learn Skill, Get Job"
			},
			{
				property: "og:description",
				content: "Industry-focused AI, Multimedia, Management and UG/PG programs with real-world projects and placement support."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Space+Grotesk:wght@400;500;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$32.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$31 = () => import("./routes-BDcmjukM.mjs");
var Route$31 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "SKILL AI School of Business — Build Real Businesses" },
		{
			name: "description",
			content: "PGP in Startup Leadership & Entrepreneurship at SKILL AI. 12 months, full-time, Bangalore."
		},
		{
			property: "og:title",
			content: "SKILL AI School of Business"
		},
		{
			property: "og:description",
			content: "The business school where you build real businesses."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$31, "component")
});
/** Auto-reveal on scroll for any element with class "reveal" */
var $$splitComponentImporter$30 = () => import("./ai-BeIZpe6_.mjs");
var Route$30 = createFileRoute("/ai")({ component: lazyRouteComponent($$splitComponentImporter$30, "component") });
var $$splitComponentImporter$29 = () => import("./future-score-DonzYBjE.mjs");
var Route$29 = createFileRoute("/future-score")({ component: lazyRouteComponent($$splitComponentImporter$29, "component") });
var $$splitComponentImporter$28 = () => import("./incubation-Bvl06GOa.mjs");
var Route$28 = createFileRoute("/incubation")({
	head: () => ({ meta: [{ title: "Incubation — Skill Ai Startup Lab" }, {
		name: "description",
		content: "Funding, mentorship, and infra to take your idea from zero to revenue at Skill Ai Startup Lab."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./management-Ki8s0B7B.mjs");
var Route$27 = createFileRoute("/management")({ component: lazyRouteComponent($$splitComponentImporter$27, "component") });
var $$splitComponentImporter$26 = () => import("./multimedia-BLw0DBJl.mjs");
var Route$26 = createFileRoute("/multimedia")({ component: lazyRouteComponent($$splitComponentImporter$26, "component") });
var $$splitComponentImporter$25 = () => import("./online-programs-CHF6EY6U.mjs");
var Route$25 = createFileRoute("/online-programs")({
	head: () => ({ meta: [{ title: "Online Programs — Skill Ai School of Business" }, {
		name: "description",
		content: "Live online cohorts in AI, growth, product and entrepreneurship — taught by founders."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./outcomes-Dz_PDZtG.mjs");
var Route$24 = createFileRoute("/outcomes")({
	head: () => ({ meta: [{ title: "Outcomes — Skill Ai School of Business" }, {
		name: "description",
		content: "Placements, founder roles and salaries achieved by Skill Ai graduates."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./workshop-Bgsii0sY.mjs");
var Route$23 = createFileRoute("/workshop")({
	head: () => ({ meta: [
		{ title: "1-Week Business Analyst Workshop — Skill AI India" },
		{
			name: "description",
			content: "From business problem to complete business solution. A 1-week intensive Business Analyst workshop covering BRD, FRD, SOP, Use Cases, UAT and more — one real-world project, complete BA experience."
		},
		{
			property: "og:title",
			content: "1-Week Business Analyst Workshop — Skill AI India"
		},
		{
			property: "og:description",
			content: "Practical training across the complete BA lifecycle — BRD, FRD, SOP, Use Cases, UAT & more. One week, one real-world project."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
/** Auto-reveal on scroll for any element with class "reveal" */
var $$splitComponentImporter$22 = () => import("./ai.index-D938y0M0.mjs");
var Route$22 = createFileRoute("/ai/")({
	head: () => ({ meta: [{ title: "AI Programs — Skill Ai" }, {
		name: "description",
		content: "AI programs at Skill Ai: Gen AI, Agentic AI, Big Data, Data Science, Cyber Security, Data Security and AI Product Management."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./ai.advanced-data-science-CUivXgg-.mjs");
var Route$21 = createFileRoute("/ai/advanced-data-science")({
	head: () => ({ meta: [{ title: "Advanced Core Data Science — 3 Month Program | Skill Ai" }, {
		name: "description",
		content: "12-week Advanced Core Data Science program: statistics, ML, time series, deep learning, MLOps & industry capstones. 144 hours, 72 sessions."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./ai.big-data-BLEOxy-Y.mjs");
var Route$20 = createFileRoute("/ai/big-data")({
	head: () => ({ meta: [{ title: "Master's in AI, Big Data & Advanced MLOps — Skill Ai" }, {
		name: "description",
		content: "12-month Master's in AI, Big Data & Advanced MLOps — 10 modules, 275 sessions: Python, SQL/NoSQL, Data Science, Hadoop, Spark, Kafka, Cloud, Tableau/Power BI, MLOps, Deep Learning, CV, NLP, GenAI & Agentic AI."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./ai.big-data-cert-CXUSvSO8.mjs");
var Route$19 = createFileRoute("/ai/big-data-cert")({
	head: () => ({ meta: [{ title: "Certificate in Big Data — Skill Ai" }, {
		name: "description",
		content: "Fast-track certificate in Big Data engineering — Spark, Hadoop, cloud data pipelines."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./ai.cyber-security-B-GAPBL1.mjs");
var Route$18 = createFileRoute("/ai/cyber-security")({
	head: () => ({ meta: [{ title: "Expertise in Cyber Security — Skill Ai" }, {
		name: "description",
		content: "Become a cyber security expert — offensive, defensive, cloud and AI-era threats."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./ai.data-security-ociVVSEi.mjs");
var Route$17 = createFileRoute("/ai/data-security")({
	head: () => ({ meta: [{ title: "Certificate in Data Security — Skill Ai" }, {
		name: "description",
		content: "Protect data at rest, in transit and in use — a focused data security certificate."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./ai.gen-ai-Bn-61MhF.mjs");
var Route$16 = createFileRoute("/ai/gen-ai")({
	head: () => ({ meta: [{ title: "Master's in Gen AI & Agentic AI — 10 Month Program | Skill Ai" }, {
		name: "description",
		content: "Skill AI's flagship 10-month Master's in GenAI & Agentic AI — 480 hours, 9 modules, from Python foundations to multi-agent production systems with a Company-sourced capstone."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./ai.product-management-_5mmcWql.mjs");
var Route$15 = createFileRoute("/ai/product-management")({
	head: () => ({ meta: [{ title: "Advanced Product Management — Skill Ai" }, {
		name: "description",
		content: "24-week industry-embedded Advanced Product Management programme — strategy, engineering, data, AI. 288 hours, 144 sessions, 12 modules, capstone on a live partner brief."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./future-score.index-bT5XX72l.mjs");
var Route$14 = createFileRoute("/future-score/")({
	head: () => ({ meta: [
		{ title: "What's Your Future Score? — Career Discovery Game" },
		{
			name: "description",
			content: "Play a 3-minute interactive career discovery game. Answer 10 questions and reveal your future profile, strengths and skill roadmap."
		},
		{
			property: "og:title",
			content: "What's Your Future Score? — Career Discovery Game"
		},
		{
			property: "og:description",
			content: "Your interests. Your skills. Your possible future. 10 questions, 3 minutes, 1 future profile."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./future-score.admin-CZ5iBrbf.mjs");
var Route$13 = createFileRoute("/future-score/admin")({
	head: () => ({ meta: [
		{ title: "Admin Dashboard — What's Your Future Score?" },
		{
			name: "description",
			content: "Fest stall admin dashboard: participants, average future score, profile analytics and leaderboard exports."
		},
		{
			property: "og:title",
			content: "Admin Dashboard — What's Your Future Score?"
		},
		{
			property: "og:description",
			content: "Participants, analytics and leaderboard management for the career discovery game."
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./management.index-D3gTHOkb.mjs");
var Route$12 = createFileRoute("/management/")({
	head: () => ({ meta: [{ title: "Management Programs — Skill Ai" }, {
		name: "description",
		content: "Management programs at Skill Ai: business leadership, marketing, sales, finance and operations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./management.business-entrepreneurship-BuPMBvdq.mjs");
var Route$11 = createFileRoute("/management/business-entrepreneurship")({
	head: () => ({ meta: [
		{ title: "Business & Entrepreneurship Program — Skill Ai" },
		{
			name: "description",
			content: "9-month Business & Entrepreneurship program: strategy, MVP, GTM, finance, fundraising and a live Demo Day pitch."
		},
		{
			property: "og:title",
			content: "Business & Entrepreneurship Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "Build, run and scale a venture with operators, live projects and a Demo Day pitch."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./management.finance-accounting-CHVDKnec.mjs");
var Route$10 = createFileRoute("/management/finance-accounting")({
	head: () => ({ meta: [
		{ title: "Finance & Accounting Program — Skill Ai" },
		{
			name: "description",
			content: "6-month finance program: accounting, Tally & Zoho, GST, income tax, audit, FP&A, valuation and AI-assisted finance."
		},
		{
			property: "og:title",
			content: "Finance & Accounting Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "Modern finance skills — books, taxation, FP&A and valuation with live client work."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./management.marketing-growth-2ae24j98.mjs");
var Route$9 = createFileRoute("/management/marketing-growth")({
	head: () => ({ meta: [
		{ title: "Marketing & Growth Program — Skill Ai" },
		{
			name: "description",
			content: "5-month marketing program: brand, performance marketing, SEO, lifecycle, analytics and AI-powered growth experiments."
		},
		{
			property: "og:title",
			content: "Marketing & Growth Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "Brand, performance, SEO and growth — with real campaigns for partner brands."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./management.people-operations-6QdUGdfc.mjs");
var Route$8 = createFileRoute("/management/people-operations")({
	head: () => ({ meta: [
		{ title: "People & Operations Program — Skill Ai" },
		{
			name: "description",
			content: "4-month People & Operations program: hiring, onboarding, culture, performance, payroll compliance and people analytics."
		},
		{
			property: "og:title",
			content: "People & Operations Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "HR, talent ops and culture for fast-growing companies, with a live hiring drive."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./management.product-management-D43TCsbI.mjs");
var Route$7 = createFileRoute("/management/product-management")({
	head: () => ({ meta: [
		{ title: "Product Management Program — Skill Ai" },
		{
			name: "description",
			content: "6-month Product Management program: discovery, roadmaps, PRDs, agile delivery, metrics, growth and AI product work."
		},
		{
			property: "og:title",
			content: "Product Management Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "Discovery, roadmaps, metrics and shipping — for SaaS and consumer products."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./management.sales-business-development-Df5zcNyr.mjs");
var Route$6 = createFileRoute("/management/sales-business-development")({
	head: () => ({ meta: [
		{ title: "Sales & Business Development Program — Skill Ai" },
		{
			name: "description",
			content: "5-month sales program: prospecting, cold outreach, discovery, negotiation, CRM, AI selling and key account management."
		},
		{
			property: "og:title",
			content: "Sales & Business Development Program — Skill Ai"
		},
		{
			property: "og:description",
			content: "Learn B2B and B2C selling with a live pipeline and real closed deals."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./multimedia.index-CYzCuO98.mjs");
var Route$5 = createFileRoute("/multimedia/")({
	head: () => ({ meta: [{ title: "Multimedia Programs — Skill Ai" }, {
		name: "description",
		content: "AI-integrated multimedia programs at Skill Ai: graphic design, video & VFX, animation, film production and marketing."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./multimedia.ai-graphic-design-Du6o76VF.mjs");
var Route$4 = createFileRoute("/multimedia/ai-graphic-design")({
	head: () => ({ meta: [{ title: "AI Integrated Graphic Design — Skill Ai CreateX" }, {
		name: "description",
		content: "144-hour AI Integrated Graphic Design course (2027 Edition) — 8 software, 6 AI tools, 11 modules, 30–40 portfolio projects. Photoshop, Illustrator, InDesign, Figma, Lightroom, Dimension, Premiere Pro, CorelDRAW + Firefly, ChatGPT Go, Ideogram, Gemini+, Perplexity, Microsoft Designer."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./multimedia.ai-video-editing-vfx-CMA5ysWp.mjs");
var Route$3 = createFileRoute("/multimedia/ai-video-editing-vfx")({
	head: () => ({ meta: [{ title: "AI Integrated Video Editing & VFX — Skill Ai" }, {
		name: "description",
		content: "12-week AI-powered video editing and VFX program: Premiere, DaVinci, After Effects, Runway and modern AI compositing."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./multimedia.animation-vfx-Dv51M_0n.mjs");
var Route$2 = createFileRoute("/multimedia/animation-vfx")({
	head: () => ({ meta: [{ title: "Animation & VFX — Skill Ai" }, {
		name: "description",
		content: "12-week Animation & VFX program: Blender, Cinema 4D, Houdini, Nuke and AI-assisted pipelines for film and streaming."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./multimedia.film-production-B5Jz4UnC.mjs");
var Route$1 = createFileRoute("/multimedia/film-production")({
	head: () => ({ meta: [{ title: "Film Production — Skill Ai" }, {
		name: "description",
		content: "12-week end-to-end Film Production program: writing, directing, cinematography, sound and post — from script to festival."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./multimedia.pm-smm-VQetnZgB.mjs");
var Route = createFileRoute("/multimedia/pm-smm")({
	head: () => ({ meta: [{ title: "Performance Marketing & Social Media Marketing — Skill Ai" }, {
		name: "description",
		content: "12-week PM & SMM program: Meta Ads, Google Ads, SEO, GA4, content strategy and AI-powered marketing."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$31.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$32
});
var AiRoute = Route$30.update({
	id: "/ai",
	path: "/ai",
	getParentRoute: () => Route$32
});
var FutureScoreRoute = Route$29.update({
	id: "/future-score",
	path: "/future-score",
	getParentRoute: () => Route$32
});
var IncubationRoute = Route$28.update({
	id: "/incubation",
	path: "/incubation",
	getParentRoute: () => Route$32
});
var ManagementRoute = Route$27.update({
	id: "/management",
	path: "/management",
	getParentRoute: () => Route$32
});
var MultimediaRoute = Route$26.update({
	id: "/multimedia",
	path: "/multimedia",
	getParentRoute: () => Route$32
});
var OnlineProgramsRoute = Route$25.update({
	id: "/online-programs",
	path: "/online-programs",
	getParentRoute: () => Route$32
});
var OutcomesRoute = Route$24.update({
	id: "/outcomes",
	path: "/outcomes",
	getParentRoute: () => Route$32
});
var UgProgramsRoute = Route$33.update({
	id: "/ug-programs",
	path: "/ug-programs",
	getParentRoute: () => Route$32
});
var WorkshopRoute = Route$23.update({
	id: "/workshop",
	path: "/workshop",
	getParentRoute: () => Route$32
});
var AiIndexRoute = Route$22.update({
	id: "/",
	path: "/",
	getParentRoute: () => AiRoute
});
var AiAdvancedDataScienceRoute = Route$21.update({
	id: "/advanced-data-science",
	path: "/advanced-data-science",
	getParentRoute: () => AiRoute
});
var AiBigDataRoute = Route$20.update({
	id: "/big-data",
	path: "/big-data",
	getParentRoute: () => AiRoute
});
var AiBigDataCertRoute = Route$19.update({
	id: "/big-data-cert",
	path: "/big-data-cert",
	getParentRoute: () => AiRoute
});
var AiCyberSecurityRoute = Route$18.update({
	id: "/cyber-security",
	path: "/cyber-security",
	getParentRoute: () => AiRoute
});
var AiDataSecurityRoute = Route$17.update({
	id: "/data-security",
	path: "/data-security",
	getParentRoute: () => AiRoute
});
var AiGenAiRoute = Route$16.update({
	id: "/gen-ai",
	path: "/gen-ai",
	getParentRoute: () => AiRoute
});
var AiProductManagementRoute = Route$15.update({
	id: "/product-management",
	path: "/product-management",
	getParentRoute: () => AiRoute
});
var FutureScoreIndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => FutureScoreRoute
});
var FutureScoreAdminRoute = Route$13.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => FutureScoreRoute
});
var ManagementIndexRoute = Route$12.update({
	id: "/",
	path: "/",
	getParentRoute: () => ManagementRoute
});
var ManagementBusinessEntrepreneurshipRoute = Route$11.update({
	id: "/business-entrepreneurship",
	path: "/business-entrepreneurship",
	getParentRoute: () => ManagementRoute
});
var ManagementFinanceAccountingRoute = Route$10.update({
	id: "/finance-accounting",
	path: "/finance-accounting",
	getParentRoute: () => ManagementRoute
});
var ManagementMarketingGrowthRoute = Route$9.update({
	id: "/marketing-growth",
	path: "/marketing-growth",
	getParentRoute: () => ManagementRoute
});
var ManagementPeopleOperationsRoute = Route$8.update({
	id: "/people-operations",
	path: "/people-operations",
	getParentRoute: () => ManagementRoute
});
var ManagementProductManagementRoute = Route$7.update({
	id: "/product-management",
	path: "/product-management",
	getParentRoute: () => ManagementRoute
});
var ManagementSalesBusinessDevelopmentRoute = Route$6.update({
	id: "/sales-business-development",
	path: "/sales-business-development",
	getParentRoute: () => ManagementRoute
});
var MultimediaIndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => MultimediaRoute
});
var MultimediaAiGraphicDesignRoute = Route$4.update({
	id: "/ai-graphic-design",
	path: "/ai-graphic-design",
	getParentRoute: () => MultimediaRoute
});
var MultimediaAiVideoEditingVfxRoute = Route$3.update({
	id: "/ai-video-editing-vfx",
	path: "/ai-video-editing-vfx",
	getParentRoute: () => MultimediaRoute
});
var MultimediaAnimationVfxRoute = Route$2.update({
	id: "/animation-vfx",
	path: "/animation-vfx",
	getParentRoute: () => MultimediaRoute
});
var MultimediaFilmProductionRoute = Route$1.update({
	id: "/film-production",
	path: "/film-production",
	getParentRoute: () => MultimediaRoute
});
var MultimediaPmSmmRoute = Route.update({
	id: "/pm-smm",
	path: "/pm-smm",
	getParentRoute: () => MultimediaRoute
});
var PortfolioSlugRoute = Route$34.update({
	id: "/portfolio/$slug",
	path: "/portfolio/$slug",
	getParentRoute: () => Route$32
});
var AiRouteChildren = {
	AiAdvancedDataScienceRoute,
	AiBigDataRoute,
	AiBigDataCertRoute,
	AiCyberSecurityRoute,
	AiDataSecurityRoute,
	AiGenAiRoute,
	AiProductManagementRoute,
	AiIndexRoute
};
var AiRouteWithChildren = AiRoute._addFileChildren(AiRouteChildren);
var FutureScoreRouteChildren = {
	FutureScoreAdminRoute,
	FutureScoreIndexRoute
};
var FutureScoreRouteWithChildren = FutureScoreRoute._addFileChildren(FutureScoreRouteChildren);
var ManagementRouteChildren = {
	ManagementBusinessEntrepreneurshipRoute,
	ManagementFinanceAccountingRoute,
	ManagementMarketingGrowthRoute,
	ManagementPeopleOperationsRoute,
	ManagementProductManagementRoute,
	ManagementSalesBusinessDevelopmentRoute,
	ManagementIndexRoute
};
var ManagementRouteWithChildren = ManagementRoute._addFileChildren(ManagementRouteChildren);
var MultimediaRouteChildren = {
	MultimediaAiGraphicDesignRoute,
	MultimediaAiVideoEditingVfxRoute,
	MultimediaAnimationVfxRoute,
	MultimediaFilmProductionRoute,
	MultimediaPmSmmRoute,
	MultimediaIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AiRoute: AiRouteWithChildren,
	FutureScoreRoute: FutureScoreRouteWithChildren,
	IncubationRoute,
	ManagementRoute: ManagementRouteWithChildren,
	MultimediaRoute: MultimediaRoute._addFileChildren(MultimediaRouteChildren),
	OnlineProgramsRoute,
	OutcomesRoute,
	UgProgramsRoute,
	WorkshopRoute,
	PortfolioSlugRoute
};
var routeTree = Route$32._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
