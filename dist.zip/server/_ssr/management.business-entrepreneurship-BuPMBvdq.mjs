import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { $ as Handshake, D as Rocket, H as Megaphone, T as Scale, c as Users, ct as DollarSign, g as Target, kt as Briefcase, q as Lightbulb, wt as ChartColumn } from "../_libs/lucide-react.mjs";
import { t as MultimediaCourseDetail } from "./MultimediaCourseDetail-CUunzaDV.mjs";
import { t as mg_biz_default } from "./mg-biz-DCKrAivz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management.business-entrepreneurship-BuPMBvdq.js
var import_jsx_runtime = require_jsx_runtime();
var MODULES = [
	{
		n: 1,
		icon: Lightbulb,
		title: "Idea, Problem & Opportunity",
		weeks: "Month 1",
		hours: "40 hrs",
		points: [
			"Problem discovery interviews",
			"Market sizing (TAM/SAM/SOM)",
			"Idea validation sprints",
			"Competitive landscape"
		],
		color: "from-lime/30 to-emerald-500/10"
	},
	{
		n: 2,
		icon: Target,
		title: "Business Models & Strategy",
		weeks: "Month 2",
		hours: "40 hrs",
		points: [
			"Business model canvas",
			"Unit economics",
			"Pricing strategy",
			"Moats & positioning"
		],
		color: "from-cyan-500/30 to-blue-500/10"
	},
	{
		n: 3,
		icon: Rocket,
		title: "Building the MVP",
		weeks: "Month 3",
		hours: "40 hrs",
		points: [
			"No-code & AI tooling",
			"Rapid prototyping",
			"Customer feedback loops",
			"Iteration cadence"
		],
		color: "from-fuchsia-500/30 to-pink-500/10"
	},
	{
		n: 4,
		icon: Megaphone,
		title: "Go-To-Market",
		weeks: "Month 4",
		hours: "40 hrs",
		points: [
			"First 100 customers",
			"Channel strategy",
			"Sales playbooks",
			"Growth experiments"
		],
		color: "from-orange-500/30 to-amber-500/10"
	},
	{
		n: 5,
		icon: DollarSign,
		title: "Startup Finance",
		weeks: "Month 5",
		hours: "40 hrs",
		points: [
			"Financial modelling",
			"Cash flow & runway",
			"Burn & CAC/LTV",
			"Investor metrics"
		],
		color: "from-violet-500/30 to-purple-500/10"
	},
	{
		n: 6,
		icon: Users,
		title: "Team, Hiring & Culture",
		weeks: "Month 6",
		hours: "40 hrs",
		points: [
			"Founding team design",
			"Hiring first 10",
			"ESOPs & compensation",
			"Operating rhythms"
		],
		color: "from-sky-500/30 to-indigo-500/10"
	},
	{
		n: 7,
		icon: Scale,
		title: "Legal, Compliance & Ops",
		weeks: "Month 7",
		hours: "40 hrs",
		points: [
			"Company incorporation",
			"Contracts & IP",
			"GST & compliance basics",
			"Operational SOPs"
		],
		color: "from-rose-500/30 to-red-500/10"
	},
	{
		n: 8,
		icon: ChartColumn,
		title: "Scaling & Operations",
		weeks: "Month 8",
		hours: "40 hrs",
		points: [
			"Process design",
			"Dashboards & OKRs",
			"Supply chain / delivery",
			"Automation with AI"
		],
		color: "from-teal-500/30 to-cyan-500/10"
	},
	{
		n: 9,
		icon: Handshake,
		title: "Fundraising & Investor Relations",
		weeks: "Month 9",
		hours: "40 hrs",
		points: [
			"Pitch deck craft",
			"Valuation & term sheets",
			"Investor pipeline",
			"Due diligence prep"
		],
		color: "from-amber-500/30 to-yellow-500/10"
	},
	{
		n: 10,
		icon: Briefcase,
		title: "Demo Day & Launch",
		weeks: "Month 9",
		hours: "20 hrs",
		points: [
			"Live pitch to industry experts",
			"1:1 investor feedback",
			"Launch plan",
			"Incubation next steps"
		],
		color: "from-orange-500/30 to-red-500/10"
	}
];
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultimediaCourseDetail, {
	eyebrow: "Management · Entrepreneurship",
	title: "Business & Entrepreneurship",
	tagline: "Build, run and scale a real venture — strategy, finance, operations and fundraising taught by operators.",
	duration: "9 Months",
	schedule: "2 hrs/day · 6 days",
	sessions: "216 Sessions",
	totalHours: "420 Hours",
	level: "Beginner → Founder",
	mode: "Hybrid + Startup Lab",
	heroImage: mg_biz_default,
	overview: "A founder-first program where you build an actual business, not a case study. You'll validate a problem, ship an MVP, acquire paying customers, model your finances and pitch at Demo Day in front of industry experts and investors.",
	modules: MODULES,
	tools: [
		"Notion",
		"Figma",
		"Excel / Google Sheets",
		"Stripe / Razorpay",
		"HubSpot",
		"Canva",
		"ChatGPT",
		"Zapier",
		"Shopify",
		"Metabase"
	],
	capstones: [
		"Validated Problem Report",
		"Working MVP",
		"First Revenue Milestone",
		"3-Year Financial Model",
		"Investor Pitch Deck",
		"Demo Day Pitch"
	],
	outcomes: [
		"Launch and run your own venture",
		"Model unit economics and runway",
		"Build repeatable GTM motions",
		"Raise pre-seed / seed capital",
		"Hire and lead a small team",
		"Join SKILL AI's incubation network"
	]
});
//#endregion
export { SplitComponent as component };
