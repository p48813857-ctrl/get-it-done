//#region node_modules/.nitro/vite/services/ssr/assets/card-mm-graphic-BHnGFFjo.js
var card_mm_graphic_default = "/assets/card-mm-graphic-DLKiIJwN.jpg";
//#endregion
export { card_mm_graphic_default as t };
