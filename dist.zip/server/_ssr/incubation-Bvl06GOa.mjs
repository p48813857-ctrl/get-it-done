import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ApplyModal } from "./ug-programs-CAHAfbmi.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { D as Rocket, Ot as Building2, bt as CircleCheck, c as Users, ct as DollarSign, f as TrendingUp, q as Lightbulb } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/incubation-Bvl06GOa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var offerings = [
	{
		Icon: DollarSign,
		t: "₹25L Pre-seed",
		d: "Equity-free grant up to ₹25 lakh for selected founders."
	},
	{
		Icon: Users,
		t: "Founder Mentors",
		d: "1:1 mentorship from 100+ unicorn founders & VCs."
	},
	{
		Icon: Building2,
		t: "Studio & Infra",
		d: "Dedicated office, studio, hardware lab and legal stack."
	},
	{
		Icon: TrendingUp,
		t: "GTM Support",
		d: "Growth, design and tech pods to help you ship fast."
	},
	{
		Icon: Lightbulb,
		t: "Idea Validation",
		d: "Customer discovery, MVP sprints and PMF playbooks."
	},
	{
		Icon: Rocket,
		t: "Demo Day",
		d: "Pitch to 80+ top VCs at the Skill Ai Demo Day each cohort."
	}
];
var stages = [
	{
		s: "01",
		t: "Apply",
		d: "Submit your idea — solo or with co-founders. Rolling intakes every quarter."
	},
	{
		s: "02",
		t: "Discovery Sprint",
		d: "2-week paid sprint to validate your problem and customer."
	},
	{
		s: "03",
		t: "Build & Ship",
		d: "16-week incubation with funding, mentors, and a studio team."
	},
	{
		s: "04",
		t: "Demo Day",
		d: "Pitch to investors and secure follow-on funding."
	}
];
var ventures = [
	{
		name: "EverRaw Foods",
		sector: "D2C Foods",
		raise: "Shark Tank India",
		note: "₹2.5L revenue in 10 weeks on campus."
	},
	{
		name: "Bloom Skincare",
		sector: "Beauty",
		raise: "₹1Cr ARR",
		note: "Bootstrapped to profitability in 14 months."
	},
	{
		name: "Lexi AI",
		sector: "AI SaaS",
		raise: "$500K Seed",
		note: "Legal copilot used by 40+ Indian law firms."
	},
	{
		name: "Trekify",
		sector: "Travel",
		raise: "₹3Cr Seed",
		note: "Adventure trips marketplace, 8000+ bookings."
	},
	{
		name: "Pago Pay",
		sector: "Fintech",
		raise: "Angel Round",
		note: "Tap-to-pay for kirana stores in tier-2 cities."
	},
	{
		name: "Stitch Studio",
		sector: "Fashion",
		raise: "₹80L Pre-seed",
		note: "On-demand designer wear, 5x MoM growth."
	}
];
function useReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal");
		const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in-view"), io.unobserve(e.target))), { threshold: .12 });
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
function Incubation() {
	useReveal();
	const [apply, setApply] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/40 bg-background/80 backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: skill_ai_logo_default,
							alt: "SkillAI - Learn Skill Get Job",
							className: "h-9 w-auto rounded-md bg-white p-1"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm text-muted-foreground hover:text-foreground",
						children: "← Home"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden border-b border-border/40 px-6 py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_80%_30%,oklch(0.72_0.2_50/0.3),transparent_60%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl reveal",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full border border-lime/30 bg-lime/5 px-4 py-1.5 text-xs font-semibold text-lime",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "h-3.5 w-3.5" }), " Skill Ai Startup Lab"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-5 text-5xl font-black md:text-7xl",
								children: [
									"From idea to ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-lime",
										children: "first revenue"
									}),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-2xl text-lg text-muted-foreground",
								children: "Skill Ai Startup Lab gives founders capital, mentorship and a full operating team to take a venture from zero to one — in 16 weeks."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-7 flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setApply(true),
									className: "rounded-full bg-lime px-7 py-3 font-bold text-lime-foreground hover:scale-105 transition-transform animate-pulse-glow",
									children: "Apply to Incubator"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#how",
									className: "rounded-full border border-border/60 bg-background/60 px-7 py-3 font-semibold hover:bg-background",
									children: "How it works"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-14 grid max-w-7xl gap-4 sm:grid-cols-2 md:grid-cols-4",
						children: [
							{
								v: "₹25L",
								l: "Grant"
							},
							{
								v: "500+",
								l: "Ventures built"
							},
							{
								v: "₹120Cr+",
								l: "Follow-on raised"
							},
							{
								v: "80+",
								l: "VC partners"
							}
						].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i + 1} rounded-2xl border border-border/40 bg-surface p-5 text-center`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-black text-gradient-lime",
								children: s.v
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: s.l
							})]
						}, s.l))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "What you get"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
						children: offerings.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i % 5 + 1} hover-lift rounded-2xl border border-border/40 bg-surface p-6`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 place-items-center rounded-xl bg-lime/15 text-lime ring-1 ring-lime/30",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(o.Icon, { className: "h-6 w-6" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-lg font-bold",
									children: o.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: o.d
								})
							]
						}, o.t))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "how",
				className: "border-t border-border/40 bg-surface/40 px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "How it works"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-4",
						children: stages.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i + 1} relative rounded-2xl border border-border/40 bg-background p-6 hover-lift`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-4xl font-black text-lime/40",
									children: s.s
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-lg font-bold",
									children: s.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: s.d
								})
							]
						}, s.s))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "Ventures built at Skill Ai"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
						children: ventures.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i % 5 + 1} rounded-2xl border border-border/40 bg-surface p-6 hover-lift`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold",
										children: v.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-lime/15 px-2.5 py-1 text-[10px] font-bold text-lime ring-1 ring-lime/30",
										children: v.raise
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: v.sector
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm",
									children: v.note
								})
							]
						}, v.name))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-border/40 bg-surface/40 px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-black md:text-5xl reveal",
							children: "Who should apply"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-3 md:grid-cols-2",
							children: [
								"Aspiring founders aged 18–32 with an idea",
								"Student founders building during college",
								"Solo founders looking for co-founders",
								"Early teams pre-revenue or with <₹10L MRR",
								"Domain experts ready to commercialize tech",
								"Founders open to relocating to Bangalore"
							].map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `reveal reveal-delay-${i % 4 + 1} flex items-start gap-3 rounded-xl border border-border/40 bg-background p-4`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-5 w-5 shrink-0 text-lime" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: p
								})]
							}, p))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setApply(true),
								className: "rounded-full bg-lime px-7 py-3 font-bold text-lime-foreground hover:scale-105 transition-transform animate-pulse-glow",
								children: "Apply to Incubator"
							})
						})
					]
				})
			}),
			apply && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyModal, {
				program: "Skill Ai Startup Lab Incubation",
				onClose: () => setApply(false)
			})
		]
	});
}
//#endregion
export { Incubation as component };
