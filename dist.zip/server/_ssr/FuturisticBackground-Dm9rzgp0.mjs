import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FuturisticBackground-Dm9rzgp0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var profiles = {
	"ai-innovator": {
		id: "ai-innovator",
		emoji: "🤖",
		name: "AI Innovator",
		tagline: "Generative AI • AI Agents • Automation",
		description: "You naturally enjoy experimenting, solving problems and exploring how technology can create new possibilities.",
		strengths: [
			{
				emoji: "🧠",
				label: "Curiosity"
			},
			{
				emoji: "💡",
				label: "Creativity"
			},
			{
				emoji: "🔧",
				label: "Experimentation"
			},
			{
				emoji: "⚡",
				label: "Problem Solving"
			},
			{
				emoji: "🚀",
				label: "Innovation"
			}
		],
		enjoy: [
			{
				emoji: "🤖",
				label: "Generative AI"
			},
			{
				emoji: "🧠",
				label: "AI Applications"
			},
			{
				emoji: "⚙️",
				label: "Automation"
			},
			{
				emoji: "💬",
				label: "Prompt Engineering"
			},
			{
				emoji: "🔗",
				label: "AI Agents"
			}
		],
		careers: [
			{
				emoji: "🤖",
				label: "AI Specialist"
			},
			{
				emoji: "🧠",
				label: "AI Application Developer"
			},
			{
				emoji: "⚙️",
				label: "Automation Specialist"
			},
			{
				emoji: "💬",
				label: "GenAI Professional"
			}
		],
		accent: "secondary"
	},
	"data-explorer": {
		id: "data-explorer",
		emoji: "📊",
		name: "Data Explorer",
		tagline: "Analytics • Statistics • Machine Learning",
		description: "You love finding the story hidden inside numbers, spotting patterns and turning raw data into clear decisions.",
		strengths: [
			{
				emoji: "🧠",
				label: "Analytical Thinking"
			},
			{
				emoji: "📊",
				label: "Pattern Recognition"
			},
			{
				emoji: "🔎",
				label: "Attention to Detail"
			},
			{
				emoji: "📈",
				label: "Logical Thinking"
			},
			{
				emoji: "💡",
				label: "Insight Generation"
			}
		],
		enjoy: [
			{
				emoji: "📊",
				label: "Data Analytics"
			},
			{
				emoji: "📈",
				label: "Power BI"
			},
			{
				emoji: "🐍",
				label: "Python"
			},
			{
				emoji: "🧠",
				label: "Machine Learning"
			},
			{
				emoji: "📊",
				label: "Data Visualization"
			}
		],
		careers: [
			{
				emoji: "📊",
				label: "Data Analyst"
			},
			{
				emoji: "📈",
				label: "Business Intelligence Analyst"
			},
			{
				emoji: "🧠",
				label: "Data Scientist"
			},
			{
				emoji: "🤖",
				label: "Machine Learning Professional"
			}
		],
		accent: "secondary"
	},
	"tech-builder": {
		id: "tech-builder",
		emoji: "💻",
		name: "Tech Builder",
		tagline: "Software • Web • Apps • Product",
		description: "You like making things real. Give you an idea and you'll turn it into a working product people can actually use.",
		strengths: [
			{
				emoji: "🔧",
				label: "Building"
			},
			{
				emoji: "💻",
				label: "Technical Thinking"
			},
			{
				emoji: "🧠",
				label: "Problem Solving"
			},
			{
				emoji: "⚡",
				label: "Execution"
			},
			{
				emoji: "🚀",
				label: "Product Thinking"
			}
		],
		enjoy: [
			{
				emoji: "💻",
				label: "Web Development"
			},
			{
				emoji: "📱",
				label: "App Development"
			},
			{
				emoji: "⚛️",
				label: "React"
			},
			{
				emoji: "🐍",
				label: "Python"
			},
			{
				emoji: "☁️",
				label: "Cloud Technology"
			}
		],
		careers: [
			{
				emoji: "💻",
				label: "Full Stack Developer"
			},
			{
				emoji: "📱",
				label: "Application Developer"
			},
			{
				emoji: "⚛️",
				label: "Frontend Developer"
			},
			{
				emoji: "⚙️",
				label: "Software Engineer"
			}
		],
		accent: "primary"
	},
	"cyber-guardian": {
		id: "cyber-guardian",
		emoji: "🔐",
		name: "Cyber Guardian",
		tagline: "Security • Ethical Hacking • Threat Detection",
		description: "You think like a detective. You notice risk early and enjoy protecting people and systems from what they can't see.",
		strengths: [
			{
				emoji: "🔐",
				label: "Security Mindset"
			},
			{
				emoji: "🔎",
				label: "Investigation"
			},
			{
				emoji: "🧠",
				label: "Logical Thinking"
			},
			{
				emoji: "⚡",
				label: "Risk Awareness"
			},
			{
				emoji: "🛡️",
				label: "Problem Solving"
			}
		],
		enjoy: [
			{
				emoji: "🔐",
				label: "Cybersecurity"
			},
			{
				emoji: "🛡️",
				label: "Ethical Hacking"
			},
			{
				emoji: "🌐",
				label: "Network Security"
			},
			{
				emoji: "🔎",
				label: "Threat Detection"
			},
			{
				emoji: "🔒",
				label: "Digital Forensics"
			}
		],
		careers: [
			{
				emoji: "🔐",
				label: "Cybersecurity Analyst"
			},
			{
				emoji: "🛡️",
				label: "Security Engineer"
			},
			{
				emoji: "🔎",
				label: "Ethical Hacker"
			},
			{
				emoji: "🌐",
				label: "Security Specialist"
			}
		],
		accent: "primary"
	},
	"business-strategist": {
		id: "business-strategist",
		emoji: "📈",
		name: "Business Strategist",
		tagline: "Strategy • Marketing • Growth",
		description: "You see the bigger picture. You connect people, numbers and ideas into decisions that move a business forward.",
		strengths: [
			{
				emoji: "📈",
				label: "Strategic Thinking"
			},
			{
				emoji: "💡",
				label: "Creativity"
			},
			{
				emoji: "🧠",
				label: "Decision Making"
			},
			{
				emoji: "🎯",
				label: "Goal Orientation"
			},
			{
				emoji: "🚀",
				label: "Leadership"
			}
		],
		enjoy: [
			{
				emoji: "📈",
				label: "Business Analytics"
			},
			{
				emoji: "📣",
				label: "Marketing"
			},
			{
				emoji: "💼",
				label: "Strategy"
			},
			{
				emoji: "🚀",
				label: "Entrepreneurship"
			},
			{
				emoji: "📊",
				label: "Business Intelligence"
			}
		],
		careers: [
			{
				emoji: "📈",
				label: "Business Analyst"
			},
			{
				emoji: "📊",
				label: "Marketing Analyst"
			},
			{
				emoji: "🚀",
				label: "Growth Strategist"
			},
			{
				emoji: "💼",
				label: "Business Consultant"
			}
		],
		accent: "secondary"
	}
};
var profileOrder = [
	"ai-innovator",
	"data-explorer",
	"tech-builder",
	"cyber-guardian",
	"business-strategist"
];
var opt = (key, emoji, label, profile) => ({
	key,
	emoji,
	label,
	profile
});
var questions = [
	{
		id: 1,
		prompt: "You're given ₹1 lakh to build something.",
		sub: "What would you create?",
		options: [
			opt("A", "📊", "A dashboard that explains data", "data-explorer"),
			opt("B", "📱", "A mobile app", "tech-builder"),
			opt("C", "🔐", "A system that protects people from hackers", "cyber-guardian"),
			opt("D", "🤖", "An AI-powered assistant", "ai-innovator"),
			opt("E", "📈", "A tool that helps a business make better decisions", "business-strategist")
		]
	},
	{
		id: 2,
		prompt: "Which challenge sounds the most exciting?",
		options: [
			opt("A", "🔍", "Find the hidden pattern in a huge dataset", "data-explorer"),
			opt("B", "🛠️", "Build something from scratch", "tech-builder"),
			opt("C", "🕵️", "Catch a hacker using clues", "cyber-guardian"),
			opt("D", "🤖", "Make AI do something nobody expected", "ai-innovator"),
			opt("E", "📉", "Figure out why a business is losing customers", "business-strategist")
		]
	},
	{
		id: 3,
		prompt: "You have 30 minutes of free time.",
		sub: "What would you rather do?",
		options: [
			opt("A", "🔢", "Play with numbers / data", "data-explorer"),
			opt("B", "🧱", "Create or build something", "tech-builder"),
			opt("C", "🧩", "Solve a mystery", "cyber-guardian"),
			opt("D", "⚡", "Experiment with AI", "ai-innovator"),
			opt("E", "💡", "Plan an idea / business", "business-strategist")
		]
	},
	{
		id: 4,
		prompt: "Which superpower would you choose?",
		options: [
			opt("A", "👁️", "See patterns nobody else can see", "data-explorer"),
			opt("B", "🏗️", "Build anything instantly", "tech-builder"),
			opt("C", "🛡️", "Detect every security threat", "cyber-guardian"),
			opt("D", "🧠", "Talk to any AI and make it do exactly what you want", "ai-innovator"),
			opt("E", "🔮", "Predict what people will buy", "business-strategist")
		]
	},
	{
		id: 5,
		prompt: "Your team gives you a difficult problem.",
		sub: "What is your first reaction?",
		options: [
			opt("A", "📊", "Analyze the information", "data-explorer"),
			opt("B", "⚙️", "Start building a solution", "tech-builder"),
			opt("C", "🔎", "Investigate what went wrong", "cyber-guardian"),
			opt("D", "🤖", "Ask AI for possibilities and experiment", "ai-innovator"),
			opt("E", "💼", "Understand the business impact", "business-strategist")
		]
	},
	{
		id: 6,
		prompt: "Which project would you enjoy working on?",
		options: [
			opt("A", "📈", "Predicting future trends using data", "data-explorer"),
			opt("B", "💻", "Building a useful application", "tech-builder"),
			opt("C", "🔐", "Creating a cybersecurity system", "cyber-guardian"),
			opt("D", "💬", "Building an AI chatbot or agent", "ai-innovator"),
			opt("E", "🚀", "Creating a strategy for a growing company", "business-strategist")
		]
	},
	{
		id: 7,
		prompt: "Which subject sounds most interesting?",
		options: [
			opt("A", "📊", "Data & Statistics", "data-explorer"),
			opt("B", "💻", "Programming & Technology", "tech-builder"),
			opt("C", "🔐", "Cybersecurity", "cyber-guardian"),
			opt("D", "🤖", "Artificial Intelligence", "ai-innovator"),
			opt("E", "📣", "Business & Marketing", "business-strategist")
		]
	},
	{
		id: 8,
		prompt: "Your friend wants to start a startup.",
		sub: "What would you be most interested in doing?",
		options: [
			opt("A", "📊", "Analyze customer data", "data-explorer"),
			opt("B", "🛠️", "Build the product", "tech-builder"),
			opt("C", "🔒", "Secure the platform", "cyber-guardian"),
			opt("D", "🤖", "Add AI capabilities", "ai-innovator"),
			opt("E", "📈", "Create the growth strategy", "business-strategist")
		]
	},
	{
		id: 9,
		prompt: "Which achievement would make you most proud?",
		options: [
			opt("A", "🔍", "Discovering an important pattern in data", "data-explorer"),
			opt("B", "📱", "Building an application used by thousands of people", "tech-builder"),
			opt("C", "🛡️", "Stopping a major cyber attack", "cyber-guardian"),
			opt("D", "🤖", "Creating an AI system that solves a real problem", "ai-innovator"),
			opt("E", "🚀", "Helping a company grow dramatically", "business-strategist")
		]
	},
	{
		id: 10,
		prompt: "Imagine yourself 5 years from now.",
		sub: "Which sounds most exciting?",
		options: [
			opt("A", "📊", "Working with data and discovering insights", "data-explorer"),
			opt("B", "💻", "Building technology products", "tech-builder"),
			opt("C", "🔐", "Protecting organizations from cyber threats", "cyber-guardian"),
			opt("D", "🤖", "Creating the next generation of AI applications", "ai-innovator"),
			opt("E", "📈", "Leading business and technology strategies", "business-strategist")
		]
	}
];
function calculateResult(answers) {
	const raw = Object.fromEntries(profileOrder.map((p) => [p, 0]));
	for (const q of questions) {
		const key = answers[q.id];
		if (!key) continue;
		const option = q.options.find((o) => o.key === key);
		if (option) raw[option.profile] += 10;
	}
	const max = Math.max(...profileOrder.map((p) => raw[p]), 10);
	const percentages = Object.fromEntries(profileOrder.map((p) => {
		const base = raw[p] / max;
		const percent = Math.round(35 + base * 57);
		return [p, Math.min(95, percent)];
	}));
	const ranked = profileOrder.map((id) => ({
		id,
		percent: percentages[id],
		raw: raw[id]
	})).sort((a, b) => b.raw - a.raw || b.percent - a.percent).map(({ id, percent }) => ({
		id,
		percent
	}));
	const top = ranked[0].id;
	percentages[top] = Math.max(percentages[top], 80);
	ranked[0].percent = percentages[top];
	const consistency = raw[top] / 100;
	return {
		raw,
		percentages,
		ranked,
		top,
		futureScore: Math.min(99, Math.round(62 + consistency * 33))
	};
}
var KEY = "fs_leaderboard_v1";
var seed = [
	{
		id: "s1",
		name: "Rahul",
		college: "",
		score: 96,
		profile: "ai-innovator",
		timestamp: 0
	},
	{
		id: "s2",
		name: "Ananya",
		college: "",
		score: 94,
		profile: "data-explorer",
		timestamp: 0
	},
	{
		id: "s3",
		name: "Arjun",
		college: "",
		score: 92,
		profile: "tech-builder",
		timestamp: 0
	},
	{
		id: "s4",
		name: "Student 04",
		college: "",
		score: 90,
		profile: "cyber-guardian",
		timestamp: 0
	},
	{
		id: "s5",
		name: "Student 05",
		college: "",
		score: 88,
		profile: "business-strategist",
		timestamp: 0
	}
];
function getLeaderboard() {
	if (typeof window === "undefined") return seed;
	try {
		const stored = window.localStorage.getItem(KEY);
		if (!stored) return seed;
		const parsed = JSON.parse(stored);
		if (!Array.isArray(parsed)) return seed;
		return parsed;
	} catch {
		return seed;
	}
}
function saveLeaderboard(entries) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(KEY, JSON.stringify(entries));
	} catch {}
}
function addLeaderboardEntry(entry) {
	const id = `p_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
	const full = {
		...entry,
		id,
		timestamp: Date.now()
	};
	const entries = [...getLeaderboard(), full].sort((a, b) => b.score - a.score || a.timestamp - b.timestamp);
	saveLeaderboard(entries);
	return {
		entries,
		rank: entries.findIndex((e) => e.id === id) + 1,
		id
	};
}
function resetLeaderboard() {
	saveLeaderboard(seed);
}
function exportCsv(entries) {
	return [[
		"Name",
		"College",
		"Contact",
		"Future Score",
		"Top Profile",
		"Date",
		"Time"
	], ...entries.map((e) => {
		const d = e.timestamp ? new Date(e.timestamp) : null;
		return [
			e.name,
			e.college ?? "",
			e.contact ?? "",
			String(e.score),
			e.profile,
			d ? d.toLocaleDateString() : "—",
			d ? d.toLocaleTimeString() : "—"
		];
	})].map((r) => r.map((c) => `"${String(c).replace(/"/g, "\"\"")}"`).join(",")).join("\n");
}
function FuturisticBackground({ intensity = "high" }) {
	const [particles, setParticles] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setParticles(Array.from({ length: intensity === "high" ? 28 : 14 }, (_, i) => ({
			id: i,
			left: Math.random() * 100,
			delay: Math.random() * 14,
			duration: 12 + Math.random() * 14,
			size: 2 + Math.random() * 4,
			blue: Math.random() > .5
		})));
	}, [intensity]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-hidden": true,
		className: "pointer-events-none fixed inset-0 -z-10 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-background" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-bg absolute inset-0 opacity-70",
				style: { animation: "grid-pan 8s linear infinite" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute -left-40 top-[-10rem] h-[36rem] w-[36rem] rounded-full bg-primary/25 blur-[140px]",
				style: { animation: "fs-pulse-glow 7s ease-in-out infinite" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute -right-40 bottom-[-12rem] h-[40rem] w-[40rem] rounded-full bg-secondary/25 blur-[150px]",
				style: { animation: "fs-pulse-glow 9s ease-in-out infinite" }
			}),
			particles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `absolute bottom-[-10vh] rounded-full ${p.blue ? "bg-secondary" : "bg-primary"}`,
				style: {
					left: `${p.left}%`,
					width: p.size,
					height: p.size,
					animation: `float-up ${p.duration}s linear ${p.delay}s infinite`,
					opacity: 0
				}
			}, p.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,transparent_10%,oklch(0.13_0.012_265/85%)_100%)]" })
		]
	});
}
//#endregion
export { getLeaderboard as a, questions as c, exportCsv as i, resetLeaderboard as l, addLeaderboardEntry as n, profileOrder as o, calculateResult as r, profiles as s, FuturisticBackground as t, saveLeaderboard as u };
