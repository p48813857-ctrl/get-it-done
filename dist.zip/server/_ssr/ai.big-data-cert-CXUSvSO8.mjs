import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { ut as Cpu } from "../_libs/lucide-react.mjs";
import { t as CourseDetail } from "./CourseDetail-CNqkmJuu.mjs";
import { t as card_bd_cert_default } from "./card-bd-cert-CLLppQO1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.big-data-cert-CXUSvSO8.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseDetail, {
	eyebrow: "Certificate Program",
	title: "Certificate in Big Data",
	tagline: "A focused sprint into distributed data systems — perfect for working professionals.",
	Icon: Cpu,
	heroImage: card_bd_cert_default,
	duration: "6 months",
	level: "Beginner → Intermediate",
	mode: "Online",
	tools: [
		"SQL",
		"Python",
		"Apache Spark",
		"Hadoop HDFS",
		"Hive",
		"Kafka",
		"Airflow",
		"AWS S3",
		"AWS EMR",
		"Snowflake",
		"dbt",
		"Docker"
	],
	roadmap: [
		{
			phase: "Module 1",
			title: "Data Foundations",
			points: [
				"SQL mastery",
				"Python for data",
				"Data warehousing concepts",
				"ETL vs ELT"
			]
		},
		{
			phase: "Module 2",
			title: "Distributed Compute",
			points: [
				"Hadoop ecosystem",
				"Spark core + SparkSQL",
				"PySpark hands-on",
				"Performance tuning"
			]
		},
		{
			phase: "Module 3",
			title: "Streaming & Cloud",
			points: [
				"Kafka streaming",
				"AWS data services",
				"Snowflake warehousing",
				"Orchestration with Airflow"
			]
		},
		{
			phase: "Module 4",
			title: "Capstone",
			points: [
				"Build an end-to-end pipeline",
				"Real dataset project",
				"Certificate exam",
				"Job portfolio"
			]
		}
	],
	outcomes: [
		"Become a Big Data Engineer",
		"Build scalable ETL pipelines",
		"Work with petabyte-scale data",
		"Transition into data careers",
		"Get cloud data certifications",
		"Land 8-18 LPA offers"
	],
	careerRoles: [
		{
			role: "Big Data Engineer",
			anchor: "M1, M2",
			desc: "Design SQL, Python & warehousing foundations for scalable data platforms"
		},
		{
			role: "Spark / Hadoop Developer",
			anchor: "M2",
			desc: "Build distributed batch pipelines with Spark, SparkSQL and PySpark"
		},
		{
			role: "Streaming Data Engineer",
			anchor: "M3",
			desc: "Real-time pipelines with Kafka, AWS EMR and Snowflake"
		},
		{
			role: "Cloud Data Engineer",
			anchor: "M3",
			desc: "AWS S3 / EMR data services with Airflow orchestration"
		},
		{
			role: "Analytics Engineer",
			anchor: "M1, M3",
			desc: "Model warehouses with dbt, Snowflake and modern ELT"
		},
		{
			role: "ETL Developer",
			anchor: "M1, M4",
			desc: "Ship production-grade pipelines and pass certification"
		}
	]
});
//#endregion
export { SplitComponent as component };
