import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { E as RotateCcw, p as Trash2, st as Download } from "../_libs/lucide-react.mjs";
import { a as getLeaderboard, i as exportCsv, l as resetLeaderboard, o as profileOrder, s as profiles, t as FuturisticBackground, u as saveLeaderboard } from "./FuturisticBackground-Dm9rzgp0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/future-score.admin-CZ5iBrbf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminDashboard() {
	const [entries, setEntries] = (0, import_react.useState)(() => getLeaderboard());
	const stats = (0, import_react.useMemo)(() => {
		const total = entries.length;
		const avg = total ? Math.round(entries.reduce((s, e) => s + e.score, 0) / total) : 0;
		const counts = Object.fromEntries(profileOrder.map((p) => [p, 0]));
		entries.forEach((e) => counts[e.profile] = (counts[e.profile] ?? 0) + 1);
		const topProfile = profileOrder.slice().sort((a, b) => (counts[b] ?? 0) - (counts[a] ?? 0))[0] ?? "ai-innovator";
		const startOfDay = /* @__PURE__ */ new Date();
		startOfDay.setHours(0, 0, 0, 0);
		return {
			total,
			avg,
			counts,
			topProfile,
			today: entries.filter((e) => e.timestamp >= startOfDay.getTime()).length
		};
	}, [entries]);
	const update = (next) => {
		saveLeaderboard(next);
		setEntries(next);
	};
	const download = () => {
		const blob = new Blob([exportCsv(entries)], { type: "text/csv" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "future-score-participants.csv";
		a.click();
		URL.revokeObjectURL(url);
	};
	const sorted = [...entries].sort((a, b) => b.score - a.score);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FuturisticBackground, { intensity: "low" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display text-3xl font-black uppercase tracking-wide sm:text-4xl",
					children: ["Admin ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient",
						children: "Dashboard"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "Future Score — college fest stall analytics"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: download,
						className: "glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium hover:border-secondary/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Export CSV"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							resetLeaderboard();
							setEntries(getLeaderboard());
						},
						className: "glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium hover:border-primary/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Reset Leaderboard"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					{
						label: "Total Participants",
						value: stats.total
					},
					{
						label: "Average Future Score",
						value: stats.avg
					},
					{
						label: "Top Career Profile",
						value: profiles[stats.topProfile].name
					},
					{
						label: "Today's Participants",
						value: stats.today
					}
				].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-2xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs uppercase tracking-[0.25em] text-muted-foreground",
						children: card.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-3xl font-black text-gradient",
						children: card.value
					})]
				}, card.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 grid gap-6 lg:grid-cols-[2fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass overflow-hidden rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "border-b border-border px-5 py-4 font-display text-sm uppercase tracking-[0.25em] text-muted-foreground",
						children: "Participants"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-left text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b border-border",
									children: [
										"Name",
										"College",
										"Score",
										"Top Profile",
										"Date",
										"Time",
										""
									].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: h
									}, h))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [sorted.map((e) => {
								const d = e.timestamp ? new Date(e.timestamp) : null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/60 last:border-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-medium",
											children: e.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-muted-foreground",
											children: e.college || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-display font-bold text-secondary",
											children: e.score
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3",
											children: [
												profiles[e.profile].emoji,
												" ",
												profiles[e.profile].name
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-muted-foreground",
											children: d ? d.toLocaleDateString() : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-muted-foreground",
											children: d ? d.toLocaleTimeString() : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												"aria-label": `Delete ${e.name}`,
												onClick: () => update(entries.filter((x) => x.id !== e.id)),
												className: "rounded-lg p-2 text-muted-foreground transition-colors hover:bg-primary/15 hover:text-primary",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
											})
										})
									]
								}, e.id);
							}), sorted.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "px-4 py-8 text-center text-muted-foreground",
								children: "No participants yet."
							}) })] })]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass rounded-2xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-sm uppercase tracking-[0.25em] text-muted-foreground",
							children: "Profile Analytics"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 grid gap-4",
							children: profileOrder.map((id) => {
								const pct = stats.total ? Math.round((stats.counts[id] ?? 0) / stats.total * 100) : 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										profiles[id].emoji,
										" ",
										profiles[id].name
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-display font-bold text-secondary",
										children: [pct, "%"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-2 overflow-hidden rounded-full bg-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full transition-[width] duration-500",
										style: {
											width: `${pct}%`,
											background: "var(--gradient-hero)"
										}
									})
								})] }, id);
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass rounded-2xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-sm uppercase tracking-[0.25em] text-muted-foreground",
							children: "Leaderboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-4 grid gap-2 text-sm",
							children: sorted.slice(0, 10).map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 rounded-lg bg-muted/40 px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-5 text-muted-foreground",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 truncate",
										children: e.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display font-bold text-secondary",
										children: e.score
									})
								]
							}, e.id))
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { AdminDashboard as component };
