//#region node_modules/.nitro/vite/services/ssr/assets/card-ads-DR6958aP.js
var card_ads_default = "/assets/card-ads-DJ-iK2Fr.jpg";
//#endregion
export { card_ads_default as t };
