import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ApplyModal } from "./ug-programs-CAHAfbmi.mjs";
import { t as skill_ai_logo_default } from "./skill-ai-logo-B_NXSqQa.mjs";
import { Ft as ArrowRight, c as Users, ct as DollarSign, f as TrendingUp, g as Target, ht as Clock, kt as Briefcase, wt as ChartColumn, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as mg_biz_default } from "./mg-biz-DCKrAivz.mjs";
import { t as mg_fin_default } from "./mg-fin-D0aO7488.mjs";
import { t as mg_sales_default } from "./mg-sales-BJSL2_Kn.mjs";
import { t as mg_mkt_default } from "./mg-mkt-BbnM-uVa.mjs";
import { t as mg_ppl_default } from "./mg-ppl-CW2SFMoA.mjs";
import { t as mg_pm_default } from "./mg-pm-Cqie_UoE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management.index-D3gTHOkb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tracks = [
	{
		Icon: Briefcase,
		img: mg_biz_default,
		slug: "business-entrepreneurship",
		title: "Business & Entrepreneurship",
		desc: "Build, run and scale a venture. Strategy, finance, ops and fundraising — taught by operators.",
		dur: "9 months",
		skills: [
			"Strategy",
			"Finance",
			"Ops",
			"Fundraising"
		]
	},
	{
		Icon: TrendingUp,
		img: mg_sales_default,
		slug: "sales-business-development",
		title: "Sales & Business Development",
		desc: "B2B and B2C selling, pipeline building, key account management and partnerships.",
		dur: "5 months",
		skills: [
			"B2B Sales",
			"CRM",
			"Negotiation"
		]
	},
	{
		Icon: Target,
		img: mg_mkt_default,
		slug: "marketing-growth",
		title: "Marketing & Growth",
		desc: "Performance marketing, brand, content and growth experiments with AI tools.",
		dur: "5 months",
		skills: [
			"Performance",
			"Brand",
			"SEO",
			"Growth"
		]
	},
	{
		Icon: DollarSign,
		img: mg_fin_default,
		slug: "finance-accounting",
		title: "Finance & Accounting",
		desc: "Modern finance — books, taxation, fintech, valuation and FP&A.",
		dur: "6 months",
		skills: [
			"FP&A",
			"Tax",
			"Audit",
			"Valuation"
		]
	},
	{
		Icon: Users,
		img: mg_ppl_default,
		slug: "people-operations",
		title: "People & Operations",
		desc: "HR, talent ops, culture and scaling teams in fast-growing companies.",
		dur: "4 months",
		skills: [
			"Hiring",
			"Ops",
			"Culture"
		]
	},
	{
		Icon: ChartColumn,
		img: mg_pm_default,
		slug: "product-management",
		title: "Product Management",
		desc: "Discovery, roadmaps, metrics and shipping — for SaaS and consumer products.",
		dur: "6 months",
		skills: [
			"Discovery",
			"Roadmap",
			"Metrics",
			"PRDs"
		]
	}
];
function useReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll(".reveal");
		const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in-view"), io.unobserve(e.target))), { threshold: .12 });
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
function Management() {
	useReveal();
	const [apply, setApply] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/40 bg-background/80 backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: skill_ai_logo_default,
							alt: "SkillAI - Learn Skill Get Job",
							className: "h-9 w-auto rounded-md bg-white p-1"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm text-muted-foreground hover:text-foreground",
						children: "← Home"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden border-b border-border/40 px-6 py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_20%,oklch(0.72_0.2_50/0.25),transparent_60%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl reveal",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-lime/30 bg-lime/5 px-4 py-1.5 text-xs font-semibold text-lime",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), " Management"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-5xl font-black tracking-tight md:text-7xl",
							children: [
								"Lead, sell, build, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-lime",
									children: "scale"
								}),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-2xl text-lg text-muted-foreground",
							children: "Management programs taught by founders, operators and CXOs — with live projects from partner companies."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-7xl gap-7 md:grid-cols-2 lg:grid-cols-3",
					children: tracks.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `reveal reveal-delay-${i % 4 + 1} hover-lift group relative overflow-hidden flex h-full flex-col rounded-3xl border border-border/50 bg-surface transition-all hover:border-lime/60`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: `/management/${t.slug}`,
							className: "block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-44 overflow-hidden",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: t.img,
										alt: t.title,
										loading: "lazy",
										className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-surface via-surface/40 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute right-3 top-3 grid h-11 w-11 place-items-center rounded-xl bg-lime/90 text-lime-foreground shadow-lg transition-transform duration-500 group-hover:rotate-6 group-hover:scale-110",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.Icon, { className: "h-5 w-5" })
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: `/management/${t.slug}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black hover:text-lime transition-colors",
										children: t.title
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: t.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), t.dur]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: t.skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-background/60 px-3 py-1 text-xs text-muted-foreground ring-1 ring-border/40",
										children: s
									}, s))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-auto flex gap-2 pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApply(t.title),
										className: "inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-lime-foreground hover:scale-105 transition-transform",
										children: ["Apply Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: `/management/${t.slug}`,
										className: "inline-flex items-center justify-center rounded-full border border-border px-5 py-2.5 text-sm font-bold hover:bg-background transition-colors",
										children: "Explore"
									})]
								})
							]
						})]
					}, t.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-border/40 bg-surface/50 px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-black md:text-5xl reveal",
						children: "Why Skill Ai Management?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-6 md:grid-cols-3",
						children: [
							{
								t: "Operator-led",
								d: "Every course taught by working founders and CXOs."
							},
							{
								t: "Live Projects",
								d: "Real consulting briefs from partner companies."
							},
							{
								t: "Placement Network",
								d: "200+ hiring partners across startups & enterprises."
							}
						].map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `reveal reveal-delay-${i + 1} rounded-2xl border border-border/40 bg-background p-6 hover-lift`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-bold",
								children: b.t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: b.d
							})]
						}, b.t))
					})]
				})
			}),
			apply && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyModal, {
				program: apply,
				onClose: () => setApply(null)
			})
		]
	});
}
//#endregion
export { Management as component };
