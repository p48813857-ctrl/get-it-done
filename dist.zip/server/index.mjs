globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-15T07:18:24.374Z",
		"size": 160,
		"path": "../client/robots.txt"
	},
	"/assets/FuturisticBackground-CJttpVxS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fe3-2skk1hyPtrVNjBsO1Pzd2Wn+bzE\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 12259,
		"path": "../client/assets/FuturisticBackground-CJttpVxS.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-15T07:18:24.374Z",
		"size": 20373,
		"path": "../client/favicon.ico"
	},
	"/assets/CourseDetail-D-BWTTbk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f18-qOWK0C7lTdIVhT30xD04eGKpPwQ\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 12056,
		"path": "../client/assets/CourseDetail-D-BWTTbk.js"
	},
	"/assets/MultimediaCourseDetail-CiDMlxd0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4591-PZ2Nqy15oCyoWhF7wJkTQ5AxhHg\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 17809,
		"path": "../client/assets/MultimediaCourseDetail-CiDMlxd0.js"
	},
	"/assets/ai.big-data-cert-Ddg_iSYs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7d7-UM9kKs5wH8Y1E4rfkt53Zwrl/RA\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 2007,
		"path": "../client/assets/ai.big-data-cert-Ddg_iSYs.js"
	},
	"/assets/ai.advanced-data-science-DlqUUr0K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75bd-ryZeEUSyg6HbIvYFkuyrR/SoD44\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 30141,
		"path": "../client/assets/ai.advanced-data-science-DlqUUr0K.js"
	},
	"/assets/ai-B0fx_eZP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-0zH+OI9TGv9x2JnUhuNAZygOcDE\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 141,
		"path": "../client/assets/ai-B0fx_eZP.js"
	},
	"/assets/ai.big-data-B_v-WXT0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"227d-m7L1Ccj0C+qVgQSlJG1xZoVic6g\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 8829,
		"path": "../client/assets/ai.big-data-B_v-WXT0.js"
	},
	"/assets/ai.gen-ai-BOPr5MRh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"78bb-LwE300jQIDi4YOT1anoX9XJkI3Y\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 30907,
		"path": "../client/assets/ai.gen-ai-BOPr5MRh.js"
	},
	"/assets/ai.data-security-QPyrHa69.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82d-BTw5txzS6Jhlua6uwACFfsPQLGo\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 2093,
		"path": "../client/assets/ai.data-security-QPyrHa69.js"
	},
	"/assets/ai.product-management-riwYh3FP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b78-y85HF9kLDUUu0eEcxmr1AQ/Z860\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 7032,
		"path": "../client/assets/ai.product-management-riwYh3FP.js"
	},
	"/assets/arrow-right-t5kLs4TR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-FViTaXl04ccaK/bR3nLFgE5JOWM\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 165,
		"path": "../client/assets/arrow-right-t5kLs4TR.js"
	},
	"/assets/award-CHHb8Lm4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"112-gZZVnaH4GfnardQoHBt4+wUSEFo\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 274,
		"path": "../client/assets/award-CHHb8Lm4.js"
	},
	"/assets/book-open-CCCN4OvP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-slAMD/2PRhNUUJupR0ZXDaJi06w\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 279,
		"path": "../client/assets/book-open-CCCN4OvP.js"
	},
	"/assets/ai.index-D0pU--7s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d38-+cfrnh2swkcKbKpTlCM0BSs+CQM\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 7480,
		"path": "../client/assets/ai.index-D0pU--7s.js"
	},
	"/assets/briefcase-Ujus5eMn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-ZOCSNpWNtyDR4GNsC93HK+vJS7w\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 220,
		"path": "../client/assets/briefcase-Ujus5eMn.js"
	},
	"/assets/ai.cyber-security-ChYaHLb6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e8-I1GlGfKfOf53l5nf4m3IDudztqk\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 2024,
		"path": "../client/assets/ai.cyber-security-ChYaHLb6.js"
	},
	"/assets/card-bd-cert-BLLxYa3n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39-fwHf2gzCi572P+YxTRhGrViVkqM\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 57,
		"path": "../client/assets/card-bd-cert-BLLxYa3n.js"
	},
	"/assets/building-2-D2szo2UC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17f-0tPCARYC2YZ0dzhklohZ6nT0Y5g\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 383,
		"path": "../client/assets/building-2-D2szo2UC.js"
	},
	"/assets/brain-C2j6qV9X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"241-cdEblYJiAg7M5UttF6WHF3nF+HY\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 577,
		"path": "../client/assets/brain-C2j6qV9X.js"
	},
	"/assets/calendar-SD3Xr6ew.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-5bomezSBb0jkFzBqMHyY64mXAoE\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 257,
		"path": "../client/assets/calendar-SD3Xr6ew.js"
	},
	"/assets/card-bd-cert-DcHG_47b.jpg": {
		"type": "image/jpeg",
		"etag": "\"15867-UjF9iaGjodYTlyHK+KRZIY+fRr0\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 88167,
		"path": "../client/assets/card-bd-cert-DcHG_47b.jpg"
	},
	"/assets/calculator-CVTxiifz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"212-SZZhlXx8FNBdDApnfddX5ud6Mxc\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 530,
		"path": "../client/assets/calculator-CVTxiifz.js"
	},
	"/assets/card-ads-DJ-iK2Fr.jpg": {
		"type": "image/jpeg",
		"etag": "\"1060b-P+SpvVi3k5DaTmo+fNx5a5Tj7jc\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 67083,
		"path": "../client/assets/card-ads-DJ-iK2Fr.jpg"
	},
	"/assets/card-big-data-Bpj8CIvo.jpg": {
		"type": "image/jpeg",
		"etag": "\"1d55b-9bq5uU2+nyBV4x4lK7OeKCUsEO8\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 120155,
		"path": "../client/assets/card-big-data-Bpj8CIvo.jpg"
	},
	"/assets/card-cyber-PTqDKZit.jpg": {
		"type": "image/jpeg",
		"etag": "\"1ac1e-cqVwrfmSlgb2EjqnieWT9hk4/+c\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 109598,
		"path": "../client/assets/card-cyber-PTqDKZit.jpg"
	},
	"/assets/card-datasec-BluUat0n.jpg": {
		"type": "image/jpeg",
		"etag": "\"1dceb-dEmOMLlLXIvznPPnDF0KFJX/XiY\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 122091,
		"path": "../client/assets/card-datasec-BluUat0n.jpg"
	},
	"/assets/card-cyber-u0J200ox.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-vfQAabDTe3PxVrWUJClE2i7bRIY\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 320,
		"path": "../client/assets/card-cyber-u0J200ox.js"
	},
	"/assets/card-datasec-PUF67myO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-YQ7Jd0f5gYMI05ixRmOWeu5jG0g\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 256,
		"path": "../client/assets/card-datasec-PUF67myO.js"
	},
	"/assets/card-gen-ai-DEfPV7U1.jpg": {
		"type": "image/jpeg",
		"etag": "\"16b0b-vQOpiFJzk333U/DXIVf55T9vP+E\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 92939,
		"path": "../client/assets/card-gen-ai-DEfPV7U1.jpg"
	},
	"/assets/card-mm-anim-CKwd8WCj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39-19TvliRS5VAJOdX6j57oI4MLAUo\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 57,
		"path": "../client/assets/card-mm-anim-CKwd8WCj.js"
	},
	"/assets/card-mm-anim-Bd-FrTBr.jpg": {
		"type": "image/jpeg",
		"etag": "\"1e9d9-J17DCQIm+EGBdc4EuuXN/xFhlh4\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 125401,
		"path": "../client/assets/card-mm-anim-Bd-FrTBr.jpg"
	},
	"/assets/card-mm-film-Qfhdb-nU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ab-2TNlXJ9TYh7P+Qzz5FNPsQQJ4Mk\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 683,
		"path": "../client/assets/card-mm-film-Qfhdb-nU.js"
	},
	"/assets/card-big-data-DnLTJYDI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a-Lw8hPl+16Br/5D9z1Vd+gO1upjU\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 58,
		"path": "../client/assets/card-big-data-DnLTJYDI.js"
	},
	"/assets/card-mm-graphic-DLKiIJwN.jpg": {
		"type": "image/jpeg",
		"etag": "\"ef19-dY8Vtc+YH86mrE9Biqn2G1L78hg\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 61209,
		"path": "../client/assets/card-mm-graphic-DLKiIJwN.jpg"
	},
	"/assets/card-mm-graphic-WdRqDNpH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-tFttg+1DspfI8NAN55c96OgfeLs\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 60,
		"path": "../client/assets/card-mm-graphic-WdRqDNpH.js"
	},
	"/assets/card-mm-pmsmm-5SMiIHVx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a-zPx3SVfAUzJsVTyOeYy4MAd4UDY\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 58,
		"path": "../client/assets/card-mm-pmsmm-5SMiIHVx.js"
	},
	"/assets/card-mm-video-Baz5FnyN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"231-64tG32rbVhUnDuotreiFkWEY+aw\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 561,
		"path": "../client/assets/card-mm-video-Baz5FnyN.js"
	},
	"/assets/card-mm-pmsmm-CLp3IqrV.jpg": {
		"type": "image/jpeg",
		"etag": "\"10000-T+G0jvAm/ecgWqeOU5QgERkDeO0\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 65536,
		"path": "../client/assets/card-mm-pmsmm-CLp3IqrV.jpg"
	},
	"/assets/card-mm-video-khtT1hRU.jpg": {
		"type": "image/jpeg",
		"etag": "\"d1e5-nMCnpgz2rqKui2C8jfx18bfHOCE\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 53733,
		"path": "../client/assets/card-mm-video-khtT1hRU.jpg"
	},
	"/assets/card-mm-film-99sCthh-.jpg": {
		"type": "image/jpeg",
		"etag": "\"11ff0-g/megy7bGTUjEcfsnMwvJs7uvXM\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 73712,
		"path": "../client/assets/card-mm-film-99sCthh-.jpg"
	},
	"/assets/card-pm-C3b5mUmT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34-3lMzfDSOt5C4KW8IlPAWx3tibsE\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 52,
		"path": "../client/assets/card-pm-C3b5mUmT.js"
	},
	"/assets/clipboard-list-CSi_6Wkw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19b-cZ3ammro87SGH/4bq1NGiAZL4co\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 411,
		"path": "../client/assets/clipboard-list-CSi_6Wkw.js"
	},
	"/assets/circle-check-TGib2X25.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-lfTG7h9SP0PPhK50rR5k/xcF3H8\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 178,
		"path": "../client/assets/circle-check-TGib2X25.js"
	},
	"/assets/clock-BKbfwJ3a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-rPzKxZ/qJdcgBSgDNLuvifdNZko\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 169,
		"path": "../client/assets/clock-BKbfwJ3a.js"
	},
	"/assets/cpu-C2Ti4Yfb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"282-MCW0PEwnNZjKWo905ww+3nERrAE\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 642,
		"path": "../client/assets/cpu-C2Ti4Yfb.js"
	},
	"/assets/chart-line-nk6w2sOy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-O3dfrd4wfd7gX1aFddL4HKPAh5E\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 230,
		"path": "../client/assets/chart-line-nk6w2sOy.js"
	},
	"/assets/card-pm-C0cmCUOD.jpg": {
		"type": "image/jpeg",
		"etag": "\"141ce-R9GX0L+sSWs2jTX6Nzz8Zr4P2u8\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 82382,
		"path": "../client/assets/card-pm-C0cmCUOD.jpg"
	},
	"/assets/chart-column-D_th3kef.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-6CmBBTmbDJ4cEayGEyAtobmALRA\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 251,
		"path": "../client/assets/chart-column-D_th3kef.js"
	},
	"/assets/createLucideIcon-CaYjXmwE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c7-ieLfiYFDYYnJ1wQZ5yp8fwjjFKA\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 1223,
		"path": "../client/assets/createLucideIcon-CaYjXmwE.js"
	},
	"/assets/film-DwcZmSds.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"197-/NifVBiksFTQcZ8tduHbb4NqaVg\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 407,
		"path": "../client/assets/film-DwcZmSds.js"
	},
	"/assets/demoday-B7TpFu8S.jpg": {
		"type": "image/jpeg",
		"etag": "\"12783-M69L2XCMTMT+L9Ai5U9T3KCJaLU\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 75651,
		"path": "../client/assets/demoday-B7TpFu8S.jpg"
	},
	"/assets/future-score-BrrGkMPG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d8-Ig2hRyJUq1bj2H75FYr6UjDp+5k\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 216,
		"path": "../client/assets/future-score-BrrGkMPG.js"
	},
	"/assets/database-CIGND17q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3-tytnGFfCY4P1/SxOpRCd6K8s/eI\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 243,
		"path": "../client/assets/database-CIGND17q.js"
	},
	"/assets/graduation-cap-DQ-Mniyi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-Doha+0SWmBxhRYrV0icu+yNmknU\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 332,
		"path": "../client/assets/graduation-cap-DQ-Mniyi.js"
	},
	"/assets/incubation-DwOEbldm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20eb-I8ehQX2VQq4GZHiBnltp2KdC0bU\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 8427,
		"path": "../client/assets/incubation-DwOEbldm.js"
	},
	"/assets/dollar-sign-CuVNJAhL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db-4GdpUe3wniyzsOIKy3MB2NddHaU\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 219,
		"path": "../client/assets/dollar-sign-CuVNJAhL.js"
	},
	"/assets/handshake-WBXbQIlY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1be-6HDSiq+/BhzfdzIxEi+fRZYJvnA\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 446,
		"path": "../client/assets/handshake-WBXbQIlY.js"
	},
	"/assets/lightbulb-DGx7Rxji.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-7Z6GhbnCK/83qTZDzuFMl2vEn98\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 286,
		"path": "../client/assets/lightbulb-DGx7Rxji.js"
	},
	"/assets/future-score.index-RSIKuZfW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"266a4-XXxQD4OrO7PFPcu0XaZhoopVgkY\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 157348,
		"path": "../client/assets/future-score.index-RSIKuZfW.js"
	},
	"/assets/link-Gv8cj_pG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1eab-5yTN4/0SyTVce97v7Jxe4ps+jK8\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 7851,
		"path": "../client/assets/link-Gv8cj_pG.js"
	},
	"/assets/mail-D311rqVx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-MIOFrVbOsV0ERGxPR7Sp0uhaJgw\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 213,
		"path": "../client/assets/mail-D311rqVx.js"
	},
	"/assets/management-B0fx_eZP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-0zH+OI9TGv9x2JnUhuNAZygOcDE\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 141,
		"path": "../client/assets/management-B0fx_eZP.js"
	},
	"/assets/management.business-entrepreneurship-DgDfVhep.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"efe-c4YK+OI7BW2LIK1YWuehOLPP2MY\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 3838,
		"path": "../client/assets/management.business-entrepreneurship-DgDfVhep.js"
	},
	"/assets/management.finance-accounting-Bnt5GC98.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1132-F4BLJ69hB3zam11XwMWYiMwCD2Q\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 4402,
		"path": "../client/assets/management.finance-accounting-Bnt5GC98.js"
	},
	"/assets/management.index-CnWUNwgY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c78-gNypIJOLi3fYMm31GjJEXE3iUXw\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 7288,
		"path": "../client/assets/management.index-CnWUNwgY.js"
	},
	"/assets/management.marketing-growth-k5RATs5v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f28-EvquHh/4AkCyqhnsZxP+F2xXnkM\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 3880,
		"path": "../client/assets/management.marketing-growth-k5RATs5v.js"
	},
	"/assets/management.people-operations-BOrH79Y3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f89-AyuD/uv111MbfavU9hOsD/RN6Es\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 3977,
		"path": "../client/assets/management.people-operations-BOrH79Y3.js"
	},
	"/assets/management.product-management-DO02F-t8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3e-sAyoR6f+VugYg9oyNsDDbDbnQWk\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 3902,
		"path": "../client/assets/management.product-management-DO02F-t8.js"
	},
	"/assets/index-DVUBL9F0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57597-0b0Ba93jAfJqdzx3zbm8V6U7b+0\"",
		"mtime": "2026-09-15T07:18:22.749Z",
		"size": 357783,
		"path": "../client/assets/index-DVUBL9F0.js"
	},
	"/assets/management.sales-business-development-CtxBnuCU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109d-t0REH+Rf1Fu1q4kliChu2Ne8yvQ\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 4253,
		"path": "../client/assets/management.sales-business-development-CtxBnuCU.js"
	},
	"/assets/layers-gDFDcbgW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a5-As1+EMMLxRvNbOBE4Ie+5HiDQ3w\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 421,
		"path": "../client/assets/layers-gDFDcbgW.js"
	},
	"/assets/future-score.admin-d-Q0oHAj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"182c-Jaf/7GPjJub5Ad0As0clfZ3VnxI\"",
		"mtime": "2026-09-15T07:18:22.750Z",
		"size": 6188,
		"path": "../client/assets/future-score.admin-d-Q0oHAj.js"
	},
	"/assets/jsx-runtime-BkSabwWG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c1-VkW1xFbt56H2FC99QIi6PTzaFIo\"",
		"mtime": "2026-09-15T07:18:22.751Z",
		"size": 961,
		"path": "../client/assets/jsx-runtime-BkSabwWG.js"
	},
	"/assets/megaphone-Tpf7wljb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15a-p9A6S/swqrgwg9lGy+nTAfYPwUA\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 346,
		"path": "../client/assets/megaphone-Tpf7wljb.js"
	},
	"/assets/message-square-DdDyki-u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-4XaXNWIgO7xzh1SteaXSCywxDPU\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 233,
		"path": "../client/assets/message-square-DdDyki-u.js"
	},
	"/assets/mg-fin-CSctJc0h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33-hXi/5IEtSMwVf9DSbF3xHXBNMIQ\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 51,
		"path": "../client/assets/mg-fin-CSctJc0h.js"
	},
	"/assets/mg-biz-DFrq5LD0.jpg": {
		"type": "image/jpeg",
		"etag": "\"de3a-pdB3MJFxGAyJ7txRG8zpb1iVOw0\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 56890,
		"path": "../client/assets/mg-biz-DFrq5LD0.jpg"
	},
	"/assets/mg-biz-Z1fqNwKi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33-fgks8BBNtvCyD0t54HJ2jcIi/vc\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 51,
		"path": "../client/assets/mg-biz-Z1fqNwKi.js"
	},
	"/assets/matchContext-BLYTW6T-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b8-w/kjeBoZNPkLTlgTDCx+iZdj3SM\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 696,
		"path": "../client/assets/matchContext-BLYTW6T-.js"
	},
	"/assets/mg-fin-Dk_yZD5L.jpg": {
		"type": "image/jpeg",
		"etag": "\"126e1-txlDBG6SjFYIT9jmm2zTQaxrzD8\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 75489,
		"path": "../client/assets/mg-fin-Dk_yZD5L.jpg"
	},
	"/assets/mg-pm-C2dIXUV8.jpg": {
		"type": "image/jpeg",
		"etag": "\"d61c-HbHODVHx06YPTyEcwKtDGAQWtMw\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 54812,
		"path": "../client/assets/mg-pm-C2dIXUV8.jpg"
	},
	"/assets/mg-ppl-BxO7CfRZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33-P8rJsCJjSGIl1DEOW/7C2AJ7qc0\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 51,
		"path": "../client/assets/mg-ppl-BxO7CfRZ.js"
	},
	"/assets/mg-sales-D-nzijmP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35-tEC7w3ED0rUhKBbcblBdY9wLYgM\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 53,
		"path": "../client/assets/mg-sales-D-nzijmP.js"
	},
	"/assets/mg-sales-yokooVLE.jpg": {
		"type": "image/jpeg",
		"etag": "\"f484-RgFhZl4sZ6ro+ROG84MO9PtOmwA\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 62596,
		"path": "../client/assets/mg-sales-yokooVLE.jpg"
	},
	"/assets/monitor-QUfmzXuq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-Zs9zmoldcSu7c8oKyZKLu24L7Sw\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 259,
		"path": "../client/assets/monitor-QUfmzXuq.js"
	},
	"/assets/mg-pm-_uUYt0yW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32-y9ZqpE5br1q2RS7BLzgI6KiwZNw\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 50,
		"path": "../client/assets/mg-pm-_uUYt0yW.js"
	},
	"/assets/multimedia-B0fx_eZP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-0zH+OI9TGv9x2JnUhuNAZygOcDE\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 141,
		"path": "../client/assets/multimedia-B0fx_eZP.js"
	},
	"/assets/multimedia.ai-graphic-design-D93xQ8DE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e72-3XDpvMxN4GQNUj+S4RpAEMw3U9g\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 7794,
		"path": "../client/assets/multimedia.ai-graphic-design-D93xQ8DE.js"
	},
	"/assets/multimedia.ai-video-editing-vfx-BRmGdmEQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1051-huEg1rH3IrN1CnHM7qzN17PEtRk\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 4177,
		"path": "../client/assets/multimedia.ai-video-editing-vfx-BRmGdmEQ.js"
	},
	"/assets/mg-ppl-tXwti5PD.jpg": {
		"type": "image/jpeg",
		"etag": "\"13566-njOEHpMozScQJZu9WT3BfSz3lws\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 79206,
		"path": "../client/assets/mg-ppl-tXwti5PD.jpg"
	},
	"/assets/multimedia.animation-vfx-qvD9TaqG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1011-sJHptCce4ex+J1n8wTekcAVld2E\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 4113,
		"path": "../client/assets/multimedia.animation-vfx-qvD9TaqG.js"
	},
	"/assets/multimedia.film-production-BN9THC-1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1115-58gwA/mXE2cBfhfwyF85FgIrnq8\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 4373,
		"path": "../client/assets/multimedia.film-production-BN9THC-1.js"
	},
	"/assets/multimedia.index-Bvmc03vZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d63-b/6oajPEQxsYGFD5SDnllR+rJEU\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 7523,
		"path": "../client/assets/multimedia.index-Bvmc03vZ.js"
	},
	"/assets/multimedia.pm-smm-CrTXcOPb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fd9-0lxceM16VuKQzH8jwL3IYlUZE54\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 4057,
		"path": "../client/assets/multimedia.pm-smm-CrTXcOPb.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 118,
		"path": "../client/assets/not-found-i5RsCZif.js"
	},
	"/assets/online-programs-DYsfyrwG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"195b-tMj6r+GJ7MVyr3kbXzf97L/tX2g\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 6491,
		"path": "../client/assets/online-programs-DYsfyrwG.js"
	},
	"/assets/mg-mkt-CinH8Xja.jpg": {
		"type": "image/jpeg",
		"etag": "\"fd8a-dTJt0QSt8nxiblxw6iiPsDLjaUU\"",
		"mtime": "2026-09-15T07:18:22.754Z",
		"size": 64906,
		"path": "../client/assets/mg-mkt-CinH8Xja.jpg"
	},
	"/assets/mg-mkt-DWna6EAV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33-+XvA5en6tG2PkoNutlZZDGSdJx0\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 51,
		"path": "../client/assets/mg-mkt-DWna6EAV.js"
	},
	"/assets/outcomes-BB3QBeEe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ea4-HYXsRzEnbpyeT11HCVxyxsAzDQ0\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 7844,
		"path": "../client/assets/outcomes-BB3QBeEe.js"
	},
	"/assets/pen-tool-DaR_Nwkh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d7-W7BE0inLibPrSmjx6qDWY9b9S50\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 471,
		"path": "../client/assets/pen-tool-DaR_Nwkh.js"
	},
	"/assets/pillar-1-B4pPyRBj.jpg": {
		"type": "image/jpeg",
		"etag": "\"19568-UegBXgsylnimj+N6ls43XC7ga/Y\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 103784,
		"path": "../client/assets/pillar-1-B4pPyRBj.jpg"
	},
	"/assets/pillar-3-kMnNw3ZX.jpg": {
		"type": "image/jpeg",
		"etag": "\"17d8d-zMD6+0XZ8F8MQbPN+MkkWjkBmC8\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 97677,
		"path": "../client/assets/pillar-3-kMnNw3ZX.jpg"
	},
	"/assets/portfolio._slug-CsxKerUa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1da-50Yh8tLTip1uWfqjT7wgnhTS0jY\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 474,
		"path": "../client/assets/portfolio._slug-CsxKerUa.js"
	},
	"/assets/pillar-4-CuQaj3eW.jpg": {
		"type": "image/jpeg",
		"etag": "\"12fb1-otkX+0KE3UQrP2VjLY5IOW0OW1A\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 77745,
		"path": "../client/assets/pillar-4-CuQaj3eW.jpg"
	},
	"/assets/pillar-2-DX6hmi3q.jpg": {
		"type": "image/jpeg",
		"etag": "\"12ee3-ibGuFwB9weIr0Ml/R+8wWivPH5U\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 77539,
		"path": "../client/assets/pillar-2-DX6hmi3q.jpg"
	},
	"/assets/scale-BH-Im57Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-krosX8kPQ30hUhwGpGfxPGyNq6g\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 332,
		"path": "../client/assets/scale-BH-Im57Q.js"
	},
	"/assets/react-DHmoMYoq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d67-nufvvndhXtiz6VWh8XcPEWVqP1g\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 7527,
		"path": "../client/assets/react-DHmoMYoq.js"
	},
	"/assets/routes-DCV3gM8T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"415d-e49EVu6HoU4BVwt3s+klmx0If/8\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 16733,
		"path": "../client/assets/routes-DCV3gM8T.js"
	},
	"/assets/search-CKfJmV27.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-XklEKa2dsZd/edXQahgpX8T+FSE\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 174,
		"path": "../client/assets/search-CKfJmV27.js"
	},
	"/assets/server-DekXndRZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"152-W0ChvrE1talk0Ro6Cdwfj4b2Sv0\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 338,
		"path": "../client/assets/server-DekXndRZ.js"
	},
	"/assets/scissors-Dfhpwz4W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"137-C0AGI/w2kjph44kIPWdhEJQGqAY\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 311,
		"path": "../client/assets/scissors-Dfhpwz4W.js"
	},
	"/assets/skill-ai-logo-DmE8jtHA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a-pvULJbMpCO4yjRUekqmdUAAtv1k\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 58,
		"path": "../client/assets/skill-ai-logo-DmE8jtHA.js"
	},
	"/assets/sparkles-uETicRdT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-VmHg7UiyYeRBWGcHD3761lUyins\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 494,
		"path": "../client/assets/sparkles-uETicRdT.js"
	},
	"/assets/styles-C_OCSo1s.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"218db-0fuVlhVhst1vgUeNKe2UyhKe7x8\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 137435,
		"path": "../client/assets/styles-C_OCSo1s.css"
	},
	"/assets/timer-Bnm_-rZF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ee-dwsoyYk2dui7COscFWtClMpLLh0\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 238,
		"path": "../client/assets/timer-Bnm_-rZF.js"
	},
	"/assets/target-reOs65de.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2-8ifL7JOnSmvUzbAC7vGCG9glESU\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 226,
		"path": "../client/assets/target-reOs65de.js"
	},
	"/assets/rocket-Bq8rK28_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c4-7bocMNqZaDoRmdlIVPxIB7hsDz4\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 452,
		"path": "../client/assets/rocket-Bq8rK28_.js"
	},
	"/assets/portfolio._slug-D8j17tRc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"399b-rcGdVF9HgtvGdB9Y3d8o0dtgZpA\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 14747,
		"path": "../client/assets/portfolio._slug-D8j17tRc.js"
	},
	"/assets/trending-up-CGDmfQK9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-R1iQVh/Hbj2YQb9MIZ6CP3e0Fy8\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 175,
		"path": "../client/assets/trending-up-CGDmfQK9.js"
	},
	"/assets/portfolio._slug-n_8VEPAT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d9-WRopS350IBRPxkyPiXeFuc3wO0E\"",
		"mtime": "2026-09-15T07:18:22.752Z",
		"size": 473,
		"path": "../client/assets/portfolio._slug-n_8VEPAT.js"
	},
	"/assets/trophy-uAopZ_Rk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dc-o9SfdpLDy7yBW4BlA/eFQwvWjJs\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 476,
		"path": "../client/assets/trophy-uAopZ_Rk.js"
	},
	"/assets/ug-programs-C0hx78k1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ec4-F8+95Wtivv4a7VbEwBvcD6zL8zI\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 20164,
		"path": "../client/assets/ug-programs-C0hx78k1.js"
	},
	"/assets/skill-ai-logo-oMhBKOpr.png": {
		"type": "image/png",
		"etag": "\"a5cbf-O4ztGgOmmebyxh7mF3T/p/qWEiY\"",
		"mtime": "2026-09-15T07:18:22.755Z",
		"size": 679103,
		"path": "../client/assets/skill-ai-logo-oMhBKOpr.png"
	},
	"/assets/users-CviH6Ox7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-FGYjeEnAXwBkNOfe3xBpSbiDolE\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 306,
		"path": "../client/assets/users-CviH6Ox7.js"
	},
	"/assets/wand-sparkles-2tq41lzm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"201-7ytHZo7aEmxFB40V70/MScKVsVg\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 513,
		"path": "../client/assets/wand-sparkles-2tq41lzm.js"
	},
	"/assets/x-Bmtl9lp9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"231-Yp/P7rgr3IK5nsr1tMg9F3jZToU\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 561,
		"path": "../client/assets/x-Bmtl9lp9.js"
	},
	"/assets/useStore-CG-np4nj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b11-sVE792V2CIDFfQMRdJNcEMoWGo4\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 19217,
		"path": "../client/assets/useStore-CG-np4nj.js"
	},
	"/assets/zap-3lSWz4TO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"106-x7P8HVw0cl92TlU4PS0L6p8QObQ\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 262,
		"path": "../client/assets/zap-3lSWz4TO.js"
	},
	"/assets/workshop-CvIKmBB_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8085-860b+VV8IU+JyJ/1tR33+CDAtwI\"",
		"mtime": "2026-09-15T07:18:22.753Z",
		"size": 32901,
		"path": "../client/assets/workshop-CvIKmBB_.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_j21Qvj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
